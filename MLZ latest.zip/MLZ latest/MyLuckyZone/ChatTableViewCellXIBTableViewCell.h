//
//  ChatTableViewCellXIBTableViewCell.h
//  VP Chat
//
//  Created by TechnoTackle on 11/04/17.
//  Copyright © 2017 TechnoTackle. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ChatTableViewCellXIBTableViewCell : UITableViewCell
@property (weak, nonatomic) IBOutlet UILabel *chatNameLabel;
@property (weak, nonatomic) IBOutlet UILabel *chatMessageLabel;
@property (weak, nonatomic) IBOutlet UILabel *chatTimeLabel;
@property (weak, nonatomic) IBOutlet UIImageView *chatUserImage;
@property (weak, nonatomic) IBOutlet UIImageView *chatImageView;

@end
