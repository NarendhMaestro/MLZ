//
//  ReferralsCell.swift
//  MyLuckyZone
//
//  Created by Kavya Mishra on 6/9/16.
//  Copyright © 2016 Adodis. All rights reserved.
//

import UIKit

class ReferralsCell: UITableViewCell {

    @IBOutlet weak var theStatusLabel: UILabel!
    @IBOutlet weak var theDOJLabel: UILabel!
    @IBOutlet weak var theEmailIdLabel: UILabel!
    @IBOutlet weak var theNameLabel: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
