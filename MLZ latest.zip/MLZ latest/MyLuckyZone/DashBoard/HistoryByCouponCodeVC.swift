//
//  HistoryByCouponCodeVC.swift
//  MyLuckyZone
//
//  Created by Kavya Mishra on 5/29/16.
//  Copyright © 2016 Adodis. All rights reserved.
//

import UIKit

class HistoryByCouponCodeVC: UIViewController,UITableViewDataSource , UITableViewDelegate {
    
    var theHistoryByCouponDataArray = NSMutableArray()
    var currentPage = NSInteger()
    
    var totalPage = NSInteger()
    
    @IBOutlet weak var tableView: UITableView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        //self.tableView.register(UITableViewCell.self, forCellReuseIdentifier: "historyByCoupon")
        tableView.delegate = self
        tableView.dataSource = self
        tableView.reloadData()
        self.navigationItem.title = "History By Coupon Code"
        // Do any additional setup after loading the view.
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(true)
        
        if Reachability.isConnectedToNetwork() == true {
            self.currentPage = 1
            self.historyBYCouponCode(self.currentPage)
            
        } else {
            self.displayAlert("Alert Message", message: "Please Check Internet connection")
            
        }
        
    }
    
    
    
    func historyBYCouponCode(_ pageNumber:NSInteger)
    {
        self.showProgress()
        let body = String(format:"token=%@&pagenumer=%@", UserDefaults.standard.object(forKey: "token") as! String,String(pageNumber))
        
        let task = "earnedhistorybycoupons"
        WebService().sendAPIRequest(UrlClass.baseUrl, body: body,task: task) { (result, error) -> Void in
            
            if result["status"] as! Int == 1
            {
                
                print(result)
                self.totalPage = result ["totalpages"] as! NSInteger
                //self.refundablePoints = result["refundablepoints"] as! String
                if(self.currentPage == 1)
                {
                    self.theHistoryByCouponDataArray = (result["history"] as! NSArray).mutableCopy() as! NSMutableArray
                }
                else{
                    let newPageArr = result["history"] as! NSArray
                    
                    let newArr = self.theHistoryByCouponDataArray.mutableCopy() as? NSMutableArray
                    
                    for i in self.theHistoryByCouponDataArray.count ..< self.theHistoryByCouponDataArray.count+newPageArr.count
                    {
                        newArr!.insert(newPageArr[i-self.theHistoryByCouponDataArray.count], at: i)
                    }
                    self.theHistoryByCouponDataArray = newArr!
                }
                
                
                DispatchQueue.main.async(execute: { () -> Void in
                    self.hideProgress()
                    if(self.theHistoryByCouponDataArray.count>0){
                        
                        self.tableView.reloadData()
                    }
                    else{
                        
                        //self.tableView.isHidden =
                        self.displayAlert("Alert Message", message: "No History")
                    }
                })
            }else{
                //self.tableView.isHidden =
                DispatchQueue.main.async(execute: { () -> Void in
                    self.hideProgress()
                    self.displayAlert("Alert Message", message: "No History")
                    
                })
                
            }
        }
    }
    
    
    func numberOfSections(in tableView: UITableView) -> Int
    {
        return 1
    }// Default is 1 if not implemented
    
    
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int
    {
        return self.theHistoryByCouponDataArray.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell
    {
        let cell   = tableView.dequeueReusableCell(withIdentifier: "historyBycoupon", for: indexPath) //as UITableViewCell//
            as! HistoryByCouponCell
        
        cell.historyCouponCodeLabel.text = (self.theHistoryByCouponDataArray.object(at: (indexPath as NSIndexPath).row) as AnyObject).value(forKey: "couponcode") as? String
        
        cell.historyCoupenDateLabel.text = (self.theHistoryByCouponDataArray.object(at: (indexPath as NSIndexPath).row) as AnyObject).value(forKey: "datetime") as? String
        
        cell.historyCouponEarnLabel.text = (self.theHistoryByCouponDataArray.object(at: (indexPath as NSIndexPath).row) as AnyObject).value(forKey: "points") as? String
        
        
        
        return cell
    }
    
    func scrollViewDidEndDragging(_ scrollView: UIScrollView, willDecelerate decelerate: Bool) {
        
        let currentOffset = scrollView.contentOffset.y
        
        let maximumOffset = scrollView.contentSize.height - scrollView.frame.size.height
        
        
        if (maximumOffset - currentOffset <= 10)
        {
            if (self.currentPage == totalPage)
            {
                
            } else {
                self.currentPage = self.currentPage + 1
                
                self.historyBYCouponCode(self.currentPage)
            }
            
        }
        
    }
    
    
    
    
    /*
     // MARK: - Navigation
     
     // In a storyboard-based application, you will often want to do a little preparation before navigation
     override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
     // Get the new view controller using segue.destinationViewController.
     // Pass the selected object to the new view controller.
     }
     */
    
}
