//
//  shippingStatusTVC.swift
//  MyLuckyZone
//
//  Created by G.Abhisek on 30/05/16.
//  Copyright © 2016 Adodis. All rights reserved.
//

import UIKit

class shippingStatusTVC: UITableViewCell {

    @IBOutlet weak var productImage: UIImageView!
    @IBOutlet weak var productNameLbl: UILabel!
    @IBOutlet weak var shippingStatusLbl: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
