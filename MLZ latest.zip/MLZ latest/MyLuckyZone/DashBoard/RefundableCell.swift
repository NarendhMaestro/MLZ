
//
//  RefundableCell.swift
//  MyLuckyZone
//
//  Created by Kavya Mishra on 6/10/16.
//  Copyright © 2016 Adodis. All rights reserved.
//

import UIKit

class RefundableCell: UITableViewCell {

    @IBOutlet weak var theStatusLabel: UILabel!
    @IBOutlet weak var theRefundableLabel: UILabel!
    @IBOutlet weak var theStakeId: UILabel!
    @IBOutlet weak var theTitleLabel: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
