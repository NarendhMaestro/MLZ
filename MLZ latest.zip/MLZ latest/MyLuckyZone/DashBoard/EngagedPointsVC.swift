//
//  EngagedPointsVC.swift
//  MyLuckyZone
//
//  Created by Adodis on 30/05/16.
//  Copyright © 2016 Adodis. All rights reserved.
//

import UIKit

class EngagedPointsVC: UIViewController ,UITableViewDataSource , UITableViewDelegate,UIPickerViewDataSource,UIPickerViewDelegate {
    
    @IBOutlet var choeseCategoryButton: UIButton!
    @IBOutlet var theTableView: UITableView!
    @IBOutlet var pickerView: UIPickerView!
    @IBOutlet var engagedPointsCategoryView: UIView!
    
    var pickerViewDataArray = NSMutableArray()
    var maskView = UIView()
    var selectedCategory:String!
    var tableDataArray = NSMutableArray()
    var refreshControl: UIRefreshControl!
    
    var currentPage = NSInteger()
    
    var totalPage = NSInteger()
    
    override func viewDidLoad()
    {
        super.viewDidLoad()
        
        refreshControl = UIRefreshControl()
        //refreshControl.attributedTitle = NSAttributedString(string: "Pull to refresh")
        refreshControl.addTarget(self, action: #selector(EngagedPointsVC.refresh(_:)), for: UIControlEvents.valueChanged)
        self.theTableView.addSubview(refreshControl)
        self.theTableView.tableFooterView = UIView()
        
        self.navigationItem.title = "Engaged Points"
        
        pickerViewDataArray = ["Sweep Stake Bid","Auction Bids","Purchased Products","Elite Products", "Risky Auction Bids"]
        selectedCategory = pickerViewDataArray[0] as? String
        
        
        self.choeseCategoryButton .setTitle(selectedCategory, for: UIControlState())
    }
    
    func refresh(_ sender:AnyObject) {
        
        self.theTableView.reloadData()
        
        refreshControl.endRefreshing()
    }
    
    
    override func viewWillAppear(_ animated: Bool)
    {
        super.viewWillAppear(true)
        if Reachability.isConnectedToNetwork() == true {
            self.currentPage = 1
            self.sweepStakeBid(self.currentPage)
            
        } else {
            self.displayAlert("Alert Message", message: "Please Check Internet connection")
            
        }
        
    }
    

    @IBAction func ShowPickerView(_ sender: AnyObject)
    {
        maskView = UIView(frame:view.bounds)
        maskView.backgroundColor = UIColor.lightGray
        //maskView.alpha = 0.5
        engagedPointsCategoryView.frame = CGRect(x: 0, y: view.frame.height-260, width: view.frame.width, height: 260)
        maskView.addSubview(engagedPointsCategoryView)
        view.addSubview(maskView)
    }
    
    
    
    //MARK:Pickerview data source methods
    func numberOfComponents(in pickerView: UIPickerView) -> Int
    {
        return 1
    }
    
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int
    {
        return pickerViewDataArray.count
    }
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String?
    {
        return pickerViewDataArray[row] as? String
    }
    
    //PickerView delegate method
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int)
    {
        selectedCategory = pickerViewDataArray[row] as? String
        
    }
    
    
    func numberOfSections(in tableView: UITableView) -> Int
    {
        return 1
    }// Default is 1 if not implemented
    
    
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int
    {
        return self.tableDataArray.count
    }
    
    // Row display. Implementers should *always* try to reuse cells by setting each cell's reuseIdentifier and querying for available reusable cells with dequeueReusableCellWithIdentifier:
    // Cell gets various attributes set automatically based on table (separators) and data source (accessory views, editing controls)
    
    func getProductDetails(_ key : String) -> String {
        if let retString = self.tableDataArray.value(forKey: key) as? String {
            return retString
        }
        if let retArray = self.tableDataArray.value(forKey: key) as? NSArray {
            if let retString = retArray[0] as? String {
                return retString
            }
        }
        return ""
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell
    {
        let index = pickerView.selectedRow(inComponent: 0)
        if index == 2 || index == 3 {
            let cell = theTableView.dequeueReusableCell(withIdentifier: "engagedPointsProductCell", for: indexPath) as! EngagedPointsProductCell
            cell.productName.text = self.getProductDetails("producttitle")
            cell.salesCode.text = "Sales Code : \(self.getProductDetails("salescode"))"
            cell.quantity.text = "Quantity : \(self.getProductDetails("qty"))"
            cell.purchasedStatus.text = "Purchased Status : \(self.getProductDetails("status"))"
            cell.points.text = "Points : \(self.getProductDetails("points"))"
            cell.purchasedAt.text = "Purchased At : \(self.getProductDetails("date"))"
            return cell
        } else {
            let cell = theTableView.dequeueReusableCell(withIdentifier: "engagedPointsCell", for: indexPath) as! EngagedPointsCell
            cell.theProducttitle.text = (self.tableDataArray.object(at: (indexPath as NSIndexPath).row) as AnyObject).value(forKey: "producttitle") as? String
            cell.theBiddate.text = (self.tableDataArray.object(at: (indexPath as NSIndexPath).row) as AnyObject).value(forKey: "biddate") as? String
            cell.theBidstatus.text = (self.tableDataArray.object(at: (indexPath as NSIndexPath).row) as AnyObject).value(forKey: "bidstatus") as? String
            cell.thePoints.text = (self.tableDataArray.object(at: (indexPath as NSIndexPath).row) as AnyObject).value(forKey: "points") as? String
            let flag = (self.tableDataArray.object(at: (indexPath as NSIndexPath).row) as AnyObject).value(forKey: "canwithdraw") as? Int
            if flag == 1 {
                cell.deleteButton.isHidden = false
                if let bidid = (self.tableDataArray.object(at: (indexPath as NSIndexPath).row) as AnyObject).value(forKey: "bidid") as? String {
                    cell.deleteButton.tag =  Int(bidid)!
                }
                cell.deleteButton.addTarget(self, action: #selector(EngagedPointsVC.deleteButtonPressed(_:)), for: .touchUpInside)
            } else {
                cell.deleteButton.isHidden = true
            }
            return cell
        }
    }
    
    func deleteListItem(_ bidid : String) {
        for item in self.tableDataArray {
            let id = (item as AnyObject).value(forKey: "bidid") as? String
            if id == bidid {
                self.tableDataArray = self.tableDataArray.mutableCopy() as! NSMutableArray
                self.tableDataArray.remove(item)
                break;
            }
        }
    }
    
    
    @IBAction func deleteButtonPressed(_ sender: AnyObject)
    {
        let alertController = UIAlertController(title: "Alert", message: "Are you sure to withdraw this?", preferredStyle: .alert)
        alertController.addAction(UIAlertAction(title: "Yes", style: .default, handler: {(UIAlertAction) -> Void in
            self.deleteItem(sender)
        }))
        alertController.addAction(UIAlertAction(title: "No", style: .cancel, handler: nil))
        self.present(alertController, animated: true, completion: nil)
    }
    
    func deleteItem(_ sender: AnyObject) {
        print("delete is pressed")
        self.showProgress()
        let button = sender as! UIButton
        let bidid = String(button.tag)
        let body = String(format:"token=%@&bidid=%@", UserDefaults.standard.object(forKey: "token") as! String, bidid)
        var task : String?
        switch pickerView.selectedRow(inComponent: 0) {
        case 0: //sweepstake
            task = "withdrawsweepstakebid"
        case 1: //Auction bid
            task = "withdrawauctionbid"
        case 4: //Risky Auction bid
            task = "withdrawriskyauctionbid"
        default:
            task = ""
        }
        WebService().sendAPIRequest(UrlClass.baseUrl, body: body,task: task!) { (result, error) -> Void in
            DispatchQueue.main.async(execute: { () -> Void in
                self.hideProgress()
                if result["status"] as! Int == 1 {
                    self.deleteListItem(bidid)
                    self.theTableView.reloadData()
                } else {
                    self.displayAlert("Alert Message", message: result["msg"] as! String)
                }
                
            })
        }
        
    }
    
    
    func isNotNSNull(_ object:AnyObject) -> Bool {
        return object.classForCoder != NSNull.classForCoder()
    }
    
    func sweepStakeBid(_ pageNumber:NSInteger)
    {
        self.showProgress()
        let body = String(format:"token=%@&pagenumer=%@", UserDefaults.standard.object(forKey: "token") as! String,String(pageNumber))
        let task = "listusersweepstakebids"
        WebService().sendAPIRequest(UrlClass.baseUrl, body: body,task: task) { (result, error) -> Void in
            
            if result["status"] as! Int == 1
            {
                self.totalPage = result["totalpages"] as! NSInteger
                
                if(self.currentPage == 1)
                {
                    self.tableDataArray = (result["bids"] as! NSArray).mutableCopy() as! NSMutableArray
                } else {
                    
                    let newPageArr = result["bids"] as! NSArray
                    
                    let newArr = self.tableDataArray.mutableCopy() as? NSMutableArray
                    
                    for i in self.tableDataArray.count ..< self.tableDataArray.count+newPageArr.count
                    {
                        newArr!.insert(newPageArr[i-self.tableDataArray.count], at: i)
                    }
                    self.tableDataArray = newArr!
                }
                
                DispatchQueue.main.async(execute: { () -> Void in
                    self.hideProgress()
                    
                    self.theTableView.reloadData()
                })
            } else if result["status"] as! Int == 0 || result["status"] as! Int == -1
            {
                DispatchQueue.main.async(execute: { () -> Void in
                    self.showErrorMessage(result["msg"] as? String)
                })
            }
        }
    }
    
    func showErrorMessage(_ message : String?) {
        self.tableDataArray = NSMutableArray()
        self.hideProgress()
        self.displayAlert("Alert Message", message: message!)
        self.theTableView.reloadData()
    }
    
    
    func auctionBids(_ pageNumber:NSInteger)
    {
        self.showProgress()
        
        let body = String(format:"token=%@&pagenumer=%@", UserDefaults.standard.object(forKey: "token") as! String,String(pageNumber))
        
        let task = "listuserauctionbids"
        WebService().sendAPIRequest(UrlClass.baseUrl, body: body,task: task) { (result, error) -> Void in
            
            if result["status"] as! Int == 1
            {
                self.totalPage = result["totalpages"] as! NSInteger
                
                if(self.currentPage == 1)
                {
                    self.tableDataArray = (result["bids"] as! NSArray).mutableCopy() as! NSMutableArray
                } else {
                    
                    let newPageArr = result["bids"] as! NSArray
                    
                    let newArr = self.tableDataArray.mutableCopy() as? NSMutableArray
                    
                    for i in self.tableDataArray.count ..< self.tableDataArray.count+newPageArr.count
                    {
                        newArr!.insert(newPageArr[i-self.tableDataArray.count], at: i)
                    }
                    self.tableDataArray = newArr!
                }
                
                DispatchQueue.main.async(execute: { () -> Void in
                    self.hideProgress()
                    
                    self.theTableView.reloadData()
                })
            } else if result["status"] as! Int == 0 || result["status"] as! Int == -1
            {
                DispatchQueue.main.async(execute: { () -> Void in
                    self.showErrorMessage(result["msg"] as? String)
                })
            }
        }
    }
    
    
    func riskyAuctionBids(_ pageNumber:NSInteger)
    {
        self.showProgress()
        
        let body = String(format:"token=%@&pagenumer=%@", UserDefaults.standard.object(forKey: "token") as! String,String(pageNumber))
        
        let task = "listuserriskyauctionbids"
        WebService().sendAPIRequest(UrlClass.baseUrl, body: body,task: task) { (result, error) -> Void in
            
            if result["status"] as! Int == 1
            {
                self.totalPage = result["totalpages"] as! NSInteger
                
                if(self.currentPage == 1)
                {
                    self.tableDataArray = (result["bids"] as! NSArray).mutableCopy() as! NSMutableArray
                } else {
                    
                    let newPageArr = result["bids"] as! NSArray
                    
                    let newArr = self.tableDataArray.mutableCopy() as? NSMutableArray
                    
                    for i in self.tableDataArray.count ..< self.tableDataArray.count+newPageArr.count
                    {
                        newArr!.insert(newPageArr[i-self.tableDataArray.count], at: i)
                    }
                    self.tableDataArray = newArr!
                }
                
                DispatchQueue.main.async(execute: { () -> Void in
                    self.hideProgress()
                    
                    self.theTableView.reloadData()
                })
            } else if result["status"] as! Int == 0 || result["status"] as! Int == -1
            {
                DispatchQueue.main.async(execute: { () -> Void in
                    self.showErrorMessage(result["msg"] as? String)
                })
            }
        }
    }
    
    
    func userPurchaseBids(_ pageNumber:NSInteger)
    {
        self.showProgress()
        
        let body = String(format:"token=%@&pagenumer=%@", UserDefaults.standard.object(forKey: "token") as! String,String(pageNumber))
        
        let task = "listuserpurchases"
        WebService().sendAPIRequest(UrlClass.baseUrl, body: body,task: task) { (result, error) -> Void in
            
            if result["status"] as! Int == 1
            {
                self.totalPage = result["totalpages"] as! NSInteger
                
                if(self.currentPage == 1)
                {
                    self.tableDataArray = (result["bids"] as! NSArray).mutableCopy() as! NSMutableArray
                } else {
                    
                    let newPageArr = result["bids"] as! NSArray
                    
                    let newArr = self.tableDataArray.mutableCopy() as? NSMutableArray
                    
                    for i in self.tableDataArray.count ..< self.tableDataArray.count+newPageArr.count
                    {
                        newArr!.insert(newPageArr[i-self.tableDataArray.count], at: i)
                    }
                    self.tableDataArray = newArr!
                }
                
                DispatchQueue.main.async(execute: { () -> Void in
                    self.hideProgress()
                    
                    self.theTableView.reloadData()
                })
            } else if result["status"] as! Int == 0 || result["status"] as! Int == -1
            {
                DispatchQueue.main.async(execute: { () -> Void in
                    self.showErrorMessage(result["msg"] as? String)
                })
            }
        }
    }
    
    
    func EliteProducts(_ pageNumber:NSInteger)
    {
        self.showProgress()
        
        let body = String(format:"token=%@&pagenumer=%@", UserDefaults.standard.object(forKey: "token") as! String,String(pageNumber))
        
        let task = "listrefsalesuserpurchases"
        WebService().sendAPIRequest(UrlClass.baseUrl, body: body,task: task) { (result, error) -> Void in
            
            if result["status"] as! Int == 1
            {
                print(result)
                
                self.totalPage = result["totalpages"] as! NSInteger
                
                if(self.currentPage == 1)
                {
                    self.tableDataArray = (result["bids"] as! NSArray).mutableCopy() as! NSMutableArray
                } else {
                    
                    let newPageArr = result["bids"] as! NSArray
                    
                    let newArr = self.tableDataArray.mutableCopy() as? NSMutableArray
                    
                    for i in self.tableDataArray.count ..< self.tableDataArray.count+newPageArr.count
                    {
                        newArr!.insert(newPageArr[i-self.tableDataArray.count], at: i)
                    }
                    self.tableDataArray = newArr!
                }
                
                DispatchQueue.main.async(execute: { () -> Void in
                    self.hideProgress()
                    
                    self.theTableView.reloadData()
                })
            } else if result["status"] as! Int == 0 || result["status"] as! Int == -1
            {
                DispatchQueue.main.async(execute: { () -> Void in
                    self.showErrorMessage(result["msg"] as? String)
                })
            }
        }
    }
    
    
    
    
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    @IBAction func dismisspickerView(_ sender: AnyObject)
    {
        maskView.removeFromSuperview()
    }
    
    @IBAction func ChooseCategory(_ sender: AnyObject)
    {
        maskView.removeFromSuperview()
        
        self.choeseCategoryButton .setTitle(selectedCategory, for: UIControlState())
        
        if Reachability.isConnectedToNetwork() == true {
            
            self.currentPage = 1
            if selectedCategory == "Sweep Stake Bid"
            {
                sweepStakeBid(self.currentPage)
            }
            else if selectedCategory == "Auction Bids"
            {
                auctionBids(self.currentPage)
            }
            else if selectedCategory == "Purchased Products"
            {
                userPurchaseBids(self.currentPage)
                
            } else if selectedCategory == "Elite Products"
            {
                EliteProducts(self.currentPage)
            } else if selectedCategory == "Risky Auction Bids" {
                self.riskyAuctionBids(self.currentPage)
            }
            
        } else {
            self.displayAlert("Alert Message", message: "Please Check Internet connection")
            
        }
    }
    
    
    func scrollViewDidEndDragging(_ scrollView: UIScrollView, willDecelerate decelerate: Bool) {
        
        let currentOffset = scrollView.contentOffset.y
        
        let maximumOffset = scrollView.contentSize.height - scrollView.frame.size.height
        
        
        if (maximumOffset - currentOffset <= 10)
        {
            if (self.currentPage == totalPage)
            {
                
            } else {//["Sweep Stake Bid","Auction Bids","Purchased Products","Elite Products", "Risky Auction Bids"]
                self.currentPage = self.currentPage + 1
                
                switch (selectedCategory! as String)
                {
                case "Sweep Stake Bid":
                    sweepStakeBid(self.currentPage)
                    
                case "Auction Bids":
                    auctionBids(self.currentPage)
                    
                case "Purchased Products":
                    userPurchaseBids(self.currentPage)
                    
                case "Elite Products":
                    EliteProducts(self.currentPage)
                case "Risky Auction Bids":
                    self.riskyAuctionBids(self.currentPage)
                default: break
                }
            }
        }
    }
    
    
    
    //    func displayAlert(title: String, message: String) {
    //        let alertController = UIAlertController(title: title, message: message, preferredStyle: .Alert)
    //        alertController.addAction(UIAlertAction(title: "OK", style: .Default, handler: nil))
    //        presentViewController(alertController, animated: true, completion: nil)
    //    }
    
    
    /*
     // MARK: - Navigation
     
     // In a storyboard-based application, you will often want to do a little preparation before navigation
     override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
     // Get the new view controller using segue.destinationViewController.
     // Pass the selected object to the new view controller.
     }
     */
    
}
