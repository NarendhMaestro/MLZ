//
//  ReferralsVC.swift
//  MyLuckyZone
//
//  Created by Kavya Mishra on 6/9/16.
//  Copyright © 2016 Adodis. All rights reserved.
//

import UIKit

class ReferralsVC: UIViewController ,UITableViewDataSource , UITableViewDelegate {
    
    var theReferrralsDataArray = NSArray()
    
    var tag = NSString()
    
    @IBOutlet var theTableView: UITableView!
    
    var currentPage = NSInteger()
    
    var totalPage = NSInteger()
    
    var refreshControl: UIRefreshControl!
    
    var referralMessage : String?

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        refreshControl = UIRefreshControl()
        refreshControl.addTarget(self, action: #selector(ReferralsVC.refresh(_:)), for: UIControlEvents.valueChanged)
        self.theTableView.addSubview(refreshControl)
        
        // Do any additional setup after loading the view.
        
        if tag == "1"
        {
            self.navigationItem.title  = "Total Referrals"
        } else if tag == "2" {
            self.navigationItem.title  = "Current Referrals"
        } else {
            self.navigationItem.title  = "Pending Referrals"
        }
        self.theTableView.tableFooterView = UIView()

        WebService.sharedInstance.getReferralMessage({(result, error) -> () in
            self.referralMessage = result["msg"] as? String
            DispatchQueue.main.async(execute: { () -> Void in
                self.theTableView.reloadData()
            })
        });
    }
    
    func refresh(_ sender:AnyObject) {
        
        self.theTableView.reloadData()
        
        refreshControl.endRefreshing()
    }
    
    
    func numberOfSections(in tableView: UITableView) -> Int
    {
        if referralMessage == nil {
            return 1
        } else {
            return 2
        }
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        if referralMessage != nil && (indexPath as NSIndexPath).section == 0 {
            return 40
        } else {
            return 120
        }
    }

    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int
    {
        if referralMessage == nil {
            return self.theReferrralsDataArray.count
        } else {
            if section == 0 {
                return 1
            } else {
                return self.theReferrralsDataArray.count
            }
        }
    }
    
    // Row display. Implementers should *always* try to reuse cells by setting each cell's reuseIdentifier and querying for available reusable cells with dequeueReusableCellWithIdentifier:
    // Cell gets various attributes set automatically based on table (separators) and data source (accessory views, editing controls)
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell
    {
        if referralMessage != nil && (indexPath as NSIndexPath).section == 0 {
            let cell = UITableViewCell(style: UITableViewCellStyle.default, reuseIdentifier: "messageCell")
            cell.textLabel?.font = UIFont(name: "Helvetica Neue", size: 14)
            cell.textLabel?.textColor = UIColor(red: 136/256, green: 11/256, blue: 36/256, alpha: 1.0)
            cell.textLabel?.numberOfLines = 10
            cell.textLabel?.text = self.referralMessage
            return cell
        }
        let cell = tableView.dequeueReusableCell(withIdentifier: "referralsCell", for: indexPath) as! ReferralsCell
        cell.theNameLabel.text = (self.theReferrralsDataArray.object(at: (indexPath as NSIndexPath).row) as AnyObject).value(forKey: "name") as? String
        cell.theEmailIdLabel.text = (self.theReferrralsDataArray.object(at: (indexPath as NSIndexPath).row) as AnyObject).value(forKey: "emailid") as? String
        cell.theDOJLabel.text = (self.theReferrralsDataArray.object(at: (indexPath as NSIndexPath).row) as AnyObject).value(forKey: "dateofjoined") as? String
        cell.theStatusLabel.text = (self.theReferrralsDataArray.object(at: (indexPath as NSIndexPath).row) as AnyObject).value(forKey: "status") as? String
        return cell
    }


    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(true)
        if Reachability.isConnectedToNetwork() == true {
            self.currentPage = 1;
            self.currentreferrals(self.currentPage)
        } else {
            self.displayAlert("Alert Message", message: "Please Check Internet connection")
        }
    }

    
    func currentreferrals(_ pageNumber:NSInteger)
    {
        self.showProgress()
        
        let body = String(format:"token=%@&pagenumer=%@", UserDefaults.standard.object(forKey: "token") as! String,String(pageNumber))
        
        var task : String! = ""
        if tag == "1"
        {
            task = "myreferrals"
        } else if tag == "2" {
            task = "currentreferrals"
        } else {
            task = "pendingreferrals"
        }
        
        WebService().sendAPIRequest(UrlClass.baseUrl, body: body,task: task) { (result, error) -> Void in
            
            if result["status"] as! Int == 1
            {
                self.totalPage = result ["totalpages"] as! NSInteger
                
                if(self.currentPage == 1)
                {
                    self.theReferrralsDataArray = result["shippinglist"] as! NSArray
                } else {
                    
                    let newPageArr = result["shippinglist"] as! NSArray
                    
                    let newArr = self.theReferrralsDataArray.mutableCopy() as? NSMutableArray
                    
                    for i in self.theReferrralsDataArray.count ..< self.theReferrralsDataArray.count+newPageArr.count
                    {
                        newArr!.insert(newPageArr[i-self.theReferrralsDataArray.count], at: i)
                    }
                    self.theReferrralsDataArray = newArr!
                }
                
                DispatchQueue.main.async(execute: { () -> Void in
                    self.hideProgress()
                    self.theTableView.reloadData()
                })
            } else if result["status"] as! Int == 0 || result["status"] as! Int == -1
            {
                DispatchQueue.main.async(execute: { () -> Void in
                    self.hideProgress()
                    self.displayAlert("Alert Message", message: result["msg"] as! String)
                    self.theTableView.reloadData()
                })
            }
        }
    }
    
    
    
    func scrollViewDidEndDragging(_ scrollView: UIScrollView, willDecelerate decelerate: Bool) {
        
        let currentOffset = scrollView.contentOffset.y
        
        let maximumOffset = scrollView.contentSize.height - scrollView.frame.size.height
        
        
        if (maximumOffset - currentOffset <= 10)
        {
            if (self.currentPage == totalPage)
            {
                
            } else {
                self.currentPage = self.currentPage + 1
                
                self.currentreferrals(self.currentPage)
            }
            
        }
        
    }
    
//    func displayAlert(title: String, message: String) {
//        let alertController = UIAlertController(title: title, message: message, preferredStyle: .Alert)
//        alertController.addAction(UIAlertAction(title: "OK", style: .Default, handler: nil))
//        presentViewController(alertController, animated: true, completion: nil)
//    }
    

    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
