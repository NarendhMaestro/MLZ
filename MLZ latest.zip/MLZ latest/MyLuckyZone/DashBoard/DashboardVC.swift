//
//  DashboardVC.swift
//  MyLuckyZone
//
//  Created by Adodis on 25/05/16.
//  Copyright © 2016 Adodis. All rights reserved.
//

import UIKit
import AVKit
import AVFoundation
fileprivate func < <T : Comparable>(lhs: T?, rhs: T?) -> Bool {
  switch (lhs, rhs) {
  case let (l?, r?):
    return l < r
  case (nil, _?):
    return true
  default:
    return false
  }
}

fileprivate func > <T : Comparable>(lhs: T?, rhs: T?) -> Bool {
  switch (lhs, rhs) {
  case let (l?, r?):
    return l > r
  default:
    return rhs < lhs
  }
}


class DashboardVC: UIViewController,UITableViewDataSource,UITableViewDelegate
{

    @IBOutlet var dashboardTableView: UITableView!
    
    
    var tableDataArray = NSMutableArray()
    
    
    var availablePoints = "0"
    var refundablePoints = "0"
    var engagedPoints = "0"
    var totalReferrals = "0"
    var currentReferrals = "0"
    var salesreferrals = "0"
    var videoWebURL = ""
    var pendingReferrals = "0"

    var elitePurchaseCredits = "0"
    var bonusPurchaseCredits = "0"
    var memberShipType = ""
    
    override func viewDidLoad() {
        super.viewDidLoad()

        tableDataArray = ["Available Points","History By Browsing","History By Bonus","History By Coupon Codes","Engaged Points","Refundable Points","Winners","Shipping Status","Total Referrals","Current Referrals", "Pending Referrals", "Available Elite Purchase Credits","Available Bonus Purchase Credits","Membership Type"]
        
        WebService.sharedInstance.getReferralCount({(result, error) -> () in
            let status = result["status"] as? Int
            if status == -1 {
                let msg = result["msg"] as! String
                self.displayAlert("Error", message: msg, handler: {(UIAlertAction) -> Void in
                    self.logout()
                })
            } else if status == 1 {
                self.totalReferrals = result["totalreferrals"] as! String
                self.currentReferrals = result["currentreferrals"] as! String
                self.pendingReferrals = result["pendingreferrals"] as! String
                //self.salesreferrals = String(result["salesreferrals"] as! Int)
                self.salesreferrals = result["salesreferrals"] as! String
                
                self.elitePurchaseCredits = result["available_elite_purchase_credits"] as! String
                self.bonusPurchaseCredits = result["available_bonus_purchase_credits"] as! String
                self.memberShipType = result["membership_type"] as! String
                
//                do{
//                    print("passing")
//                    
//                    guard
//                        else {return nil}
//                print("Passed")
//                }catch{
//                    print("Error")
//                    self.salesreferrals = String("0" as! Int)
//                }
                
                                DispatchQueue.main.async(execute: {
                    self.dashboardTableView.reloadData()
                })
            }
        })

        WebService.sharedInstance.getPremiumSweepStakes({(result, error) -> () in
            let status = result["status"] as? Int
            if status == 1 {
                let msg = result["msg"] as? String
                if msg?.characters.count > 0 {
                    self.tableDataArray.add(msg!)
                    DispatchQueue.main.async(execute: { () -> Void in
                        self.dashboardTableView.reloadData()
                    })
                }
            }
        })
        
        self.getVideoURL()
        
        // Do any additional setup after loading the view.
    }
    
    func playVideo(){
       
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return tableDataArray.count
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        if (indexPath as NSIndexPath).row == 14 || (indexPath as NSIndexPath).row == 14 {
            return 80
        }
        return 50
    }

    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        if (indexPath as NSIndexPath).row == 0
        {
            let cell = dashboardTableView.dequeueReusableCell(withIdentifier: "availablePointsCell", for: indexPath) as! dashBoardTVC
            cell.availablePointsLabel.text = tableDataArray[(indexPath as NSIndexPath).row] as! String+" ("+availablePoints+") "
            return cell
        }
        else
        {
           print("TableCell:",tableDataArray[(indexPath as NSIndexPath).row] as? String as Any)
            
            if tableDataArray[(indexPath as NSIndexPath).row] as? String == "Engaged Points"
            {
                 let cell = dashboardTableView.dequeueReusableCell(withIdentifier: "otherCells", for: indexPath)
                 cell.textLabel?.text = tableDataArray[(indexPath as NSIndexPath).row] as! String+" ("+engagedPoints+") "
                 return cell
            }
            else if tableDataArray[(indexPath as NSIndexPath).row] as? String == "Refundable Points"
            {
                 let cell = dashboardTableView.dequeueReusableCell(withIdentifier: "otherCells", for: indexPath)
                 cell.textLabel?.text = tableDataArray[(indexPath as NSIndexPath).row] as! String+" ("+refundablePoints+") "
                 return cell
            }else if tableDataArray[(indexPath as NSIndexPath).row] as? String == "Total Referrals"
            {
                let cell = dashboardTableView.dequeueReusableCell(withIdentifier: "otherCells", for: indexPath)
                cell.textLabel?.text = tableDataArray[(indexPath as NSIndexPath).row] as! String+" ("+totalReferrals+") "
                return cell
            } else if tableDataArray[(indexPath as NSIndexPath).row] as? String == "Current Referrals"
            {
                let cell = dashboardTableView.dequeueReusableCell(withIdentifier: "otherCells", for: indexPath)
                cell.textLabel?.text = tableDataArray[(indexPath as NSIndexPath).row] as! String+" ("+currentReferrals+") "
                return cell
            }
            else if tableDataArray[(indexPath as NSIndexPath).row] as? String == "Pending Referrals"
            {
                let cell = dashboardTableView.dequeueReusableCell(withIdentifier: "otherCells", for: indexPath)
                cell.textLabel?.text = tableDataArray[(indexPath as NSIndexPath).row] as! String+" ("+pendingReferrals+") "
                return cell
            }
            else if tableDataArray[(indexPath as NSIndexPath).row] as? String == "Available Elite Purchase Credits"
            {
                let cell = dashboardTableView.dequeueReusableCell(withIdentifier: "otherCells", for: indexPath)
                cell.textLabel?.text = tableDataArray[(indexPath as NSIndexPath).row] as! String+" ("+elitePurchaseCredits+") "
                cell.textLabel?.numberOfLines = 2
                return cell
            }
            else if tableDataArray[(indexPath as NSIndexPath).row] as? String == "Available Bonus Purchase Credits"
            {
                let cell = dashboardTableView.dequeueReusableCell(withIdentifier: "otherCells", for: indexPath)
                cell.textLabel?.text = tableDataArray[(indexPath as NSIndexPath).row] as! String+" ("+bonusPurchaseCredits+") "
                cell.textLabel?.numberOfLines = 2
                return cell
            }
            else if tableDataArray[(indexPath as NSIndexPath).row] as? String == "Membership Type"
            {
                let cell = dashboardTableView.dequeueReusableCell(withIdentifier: "otherCells", for: indexPath)
                cell.textLabel?.text = tableDataArray[(indexPath as NSIndexPath).row] as! String+" ("+memberShipType+") "
                cell.textLabel?.numberOfLines = 3
                return cell
            }

            else if (indexPath as NSIndexPath).row == 14
            {
                let cell = dashboardTableView.dequeueReusableCell(withIdentifier: "otherCells", for: indexPath)
                let msg = tableDataArray.object(at: (indexPath as NSIndexPath).row)
                cell.textLabel?.text = "Premium Sweepstakes Status : (\(msg))"
                cell.textLabel?.numberOfLines = 4
                return cell
            }
            else
            {
                 let cell = dashboardTableView.dequeueReusableCell(withIdentifier: "otherCells", for: indexPath)
                 cell.textLabel?.text = tableDataArray[(indexPath as NSIndexPath).row] as? String
                 return cell
            }
            
        }
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath)
    {
        if (indexPath as NSIndexPath).row == 1
        {
            self.performSegue(withIdentifier: "historyByBrowsing", sender: self)
 
        } else if ((indexPath as NSIndexPath).row == 2)
        {
        self.performSegue(withIdentifier: "historyByBonus", sender: self)
            
        } else if ((indexPath as NSIndexPath).row == 3)
        {
            self.performSegue(withIdentifier: "historyBYCouponCode", sender: self)

        } else if ((indexPath as NSIndexPath).row == 4)
        {
        self.performSegue(withIdentifier: "engagedPoints", sender: self)
        }
        else if ((indexPath as NSIndexPath).row == 5)
        {
        self.performSegue(withIdentifier: "RefundablePoints", sender: self)
        } else if ((indexPath as NSIndexPath).row == 6)
        {
        self.performSegue(withIdentifier: "winners", sender: self)
        }
        else if ((indexPath as NSIndexPath).row == 7)
        {
        self.performSegue(withIdentifier: "shippingStatus", sender: self)
        }
        
        else if ((indexPath as NSIndexPath).row == 8)
        {
            self.performSegue(withIdentifier: "referrals", sender: "1")
        }
        else if ((indexPath as NSIndexPath).row == 9)
        {
            self.performSegue(withIdentifier: "referrals", sender: "2")
        }
        else if ((indexPath as NSIndexPath).row == 10)
        {
            self.performSegue(withIdentifier: "referrals", sender: "3")
        }

    }
    
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        
        if (segue.identifier == "referrals")
        {
            let destinationView = segue.destination as! ReferralsVC
            destinationView.tag = sender as! String as NSString
        }
        
        navigationItem.backBarButtonItem = UIBarButtonItem(title: "Backkk Butonnn", style: .plain, target: nil, action: nil)
    }

    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(true)
        
        if Reachability.isConnectedToNetwork() == true {
        self.dashBoard()

        } else {
        self.displayAlert("Alert Message", message: "Please Check Internet connection")
   
        }
    }
    
    
    func dashBoard()
    {
        let body = String(format:"token=%@", UserDefaults.standard.object(forKey: "token") as! String)
        
        let task = "dashboard"
        WebService().sendAPIRequest(UrlClass.baseUrl, body: body,task: task) { (result, error) -> Void in
            
            if result["status"] as! Int == 1
            {
            self.availablePoints = result["availablepoints"] as! String
                
            self.refundablePoints = result["refundablepoints"] as! String

            self.engagedPoints = result["engagedpoints"] as! String
                
           
            DispatchQueue.main.async(execute: { () -> Void in
            self.getuserreferralcount()
            })
            } else if result["status"] as! Int == 0 || result["status"] as! Int == -1
            {
            DispatchQueue.main.async(execute: { () -> Void in
            self.hideProgress()
            self.displayAlert("Alert Message", message: result["msg"] as! String)
            })
            }

        }
    }
    
    
    func getVideoURL()
    {
        let body = String(format:"token=%@", UserDefaults.standard.object(forKey: "token") as! String)
        
        let task = "demovideo"
        WebService().sendAPIRequest("http://dev.myluckyzone.com/webservice/", body: body,task: task) { (result, error) -> Void in
            
            if result["status"] as! Int == 1
            {
                self.videoWebURL = result["path"] as! String
            
                DispatchQueue.main.async(execute: { () -> Void in
                    self.playVideo()
                })
            } else if result["status"] as! Int == 0 || result["status"] as! Int == -1
            {
                DispatchQueue.main.async(execute: { () -> Void in
                    self.hideProgress()
                   // self.displayAlert("Alert Message", message: result["msg"] as! String)
                })
            }
            
        }
    }
    
    
    func getuserreferralcount()
    {
        let body = String(format:"token=%@&pagenumer=1", UserDefaults.standard.object(forKey: "token") as! String)
        
        let task = "getuserreferralcount"
        WebService().sendAPIRequest(UrlClass.baseUrl, body: body,task: task) { (result, error) -> Void in
            
            if result["status"] as! Int == 1
            {
            DispatchQueue.main.async(execute: { () -> Void in
                
            self.totalReferrals = result["totalreferrals"] as! String
                
            self.currentReferrals = result["currentreferrals"] as! String
              
             self.salesreferrals = result["salesreferrals"] as! String
            //self.salesreferrals = String(result["salesreferrals"] as! Int)
                
                self.elitePurchaseCredits = result["available_elite_purchase_credits"] as! String
                self.bonusPurchaseCredits = result["available_bonus_purchase_credits"] as! String
                self.memberShipType = result["membership_type"] as! String
            
                self.hideProgress()
            self.dashboardTableView.reloadData()
            })
            } else if result["status"] as! Int == 0  || result["status"] as! Int == -1
            {
            DispatchQueue.main.async(execute: { () -> Void in
            self.hideProgress()
            self.displayAlert("Alert Message", message: result["msg"] as! String)
            })
            }
            
        }
    }
    
//    func displayAlert(title: String, message: String) {
//        let alertController = UIAlertController(title: title, message: message, preferredStyle: .Alert)
//        alertController.addAction(UIAlertAction(title: "OK", style: .Default, handler: nil))
//        presentViewController(alertController, animated: true, completion: nil)
//    }


    

    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
