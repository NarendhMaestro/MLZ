//
//  EngagedPointsProductCell.swift
//  MyLuckyZone
//
//  Created by Prabhu Swaminathan on 19/08/16.
//  Copyright © 2016 Adodis. All rights reserved.
//

import UIKit
import Foundation

class EngagedPointsProductCell : UITableViewCell {
    
    @IBOutlet var purchasedAt: UILabel!
    @IBOutlet var points: UILabel!
    @IBOutlet var purchasedStatus: UILabel!
    @IBOutlet var quantity: UILabel!
    @IBOutlet var salesCode: UILabel!
    @IBOutlet var productName: UILabel!
}
