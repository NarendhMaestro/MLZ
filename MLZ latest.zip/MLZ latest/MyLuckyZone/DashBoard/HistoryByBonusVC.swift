//
//  HistoryByBonusVC.swift
//  MyLuckyZone
//
//  Created by Kavya Mishra on 5/29/16.
//  Copyright © 2016 Adodis. All rights reserved.
//

import UIKit

class HistoryByBonusVC: UIViewController ,UITableViewDataSource , UITableViewDelegate{
    
    @IBOutlet weak var theTableView: UITableView!
    var theHistoryByBonusDataArray = NSMutableArray()
    
    var currentPage = NSInteger()
    
    var totalPage = NSInteger()
    
    var refreshControl: UIRefreshControl!



    override func viewDidLoad() {
        super.viewDidLoad()
        
        refreshControl = UIRefreshControl()
        //refreshControl.attributedTitle = NSAttributedString(string: "Pull to refresh")
        refreshControl.addTarget(self, action: #selector(HistoryByBonusVC.refresh(_:)), for: UIControlEvents.valueChanged)
        self.theTableView.addSubview(refreshControl)

        self.navigationItem.title = "History By Bonus"
    }
    
    
    func refresh(_ sender:AnyObject) {
        
        self.theTableView.reloadData()
        
        refreshControl.endRefreshing()
    }
    

    
    func numberOfSections(in tableView: UITableView) -> Int
    {
        return 1
    }// Default is 1 if not implemented
    
    
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int
    {
        return self.theHistoryByBonusDataArray.count
    }
    
    // Row display. Implementers should *always* try to reuse cells by setting each cell's reuseIdentifier and querying for available reusable cells with dequeueReusableCellWithIdentifier:
    // Cell gets various attributes set automatically based on table (separators) and data source (accessory views, editing controls)
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell
    {
        let cell = tableView.dequeueReusableCell(withIdentifier: "historyByBonus", for: indexPath) as! HistoryByBonusCell
        
        cell.theDescriptionLabel.text = (self.theHistoryByBonusDataArray.object(at: (indexPath as NSIndexPath).row) as AnyObject).value(forKey: "description") as? String
        
        cell.theDateAndTimeLabel.text = (self.theHistoryByBonusDataArray.object(at: (indexPath as NSIndexPath).row) as AnyObject).value(forKey: "datetime") as? String
        
        cell.theEarnedPointsLabel.text = (self.theHistoryByBonusDataArray.object(at: (indexPath as NSIndexPath).row) as AnyObject).value(forKey: "points") as? String
        
        
        
        return cell
    }


    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(true)
        
        
        if Reachability.isConnectedToNetwork() == true {
            
        self.currentPage = 1
            
        self.historyBYBonus(1)
            
        } else {
            self.displayAlert("Alert Message", message: "Please Check Internet connection")
            
        }

    }
    
    
    
    func historyBYBonus(_ pageNumber:NSInteger)
    {
        self.showProgress()
        let body = String(format:"token=%@&pagenumer=%@", UserDefaults.standard.object(forKey: "token") as! String,String(pageNumber))
        
        let task = "earnedhistorybybonous"
        WebService().sendAPIRequest(UrlClass.baseUrl, body: body,task: task) { (result, error) -> Void in
            
            if result["status"] as! Int == 1
            {
                self.totalPage = result ["totalpages"] as! NSInteger
                
                if(self.currentPage == 1)
                {
                self.theHistoryByBonusDataArray = (result["history"] as! NSArray).mutableCopy() as! NSMutableArray
                }
                else
                {
                    let newPageArr = result["history"] as! NSArray
                    
                    let newArr = self.theHistoryByBonusDataArray.mutableCopy() as? NSMutableArray
                    
                    for i in self.theHistoryByBonusDataArray.count ..< self.theHistoryByBonusDataArray.count+newPageArr.count
                    {
                        newArr!.insert(newPageArr[i-self.theHistoryByBonusDataArray.count], at: i)
                    }
                    self.theHistoryByBonusDataArray = newArr!
                }
                
                DispatchQueue.main.async(execute: { () -> Void in
                self.hideProgress()
                self.theTableView.reloadData()
                })
            } else if result["status"] as! Int == 0 || result["status"] as! Int == -1
            {
            DispatchQueue.main.async(execute: { () -> Void in
            self.hideProgress()
            self.displayAlert("Alert Message", message: result["msg"] as! String)

            })
            }
        }
    }
    
    
    func scrollViewDidEndDragging(_ scrollView: UIScrollView, willDecelerate decelerate: Bool) {
        
        let currentOffset = scrollView.contentOffset.y
        
        let maximumOffset = scrollView.contentSize.height - scrollView.frame.size.height
        
        
        if (maximumOffset - currentOffset <= 10)
        {
            if (self.currentPage == totalPage)
            {
                
            } else {
                self.currentPage = self.currentPage + 1
                
                self.historyBYBonus(self.currentPage)
            }
            
        }
        
    }


//    func displayAlert(title: String, message: String) {
//        let alertController = UIAlertController(title: title, message: message, preferredStyle: .Alert)
//        alertController.addAction(UIAlertAction(title: "OK", style: .Default, handler: nil))
//        presentViewController(alertController, animated: true, completion: nil)
//    }

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
