//
//  HistoryByBrowsingCell.swift
//  MyLuckyZone
//
//  Created by Kavya Mishra on 5/30/16.
//  Copyright © 2016 Adodis. All rights reserved.
//

import UIKit

class HistoryByBrowsingCell: UITableViewCell {
    @IBOutlet weak var theWebsiteTitle: UILabel!

    @IBOutlet weak var theEarnedPoints: UILabel!
    @IBOutlet weak var theDuration: UILabel!
    @IBOutlet weak var theEndTime: UILabel!
    @IBOutlet weak var theStartTime: UILabel!
    @IBOutlet weak var theUrl: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
