//
//  WinnersCell.swift
//  MyLuckyZone
//
//  Created by Adodis on 30/05/16.
//  Copyright © 2016 Adodis. All rights reserved.
//

import UIKit

class WinnersCell: UITableViewCell {
    @IBOutlet var theWinnersTitleLabel: UILabel!

    @IBOutlet var theProductimg: UIImageView!
    @IBOutlet var theSweepstakedate: UILabel!
    @IBOutlet var theProductcode: UILabel!
    @IBOutlet var theProducttitle: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
