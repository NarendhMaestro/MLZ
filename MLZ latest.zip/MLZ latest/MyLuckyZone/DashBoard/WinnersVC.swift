//
//  WinnersVC.swift
//  MyLuckyZone
//
//  Created by Kavya Mishra on 5/29/16.
//  Copyright © 2016 Adodis. All rights reserved.
//

import UIKit
import SDWebImage


class WinnersVC: UIViewController ,UITableViewDataSource , UITableViewDelegate{
    
    var theWinnerListArray = NSArray()

    @IBOutlet var theTableView: UITableView!
    
    var currentPage = NSInteger()
    
    var totalPage = NSInteger()
    
    var refreshControl: UIRefreshControl!

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
        refreshControl = UIRefreshControl()
        //refreshControl.attributedTitle = NSAttributedString(string: "Pull to refresh")
        refreshControl.addTarget(self, action: #selector(WinnersVC.refresh(_:)), for: UIControlEvents.valueChanged)
        self.theTableView.addSubview(refreshControl)
        
        // Do any additional setup after loading the view.
        
        self.navigationItem.title = "Winners"
    }
    
    func refresh(_ sender:AnyObject) {
        
        self.theTableView.reloadData()
        
        refreshControl.endRefreshing()
    }

    
    
    func numberOfSections(in tableView: UITableView) -> Int
    {
        return 1
    }// Default is 1 if not implemented
    
    
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int
    {
        return self.theWinnerListArray.count
    }
    
    // Row display. Implementers should *always* try to reuse cells by setting each cell's reuseIdentifier and querying for available reusable cells with dequeueReusableCellWithIdentifier:
    // Cell gets various attributes set automatically based on table (separators) and data source (accessory views, editing controls)
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell
    {
        let cell = tableView.dequeueReusableCell(withIdentifier: "winnersCell", for: indexPath) as! WinnersCell
        
        cell.theWinnersTitleLabel.text = (self.theWinnerListArray.object(at: (indexPath as NSIndexPath).row) as AnyObject).value(forKey: "winner") as? String
        
        cell.theProducttitle.text = (self.theWinnerListArray.object(at: (indexPath as NSIndexPath).row) as AnyObject).value(forKey: "producttitle") as? String
        
        cell.theProductcode.text = (self.theWinnerListArray.object(at: (indexPath as NSIndexPath).row) as AnyObject).value(forKey: "productcode") as? String
        
        cell.theSweepstakedate.text = (self.theWinnerListArray.object(at: (indexPath as NSIndexPath).row) as AnyObject).value(forKey: "sweepstakedate") as? String
        
        
        let temp = self.theWinnerListArray.object(at: indexPath.row) as? AnyObject
        if let value = temp?.value(forKey: "productimg") as? String
        {
            let imageURl = String(format: "%@%@",  WebService.sharedInstance.getBaseURL, value)
            
            if (isNotNSNull(imageURl as AnyObject))
            {
                cell.theProductimg.sd_setImage(with: URL(string:imageURl)
                    , placeholderImage: nil
                    , options: SDWebImageOptions.retryFailed
                    , progress: {(receivedSize: Int, expectedSize: Int) in
                    }
                    , completed:{(image: UIImage?, error: Error?, cacheType: SDImageCacheType, imageURL: URL?) in
                        if (image != nil) {
                        cell.theProductimg.image = image
                        }
                })
            }
        }

        return cell
    }


    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(true)
        
        
        
        if Reachability.isConnectedToNetwork() == true {
            
            self.currentPage = 1;
            
            self.winners(self.currentPage)
            
        } else {
            self.displayAlert("Alert Message", message: "Please Check Internet connection")
            
        }
    }
    
    
    func isNotNSNull(_ object:AnyObject) -> Bool {
        return object.classForCoder != NSNull.classForCoder()
    }
    
    
    
    func winners(_ pageNumber:NSInteger)
    {
        self.showProgress()
        
        let body = String(format:"token=%@&pagenumer=%@", UserDefaults.standard.object(forKey: "token") as! String,String(pageNumber))
        
        let task = "listallsweepstakewinners"
        WebService().sendAPIRequest(UrlClass.baseUrl, body: body,task: task) { (result, error) -> Void in
            
            if result["status"] as! Int == 1
            {
                self.totalPage = result ["totalpages"] as! NSInteger

                if(self.currentPage == 1)
                {
                self.theWinnerListArray = result["winnerslist"] as! NSArray
                } else {
                    
                    let newPageArr = result["winnerslist"] as! NSArray
                    
                    let newArr = self.theWinnerListArray.mutableCopy() as? NSMutableArray
                    
                    for i in self.theWinnerListArray.count ..< self.theWinnerListArray.count+newPageArr.count
                    {
                        newArr!.insert(newPageArr[i-self.theWinnerListArray.count], at: i)
                    }
                    self.theWinnerListArray = newArr!
                }

            DispatchQueue.main.async(execute: { () -> Void in
            self.hideProgress()
             self.theTableView.reloadData()
            })
            } else if result["status"] as! Int == 0 || result["status"] as! Int == -1
            {
            DispatchQueue.main.async(execute: { () -> Void in
            self.hideProgress()
            self.displayAlert("Alert Message", message: result["msg"] as! String)
            self.theTableView.reloadData()
            })
            }
        }
    }
    
    
    
    func scrollViewDidEndDragging(_ scrollView: UIScrollView, willDecelerate decelerate: Bool) {
        
        let currentOffset = scrollView.contentOffset.y
        
        let maximumOffset = scrollView.contentSize.height - scrollView.frame.size.height
        
        
        if (maximumOffset - currentOffset <= 10)
        {
            if (self.currentPage == totalPage)
            {
                
            } else {
                self.currentPage = self.currentPage + 1
                
                self.winners(self.currentPage)
            }
            
        }
        
    }
    
   

    

    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
