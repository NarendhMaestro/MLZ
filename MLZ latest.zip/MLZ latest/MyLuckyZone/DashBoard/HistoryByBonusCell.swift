//
//  HistoryByBonusCell.swift
//  MyLuckyZone
//
//  Created by Kavya Mishra on 5/30/16.
//  Copyright © 2016 Adodis. All rights reserved.
//

import UIKit

class HistoryByBonusCell: UITableViewCell {

    @IBOutlet weak var theEarnedPointsLabel: UILabel!
    @IBOutlet weak var theDateAndTimeLabel: UILabel!
    @IBOutlet weak var theDescriptionLabel: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
