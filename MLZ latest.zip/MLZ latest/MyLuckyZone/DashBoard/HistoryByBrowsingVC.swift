//
//  HistoryByBrowsingVC.swift
//  MyLuckyZone
//
//  Created by Adodis on 27/05/16.
//  Copyright © 2016 Adodis. All rights reserved.
//

import UIKit

class HistoryByBrowsingVC: UIViewController ,UITableViewDataSource , UITableViewDelegate {
    
    @IBOutlet weak var theTableView: UITableView!
    
    var currentPage = NSInteger()
    
    var totalPage = NSInteger()
    
    var theHistoryBrowsingDataArray = NSMutableArray()
    
    var refreshControl: UIRefreshControl!


    override func viewDidLoad() {
        super.viewDidLoad()
        
        refreshControl = UIRefreshControl()
        //refreshControl.attributedTitle = NSAttributedString(string: "Pull to refresh")
        refreshControl.addTarget(self, action: #selector(HistoryByBrowsingVC.refresh(_:)), for: UIControlEvents.valueChanged)
        self.theTableView.addSubview(refreshControl)
        
        theTableView.rowHeight = UITableViewAutomaticDimension
        theTableView.estimatedRowHeight = 168

        // Do any additional setup after loading the view.
        
        self.navigationItem.title = "History By Browsing"
    }

    
    func refresh(_ sender:AnyObject) {
        
        self.theTableView.reloadData()
        
        refreshControl.endRefreshing()
    }
    
    func numberOfSections(in tableView: UITableView) -> Int
    {
        return 1
    }// Default is 1 if not implemented
    

    
     func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int
     {
        return self.theHistoryBrowsingDataArray.count
    }
    
    // Row display. Implementers should *always* try to reuse cells by setting each cell's reuseIdentifier and querying for available reusable cells with dequeueReusableCellWithIdentifier:
    // Cell gets various attributes set automatically based on table (separators) and data source (accessory views, editing controls)
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell
     {
        let cell = tableView.dequeueReusableCell(withIdentifier: "historyByBrowsing", for: indexPath) as! HistoryByBrowsingCell
        
        
          cell.theWebsiteTitle.text = (self.theHistoryBrowsingDataArray.object(at: (indexPath as NSIndexPath).row) as AnyObject).value(forKey: "website") as? String
     
        
        cell.theUrl.text = (self.theHistoryBrowsingDataArray.object(at: (indexPath as NSIndexPath).row) as AnyObject).value(forKey: "url") as? String

        cell.theStartTime.text = (self.theHistoryBrowsingDataArray.object(at: (indexPath as NSIndexPath).row) as AnyObject).value(forKey: "starttime") as? String

        cell.theEndTime.text = (self.theHistoryBrowsingDataArray.object(at: (indexPath as NSIndexPath).row) as AnyObject).value(forKey: "endtime") as? String

        cell.theDuration.text = (self.theHistoryBrowsingDataArray.object(at: (indexPath as NSIndexPath).row) as AnyObject).value(forKey: "duration") as? String

        cell.theEarnedPoints.text = (self.theHistoryBrowsingDataArray.object(at: (indexPath as NSIndexPath).row) as AnyObject).value(forKey: "points") as? String


        
        return cell
    }
    
    

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(true)
        
        if Reachability.isConnectedToNetwork() == true {
            self.currentPage = 1;
            
            self.historyBYBrowsing(self.currentPage)
        } else {
            self.displayAlert("Alert Message", message: "Please Check Internet connection")
            
        }
        
        
    }

    
    
    func historyBYBrowsing(_ pageNumber:NSInteger)
    {
        self.showProgress()
        let body = String(format:"token=%@&pagenumer=%@", UserDefaults.standard.object(forKey: "token") as! String,String(pageNumber))
        
        let task = "earnedhistorybybrowsing"
        WebService().sendAPIRequest(UrlClass.baseUrl, body: body,task: task) { (result, error) -> Void in
            
            if result["status"] as! Int == 1
            {
            self.totalPage = result["totalpages"] as! NSInteger
 
                
            if(self.currentPage == 1)
            {
            self.theHistoryBrowsingDataArray = (result["history"] as! NSArray).mutableCopy() as! NSMutableArray
            } else {
                
                let newPageArr = result["history"] as! NSArray
                
                let newArr = self.theHistoryBrowsingDataArray.mutableCopy() as? NSMutableArray
                
                for i in self.theHistoryBrowsingDataArray.count ..< self.theHistoryBrowsingDataArray.count+newPageArr.count
                {
                    newArr!.insert(newPageArr[i-self.theHistoryBrowsingDataArray.count], at: i)
                }
                self.theHistoryBrowsingDataArray = newArr!
            }
            DispatchQueue.main.async(execute: { () -> Void in
            self.hideProgress()
            self.theTableView.reloadData()
            })
            } else if result["status"] as! Int == 0  || result["status"] as! Int == -1
            {
            DispatchQueue.main.async(execute: { () -> Void in
                self.hideProgress()
            self.displayAlert("Alert Message", message: result["msg"] as! String)

            })
            }

        }
    }
    
    
    func scrollViewDidEndDragging(_ scrollView: UIScrollView, willDecelerate decelerate: Bool) {
        
        let currentOffset = scrollView.contentOffset.y
        
        let maximumOffset = scrollView.contentSize.height - scrollView.frame.size.height
        
        
        if (maximumOffset - currentOffset <= 10)
        {
            if (self.currentPage == totalPage)
            {
                
            } else {
                self.currentPage = self.currentPage + 1
                
                self.historyBYBrowsing(self.currentPage)
            }
            
        }
        
    }

   
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
