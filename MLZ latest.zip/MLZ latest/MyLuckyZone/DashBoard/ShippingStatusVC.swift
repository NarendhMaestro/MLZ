//
//  ShippingStatusVC.swift
//  MyLuckyZone
//
//  Created by Adodis on 30/05/16.
//  Copyright © 2016 Adodis. All rights reserved.
//

import UIKit
import SDWebImage
import Foundation

class ShippingStatusVC: UIViewController,UITableViewDelegate,UITableViewDataSource
{

    @IBOutlet var choseCategoryButton: UIButton!
    @IBOutlet weak var shippingStatusTableView: UITableView!
    
    @IBOutlet var pickerView: UIPickerView!
    
    @IBOutlet var shippingStatusCategoryView: UIView!
    
    var productListArray=NSMutableArray()
    
    var pickerViewDataArray = NSMutableArray()
    var maskView = UIView()
    var selectedCategory:String!
    
    var currentPage = NSInteger()
    
    var totalPage = NSInteger()
    
    var theHistoryBrowsingDataArray = NSMutableArray()
    
    var refreshControl: UIRefreshControl!

    
    override func viewDidLoad() {
        super.viewDidLoad()

        selectedCategory = "Sweep Stake Wins"
        pickerViewDataArray = ["Sweep Stake Wins","Auction Wins","Purchased Products","Elite Products"]
        
        // Do any additional setup after loading the view.
        
        refreshControl = UIRefreshControl()
        //refreshControl.attributedTitle = NSAttributedString(string: "Pull to refresh")
        refreshControl.addTarget(self, action: #selector(ShippingStatusVC.refresh(_:)), for: UIControlEvents.valueChanged)
        self.shippingStatusTableView.addSubview(refreshControl)
        
        // Do any additional setup after loading the view.
        
        self.navigationItem.title = "Shipping Status"
    }
    
    func refresh(_ sender:AnyObject) {
        
        self.shippingStatusTableView.reloadData()
        
        refreshControl.endRefreshing()
    }


    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    override func viewWillAppear(_ animated: Bool)
    {
        self.choseCategoryButton .setTitle("Sweep Stake Wins", for: UIControlState())
        
        if Reachability.isConnectedToNetwork() == true {
            
            self.currentPage = 1;
            
            shippingStatusSweepStakewins(self.currentPage)
            
        } else {
            self.displayAlert("Alert Message", message: "Please Check Internet connection")
            
        }
        
    }
    
    
    @IBAction func ShowPickerView(_ sender: AnyObject)
    {
        maskView = UIView(frame:view.bounds)
        maskView.backgroundColor = UIColor.lightGray
        //maskView.alpha = 0.5
        shippingStatusCategoryView.frame = CGRect(x: 0, y: view.frame.height-260, width: view.frame.width, height: 260)
        maskView.addSubview(shippingStatusCategoryView)
        view.addSubview(maskView)
    }
    
    //MARK:Pickerview data source methods
    func numberOfComponentsInPickerView(_ pickerView: UIPickerView) -> Int
    {
        return 1
    }
    
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int
    {
        return pickerViewDataArray.count
    }
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String?
    {
        return pickerViewDataArray[row] as? String
    }
    
    //PickerView delegate method
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int)
    {
        selectedCategory = pickerViewDataArray[row] as? String
        
    }

    
    //MARK:TableView data source
    
    
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int
    {
        return productListArray.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell
    {
        let cell = shippingStatusTableView.dequeueReusableCell(withIdentifier: "shippingStatusCell", for: indexPath) as? shippingStatusTVC
        
        cell?.productNameLbl.text = (productListArray[(indexPath as NSIndexPath).row] as AnyObject).value(forKey: "producttitle") as? String
        cell?.shippingStatusLbl.text = (productListArray[(indexPath as NSIndexPath).row] as AnyObject).value(forKey: "status") as? String
        
        let imagePath = String(format: "%@%@",  WebService.sharedInstance.getBaseURL, ((self.productListArray[(indexPath as NSIndexPath).row] as AnyObject).value(forKey: "productimg") as? String)!)
        
        cell?.productImage.sd_setImage(with: URL(string:imagePath)
            , placeholderImage: nil
            , options: SDWebImageOptions.retryFailed
            , progress: {(receivedSize: Int, expectedSize: Int) in
                
            }
            , completed:{(image: UIImage?, error: Error?, cacheType: SDImageCacheType, imageURL: URL?) in
                if (image != nil) {
                    cell!.productImage.image = image
                }
        })

        return cell!
    }
    
    
    func shippingStatusSweepStakewins(_ pageNumber:NSInteger)
    {
        self.showProgress()

        let body = String(format:"token=%@&pagenumer=%@", UserDefaults.standard.object(forKey: "token") as! String,String(pageNumber))
        
        let task = "shippingstatussweepstakewins"
        WebService().sendAPIRequest(UrlClass.baseUrl, body: body,task: task) { (result, error) -> Void in
            
            if result["status"] as! Int == 1
            {
                self.totalPage = result ["totalpages"] as! NSInteger

                if(self.currentPage == 1)
                {
                    print("result 0:", result["shippinglist"])
                    
                    let newPageArr = result["shippinglist"] as! NSArray
                    
                    print("result count:", newPageArr.count)
                    
                    let nsMutableArray = NSMutableArray(array: newPageArr)
                    
                    
                    print("result 2:", nsMutableArray)
                    self.productListArray = nsMutableArray
                } else {
                    
                    let newPageArr = result["shippinglist"] as! NSArray
                    
                    let newArr = self.productListArray.mutableCopy() as? NSMutableArray
                    
                    for i in self.productListArray.count ..< self.productListArray.count+newPageArr.count
                    {
                        newArr!.insert(newPageArr[i-self.productListArray.count], at: i)
                    }
                    self.productListArray = newArr!
                }
                DispatchQueue.main.async(execute: { () -> Void in
                    self.hideProgress()

                    self.shippingStatusTableView.reloadData()
                })
            } else if result["status"] as! Int == 0 || result["status"] as! Int == -1
            {
            DispatchQueue.main.async(execute: { () -> Void in
            self.hideProgress()
            self.displayAlert("Alert Message", message: result["msg"] as! String)
            self.productListArray.removeAllObjects()
            self.shippingStatusTableView.reloadData()

            })
            }
        }
    }
    
    
    
    func shippingStatusAuctionWins(_ pageNumber:NSInteger)
    {
        self.showProgress()

      let body = String(format:"token=%@&pagenumer=%@", UserDefaults.standard.object(forKey: "token") as! String,String(pageNumber))
        
        let task = "shippingstatusauctionwins"
        WebService().sendAPIRequest(UrlClass.baseUrl, body: body,task: task) { (result, error) -> Void in
            
            if result["status"] as! Int == 1
            {
                self.totalPage = result ["totalpages"] as! NSInteger
                
                if(self.currentPage == 1)
                {
                    print("result 0:", result["shippinglist"])
                    
                    let newPageArr = result["shippinglist"] as! NSArray
                    
                    print("result count:", newPageArr.count)
                    
                    let nsMutableArray = NSMutableArray(array: newPageArr)
                    
                    
                    print("result 2:", nsMutableArray)
                    self.productListArray = nsMutableArray
                } else {
                    
                    let newPageArr = result["shippinglist"] as! NSArray
                    
                    let newArr = self.productListArray.mutableCopy() as? NSMutableArray
                    
                    for i in self.productListArray.count ..< self.productListArray.count+newPageArr.count
                    {
                        newArr!.insert(newPageArr[i-self.productListArray.count], at: i)
                    }
                    self.productListArray = newArr!
                }
                
                DispatchQueue.main.async(execute: { () -> Void in
                    self.hideProgress()

                    self.shippingStatusTableView.reloadData()
                })
            } else if result["status"] as! Int == 0 || result["status"] as! Int == -1
            {
                DispatchQueue.main.async(execute: { () -> Void in
                    
                self.hideProgress()
                self.displayAlert("Alert Message", message: result["msg"] as! String)
                self.productListArray.removeAllObjects()
                self.shippingStatusTableView.reloadData()

                })
            }
        }
    }
    
    
    
    func shippingStatusPurchasedProducts(_ pageNumber:NSInteger)
    {
        self.showProgress()

        let body = String(format:"token=%@&pagenumer=%@", UserDefaults.standard.object(forKey: "token") as! String,String(pageNumber))
        
        let task = "shippingstatuspurchasedproducts"
        WebService().sendAPIRequest(UrlClass.baseUrl, body: body,task: task) { (result, error) -> Void in
            
            print("primary result data :", result)
            print("primary result keys :", result.keys)
            print("primary result count :", result.count)
            print("primary result values :", result.values)
            //print("primary result isempty :", result.isEmptyvalues)
            
            if result["status"] as! Int == 1
            {
                self.totalPage = result ["totalpages"] as! NSInteger
                
                if(self.currentPage == 1)
                {
                    print("result 0:", result["shippinglist"])
                    
                    let newPageArr = result["shippinglist"] as! NSArray
                    
                    print("result count:", newPageArr.count)
                    
                    let nsMutableArray = NSMutableArray(array: newPageArr)
                    
                    
                    print("result 2:", nsMutableArray)
                    self.productListArray = nsMutableArray
                   // self.productListArray = result["shippinglist"] as! NSMutableArray
                } else {
                    
                    let newPageArr = result["shippinglist"] as! NSArray
                    
                    let newArr = self.productListArray.mutableCopy() as? NSMutableArray
                    
                    for i in self.productListArray.count ..< self.productListArray.count+newPageArr.count
                    {
                        newArr!.insert(newPageArr[i-self.productListArray.count], at: i)
                    }
                    self.productListArray = newArr!
                }
                DispatchQueue.main.async(execute: { () -> Void in
                self.hideProgress()

                self.shippingStatusTableView.reloadData()
                })
            }  else if result["status"] as! Int == 0 || result["status"] as! Int == -1
            {
                DispatchQueue.main.async(execute: { () -> Void in
                self.hideProgress()
                self.displayAlert("Alert Message", message: result["msg"] as! String)
                self.productListArray.removeAllObjects()
                self.shippingStatusTableView.reloadData()

                })
            }
        }
    }
    
    
    func shippingstatusrefpurchasedproducts(_ pageNumber:NSInteger)
    {
        self.showProgress()
        let body = String(format:"token=%@&pagenumer=%@", UserDefaults.standard.object(forKey: "token") as! String,String(pageNumber))
        
        let task = "shippingstatusrefpurchasedproducts"
        WebService().sendAPIRequest(UrlClass.baseUrl, body: body,task: task) { (result, error) -> Void in
            
            if result["status"] as! Int == 1
            {
                self.totalPage = result ["totalpages"] as! NSInteger

                if(self.currentPage == 1)
                {
                    print("result 0:", result["shippinglist"])
                    
                    let newPageArr = result["shippinglist"] as! NSArray
                    
                    print("result count:", newPageArr.count)
                    
                    let nsMutableArray = NSMutableArray(array: newPageArr)
                    
                    
                    print("result 2:", nsMutableArray)
                    self.productListArray = nsMutableArray
                } else {
                    
                    let newPageArr = result["shippinglist"] as! NSArray
                    
                    let newArr = self.productListArray.mutableCopy() as? NSMutableArray
                    
                    for i in self.productListArray.count ..< self.productListArray.count+newPageArr.count
                    {
                        newArr!.insert(newPageArr[i-self.productListArray.count], at: i)
                    }
                    self.productListArray = newArr!
                }
                DispatchQueue.main.async(execute: { () -> Void in
                self.hideProgress()

                self.shippingStatusTableView.reloadData()
                })
            } else if result["status"] as! Int == 0 || result["status"] as! Int == -1
            {
            DispatchQueue.main.async(execute: { () -> Void in
            self.hideProgress()
            self.displayAlert("Alert Message", message: result["msg"] as! String)
            self.productListArray.removeAllObjects()
            self.shippingStatusTableView.reloadData()

            })
            }
        }
    }
    
    func shippingEliteProducts(_ pageNumber:NSInteger)
    {
        self.showProgress()
        
        let body = String(format:"token=%@&pagenumer=%@", UserDefaults.standard.object(forKey: "token") as! String,String(pageNumber))
        
        let task = "shippingstatusrefpurchasedproducts"
        WebService().sendAPIRequest(UrlClass.baseUrl, body: body,task: task) { (result, error) -> Void in
            
            if result["status"] as! Int == 1
            {
                
                self.totalPage = result ["totalpages"] as! NSInteger
                
                if(self.currentPage == 1)
                {
                    print("result 0:", result["shippinglist"])
                    
                    let newPageArr = result["shippinglist"] as! NSArray
                    
                    print("result count:", newPageArr.count)
                    
                    let nsMutableArray = NSMutableArray(array: newPageArr)
                    
                    
                    print("result 2:", nsMutableArray)
                    self.productListArray = nsMutableArray
                } else {
                    
                    let newPageArr = result["shippinglist"] as! NSArray
                    
                    let newArr = self.productListArray.mutableCopy() as? NSMutableArray
                    
                    for i in self.productListArray.count ..< self.productListArray.count+newPageArr.count
                    {
                        newArr!.insert(newPageArr[i-self.productListArray.count], at: i)
                    }
                    self.productListArray = newArr!
                }
                
                DispatchQueue.main.async(execute: { () -> Void in
                    self.hideProgress()
                    
                    self.shippingStatusTableView.reloadData()
                })
            } else if result["status"] as! Int == 0 || result["status"] as! Int == -1
            {
                DispatchQueue.main.async(execute: { () -> Void in
                    
                    self.hideProgress()
                    self.displayAlert("Alert Message", message: result["msg"] as! String)
                    self.productListArray.removeAllObjects()
                    self.shippingStatusTableView.reloadData()
                    
                })
            }
        }
    }


    @IBAction func dismisspickerView(_ sender: AnyObject)
    {
        maskView.removeFromSuperview()
    }
    
    @IBAction func ChooseCategory(_ sender: AnyObject)
    {
        maskView.removeFromSuperview()
        
        self.currentPage = 1
        
        if Reachability.isConnectedToNetwork() == true {
      
            self.choseCategoryButton.titleLabel?.text = selectedCategory
            
            if selectedCategory == "Sweep Stake Wins"
            {
                shippingStatusSweepStakewins(self.currentPage)
            }
            else if selectedCategory == "Auction Wins"
            {
                shippingStatusAuctionWins(self.currentPage)
            }
            else if selectedCategory == "Purchased Products"
            {
                shippingStatusPurchasedProducts(self.currentPage)
            }
            else if selectedCategory == "Elite Products"
            {
                shippingEliteProducts(self.currentPage)
            }
            
        } else {
            self.displayAlert("Alert Message", message: "Please Check Internet connection")
            
        }

        
            }
    
    func scrollViewDidEndDragging(_ scrollView: UIScrollView, willDecelerate decelerate: Bool) {
        
        let currentOffset = scrollView.contentOffset.y
        
        let maximumOffset = scrollView.contentSize.height - scrollView.frame.size.height
        
        
        if (maximumOffset - currentOffset <= 10)
        {
            if (self.currentPage == totalPage)
            {
                
            } else {
                
                self.currentPage = self.currentPage + 1
                
                switch (selectedCategory! as String)
                {
                case "Sweep Stake Wins":
                shippingStatusSweepStakewins(self.currentPage)
                    
                case "Auction Wins":
                self.shippingStatusAuctionWins(self.currentPage)

                case "Purchased Products":
                shippingstatusrefpurchasedproducts(self.currentPage)
                    
                case "Elite Products":
                shippingEliteProducts(self.currentPage)

                default: break
                }
                
            }
        }
        
    }
    
    
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
