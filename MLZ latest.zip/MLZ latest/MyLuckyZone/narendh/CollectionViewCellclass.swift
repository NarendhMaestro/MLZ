//
//  CollectionViewCellclass.swift
//  MyLuckyzone
//
//  Created by Mastero on 20/11/17.
//  Copyright © 2017 Adodis. All rights reserved.
//

import UIKit

class CollectionViewCellclass: UICollectionViewCell {
    
    @IBOutlet weak var lable: UILabel!
    
    @IBOutlet weak var image: UIImageView!
    
    @IBOutlet weak var starcard: UILabel!
    
    @IBOutlet weak var bidbutton: UIButton!
    
}
