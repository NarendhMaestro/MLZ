//
//  mainpage.swift
//  MyLuckyzone
//
//  Created by Mastero on 20/11/17.
//  Copyright © 2017 Adodis. All rights reserved.
//
//
import UIKit

class mainpage: UIViewController{

//    @IBOutlet var ATableView: UITableView!
//
//    let hearderarry = ["Sweep Takes","Auction","Sales","Platinum","Gold","Silver","Premium Sweep Stakes","Risky"]
//    var storedOffsets = [Int: CGFloat]()
//
//    var model = [[String]]()
//
//
//    override func viewDidLoad() {
//
//        let Sweep_Takes = ["England", "Ireland", "Scotland", "Wales","England", "Ireland", "Scotland", "Wales"]
//        let Auction = ["Canada", "Mexico", "United States","Canada", "Mexico", "United States"]
//        let Sales = ["China", "Japan", "South Korea"]
//        let Platinum = ["England", "Ireland", "Scotland", "Wales","England", "Ireland", "Scotland", "Wales"]
//        let Gold = ["Canada", "Mexico", "United States","Canada", "Mexico", "United States"]
//        let Silver = ["China", "Japan", "South Korea"]
//        let Premium_Sweep_Stakes = ["England", "Ireland", "Scotland", "Wales","England", "Ireland", "Scotland", "Wales"]
//        let Risky = ["Canada", "Mexico", "United States","Canada", "Mexico", "United States"]
//
//
//        model.append(Sweep_Takes)
//        model.append(Auction)
//        model.append(Sales)
//        model.append(Platinum)
//        model.append(Gold)
//        model.append(Silver)
//        model.append(Premium_Sweep_Stakes)
//        model.append(Risky)
//
//        super.viewDidLoad()
//
//        // Do any additional setup after loading the view.
//    }
//
//    override func didReceiveMemoryWarning() {
//        super.didReceiveMemoryWarning()
//        // Dispose of any resources that can be recreated.
//    }
//
//
//    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
//        return model.count
//    }
//
//    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
//        return 200
//    }
//
//    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
//
//        let cell = tableView.dequeueReusableCell(withIdentifier: "celltable", for: indexPath ) as! TableViewCellclass
//
//
//        cell.headerlable.text = hearderarry[indexPath.row]
////
//        return cell
//    }
//
//
//     func tableView(_ tableView: UITableView, willDisplay cell: UITableViewCell, forRowAt indexPath: IndexPath) {
//
//        guard let tableViewCell = cell as? TableViewCellclass else { return }
//
//        tableViewCell.setCollectionViewDataSourceDelegate(self, forRow: indexPath.row)
//        tableViewCell.collectionViewOffset = storedOffsets[indexPath.row] ?? 0
//    }
//
//     func tableView(_ tableView: UITableView, didEndDisplaying cell: UITableViewCell, forRowAt indexPath: IndexPath) {
//
//        guard let tableViewCell = cell as? TableViewCellclass else { return }
//
//        storedOffsets[indexPath.row] = tableViewCell.collectionViewOffset
//    }
//
//
//
//
//}
//
//    extension mainpage:UICollectionViewDelegate,UICollectionViewDataSource {
//
//        func numberOfSections(in collectionView: UICollectionView) -> Int {
//            return 1
//        }
//
//        func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
//            return model[collectionView.tag].count
//        }
//
//        func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
//            let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "cellcollection", for: indexPath) as! CollectionViewCellclass
////            cell.backgroundColor = UIColor.blue
//
//            cell.lable.text = model[collectionView.tag][indexPath.item]
//
//            return cell
//        }
//
    }
    
    

