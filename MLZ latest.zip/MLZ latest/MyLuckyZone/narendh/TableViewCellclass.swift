//
//  TableViewCellclass.swift
//  MyLuckyzone
//
//  Created by Mastero on 20/11/17.
//  Copyright © 2017 Adodis. All rights reserved.
//

import UIKit

class TableViewCellclass: UITableViewCell {

    
    @IBOutlet var collectionoutlet:UICollectionView!
    @IBOutlet weak var headerlable: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
extension TableViewCellclass {
    
    func setCollectionViewDataSourceDelegate<D: UICollectionViewDataSource & UICollectionViewDelegate>(_ dataSourceDelegate: D, forRow row: Int) {
        
        collectionoutlet.delegate = dataSourceDelegate
        collectionoutlet.dataSource = dataSourceDelegate
        collectionoutlet.tag = row
        collectionoutlet.setContentOffset(collectionoutlet.contentOffset, animated:false) // Stops collection view if it was scrolling.
        collectionoutlet.reloadData()
    }
    
    var collectionViewOffset: CGFloat {
        set { collectionoutlet.contentOffset.x = newValue }
        get { return collectionoutlet.contentOffset.x }
    }
}
