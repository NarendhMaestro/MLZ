//
//  UIArgView.m
//  Dinamalar News
//
//  Created by Aravind SCS on 20/09/16.
//  Copyright © 2016 Softcraft Systems & Solutions Private Limited.,. All rights reserved.
//

#import "UIArgView.h"

@implementation UIArgView

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

@synthesize argument1;
@synthesize argument2;

@end
