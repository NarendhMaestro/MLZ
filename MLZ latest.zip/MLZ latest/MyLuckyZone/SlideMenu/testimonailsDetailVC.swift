//
//  testimonailsDetailVC.swift
//  MyLuckyZone
//
//  Created by Maestro_MAC1 on 11/05/17.
//  Copyright © 2017 Adodis. All rights reserved.
//

import UIKit

class testimonailsDetailVC: UIViewController {

    @IBOutlet weak var imgView: UIImageView!
    @IBOutlet weak var lblTitle : UILabel!
    @IBOutlet weak var text : UITextView!
    
    
    public var dictData = NSDictionary()

    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        dictData = UserDefaults.standard.dictionary(forKey: "passedDict") as! NSDictionary
        
        
        print(dictData)
        
        
        if dictData.allKeys.count > 0
        {
            lblTitle.text = dictData["name"] as! String
            lblTitle.font = UIFont.boldSystemFont(ofSize: 18.0)
            lblTitle.numberOfLines = 0
            lblTitle.adjustsFontSizeToFitWidth = true
            
            imgView.layer.cornerRadius = 35.0
            let imStr = String(format: "http://dev.myluckyzone.com/%@", dictData["imgpath"] as! String)
            let fileUrl = NSURL(string: imStr)
            imgView.sd_setImage(with: fileUrl as! URL)
            //imgView.clipsToBounds = true
            
            text.font = UIFont.systemFont(ofSize: 13.0)
            
            let style = NSMutableParagraphStyle()
            style.lineSpacing = 8
            let attributeFontSaySomething = (key: NSFontAttributeName, value:UIFont(name: "HelveticaNeue-Light", size: 17)!)
            let attributeColorSaySomething = (key: NSParagraphStyleAttributeName, value: style)
            
            let attStringSaySomething = NSAttributedString(string: dictData["content"] as! String, attributes: [attributeFontSaySomething.key : attributeFontSaySomething.value,attributeColorSaySomething.key : attributeColorSaySomething.value])
            text.attributedText = attStringSaySomething
        }
        
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
