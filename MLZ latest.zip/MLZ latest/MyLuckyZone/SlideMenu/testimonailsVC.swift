//
//  testimonailsVC.swift
//  MyLuckyZone
//
//  Created by Maestro_MAC1 on 11/05/17.
//  Copyright © 2017 Adodis. All rights reserved.
//

import UIKit
import MediaPlayer



class testimonailsCell: UITableViewCell {
    @IBOutlet weak var lblData: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }
    
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
        
        // Configure the view for the selected state
    }
    
}


class testimonailsVC: UIViewController, UITableViewDelegate,UITableViewDataSource, UIScrollViewDelegate
{
    var moviePlayer:MPMoviePlayerController!
    
    @IBOutlet weak var tableMain: UITableView!
    
    @IBOutlet weak var scroll: UIScrollView!
    
    var arrData = NSArray()
    var dictVideos = NSDictionary()
    var dictToPass = NSDictionary()
    
    let cellReuseIdentifier = "cell"
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        
        
        if Reachability.isConnectedToNetwork() == true {
            let body = String(format:"token=\(UserDefaults.standard.object(forKey: "token") as! String)")
            let task = "listallvideotestimonials"
            WebService().sendAPIRequest(UrlClass.baseUrl, body: body,task: task) { (result, error) -> Void in
                print(result)
                if result["status"] as! Int == 1
                {
                    DispatchQueue.main.async(execute: { () -> Void in
                        self.dictVideos = result as NSDictionary//["testimonialslist"] as! NSArray
                        
                       self.loadVideos()
                    })
                }
            }
        } else {
            self.displayAlert("Alert Message", message: "Please Check Internet connection")
        }
        
        

        self.showProgress()
        if Reachability.isConnectedToNetwork() == true {
            let body = String(format:"token=\(UserDefaults.standard.object(forKey: "token") as! String)")
            
            let task = "listalltexttestimonials"
            WebService().sendAPIRequest(UrlClass.baseUrl, body: body,task: task) { (result, error) -> Void in
                
                print(result)
                if result["status"] as! Int == 1
                {
                    DispatchQueue.main.async(execute: { () -> Void in
                        self.hideProgress()
                        self.arrData = result["testimonialslist"] as! NSArray
                        self.tableMain.reloadData()
                    })
                }
            }
        } else {
            self.displayAlert("Alert Message", message: "Please Check Internet connection")
        }
    }
    
    func loadVideos()
    {
        let arrVideos = dictVideos["testimonialslist"] as! NSArray
        if arrVideos.count > 1
        {
            scroll.delegate = self
            scroll.isScrollEnabled = true
            let scrollWidth:Int = 120
            
         //   scroll.frame = CGRect(x: 0, y: 0, width : self.view.frame.size.width, height: scroll.frame.size.height)
           // scroll.backgroundColor = UIColor.black
            
            var xOffset:Int = 5
            for var i in (0..<arrVideos.count)
            {
                let dictData = arrVideos[i] as! NSDictionary
                
                let viewForCell = UIArgView(frame: CGRect(x: xOffset, y: 0, width : 130, height: Int(scroll.frame.size.height)))
                viewForCell.backgroundColor = UIColor.white
                viewForCell.layer.cornerRadius = 5.0
                viewForCell.clipsToBounds = true
                
                
                viewForCell.layer.borderWidth = 1
                viewForCell.layer.borderColor = UIColor(red:222/255.0, green:225/255.0, blue:227/255.0, alpha: 0.5).cgColor
                
                
//                viewForCell.layer.shadowColor = UIColor.black.cgColor
//                viewForCell.layer.shadowOpacity = 1
//                viewForCell.layer.shadowOffset = CGSize(width : 3, height: 3)
//                viewForCell.layer.shadowRadius = 10
                
                
                
                viewForCell.argument1 = dictData
                
                let tapGesture = UITapGestureRecognizer(target: self, action: #selector(self.videoTapped(_:)))
                viewForCell.addGestureRecognizer(tapGesture)
                
                let img = UIImageView(frame: CGRect(x: 3, y: 3, width : 124, height:Int(scroll.frame.size.height) - 6))
                img.isUserInteractionEnabled = true
                let imStr = String(format: "http://dev.myluckyzone.com/%@", dictData["imgpath"] as! String)
                let fileUrl = NSURL(string: imStr)
                DispatchQueue.global().async {
                    let data = try? Data(contentsOf: fileUrl! as URL)
                    DispatchQueue.main.async {
                        img.image = UIImage(data: data!)
                    }
                }
                
                
                //img.sd_setImage(with: fileUrl as! URL)
                viewForCell.addSubview(img)
                
                
                

               xOffset+=145;
                scroll .addSubview(viewForCell)
            }
            scroll.contentSize = CGSize( width: scrollWidth + xOffset - 60, height: 110);
        }
    }
    
    func videoTapped(_ sender: UITapGestureRecognizer)
    {
        let button = sender.view as! UIArgView
        let result = button.argument1 as! NSDictionary
        
        DispatchQueue.main.async {
            self.hideProgress()
            let screenSize: CGRect = UIScreen.main.bounds
           // let screenWidth = screenSize.width
            //let screenHeight = screenSize.height
            var value = UrlClass.videoURL
            value.append(result["videopath"] as! String)
            //value = "http://dev.myluckyzone.com/images/video/MyLuckyZone_FinalCut.mp4"
            let url:NSURL = NSURL(string: value)!
            
            self.moviePlayer = MPMoviePlayerController(contentURL: url as URL!)
            //self.moviePlayer.view.frame = CGRect(x: 0, y: screenHeight/2, width: screenWidth, height: 150)
            
            self.view.addSubview(self.moviePlayer.view)
            self.moviePlayer.isFullscreen = true
            
            NotificationCenter.default.addObserver(self, selector: #selector(self.exitedFullscreen(notification:)),name: NSNotification.Name.MPMoviePlayerDidExitFullscreen,object: nil)
            self.moviePlayer.controlStyle = MPMovieControlStyle.embedded
        }
    }
    
    @objc func exitedFullscreen(notification: NSNotification){
       self.moviePlayer.stop()
    }
    
    
    
    override func viewWillAppear(_ animated: Bool) {
        
    }
    
    func numberOfSections(in tableView: UITableView) -> Int
    {
        return 1
    }
    
    
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int
    {
        return arrData.count
    }
    
        func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
            return 170
    }
    
//    func calculateHeight(inString:String) -> CGFloat
//    {
//        let messageString = inString
//        let attributes : [String : Any] = [NSFontAttributeName : UIFont.systemFont(ofSize: 15.0)]
//        
//        let attributedString : NSAttributedString = NSAttributedString(string: messageString, attributes: attributes)
//        
//        let rect : CGRect = attributedString.boundingRect(with: CGSize(width: 222.0, height: CGFloat.greatestFiniteMagnitude), options: .usesLineFragmentOrigin, context: nil)
//        
//        let requredSize:CGRect = rect
//        return requredSize.height
//    }
    
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        self.tableMain.register(UITableViewCell.self, forCellReuseIdentifier: "cell")
        
        print(arrData)
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for:indexPath)
        cell.selectionStyle = UITableViewCellSelectionStyle.none
        
        
        let dict = arrData[indexPath.row] as! NSDictionary
        
        
        
        let view = UIView(frame: CGRect(x: 5 , y: 10 , width : self.view.frame.size.width-10, height : 150))
        view.layer.cornerRadius = 5.0
        view.clipsToBounds = true
        view.layer.borderColor = UIColor.lightGray.cgColor
        view.layer.borderWidth = 0.3
        view.layer.shadowOffset = CGSize(width : 0, height : 3)
        cell.addSubview(view)
        
        
        
        let lblTitle = UILabel(frame: CGRect(x: 40 , y: 20 , width : self.view.frame.size.width-60, height : 50))
        lblTitle.text = dict["name"] as! String
        lblTitle.font = UIFont.boldSystemFont(ofSize: 15.0)
        lblTitle.numberOfLines = 0
        lblTitle.adjustsFontSizeToFitWidth = true
        view.addSubview(lblTitle)
        
        let img = UIImageView(frame: CGRect(x: 40 , y: 70 , width : 70, height : 70))
        img.layer.cornerRadius = 35.0
       // let imStr = "http://dev.myluckyzone.com/\dict["imgpath"]"
        
        let imStr = String(format: "http://dev.myluckyzone.com/%@", dict["imgpath"] as! String)
        
        let fileUrl = NSURL(string: imStr)
        img.sd_setImage(with: fileUrl as! URL)
        img.clipsToBounds = true
        view.addSubview(img)
        
        
        let lblContents = UILabel(frame: CGRect(x: 150 , y: 40 , width : self.view.frame.size.width-170, height : 100))
        lblContents.text = dict["content"] as! String
        lblContents.numberOfLines = 3
        lblContents.font = UIFont.systemFont(ofSize: 13.0)
        view.addSubview(lblContents)
        
        
        let btn = UIButton(frame: CGRect(x: view.frame.size.width-90, y: view.frame.size.height-25 , width : 80, height : 20))
        btn.addTarget(self, action:#selector(handleMore(sender:)), for: .touchUpInside)
        btn.tag = indexPath.row
        btn.titleLabel?.font = UIFont.systemFont(ofSize: 12.0)
        btn.backgroundColor = UIColor.init(red: 174/255, green: 47/255, blue: 61/255, alpha: 1.0)
        btn.setTitle("VIEW MORE", for:UIControlState.normal)
        view.addSubview(btn)
        
        
         cell.addSubview(view)
        
        return cell
    }
    
    @IBAction func handleMore(sender: AnyObject)
    {
        let button = sender as! UIButton
        let index = button.tag
        dictToPass = arrData[index] as! NSDictionary
        
        
        UserDefaults.standard.set(dictToPass, forKey: "passedDict")
        
        
         self.performSegue(withIdentifier: "testimonailsDetail", sender: nil)
        
        
//        DispatchQueue.main.async(execute: { () -> Void in
//           
//        })
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        tableView.deselectRow(at: indexPath, animated: false)
        dictToPass = arrData[indexPath.row] as! NSDictionary
        UserDefaults.standard.set(dictToPass, forKey: "passedDict")
        self.performSegue(withIdentifier: "testimonailsDetail", sender: nil)
    }
    
    
    func prepareForSegue(segue: UIStoryboardSegue!, sender: AnyObject!)
    {
        if (segue.identifier == "testimonailsDetail") {
            let detailVC = segue!.destination as! testimonailsDetailVC;
            detailVC.dictData = dictToPass
        }
    }

    
       func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        return 1.0
    }
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {

        let viewHeader = UILabel(frame: CGRect(x:0, y:0, width:self.view.frame.size.width, height:0))
        //viewHeader.textColor = UIColor.red
       // viewHeader.text = "title \(section)"
        return viewHeader;
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

   
}
