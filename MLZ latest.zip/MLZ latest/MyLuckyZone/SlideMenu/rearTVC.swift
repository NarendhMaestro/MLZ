//
//  rearTVC.swift
//  MyLuckyZone
//
//  Created by G.Abhisek on 19/05/16.
//  Copyright © 2016 Adodis. All rights reserved.
//

import UIKit

class rearTVC: UITableViewCell {

    
    @IBOutlet weak var logoImge: UIImageView!
    @IBOutlet weak var titleLabel: UILabel!
    
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
