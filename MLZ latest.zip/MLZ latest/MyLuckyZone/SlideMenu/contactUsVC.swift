//
//  contactUsVC.swift
//  MyLuckyZone
//
//  Created by Adodis on 26/05/16.
//  Copyright © 2016 Adodis. All rights reserved.
//

import UIKit

class contactUsVC: UIViewController , UITextFieldDelegate {

    @IBOutlet var usernameTxtFld: UITextField!
    @IBOutlet var emailTxtFld: UITextField!
    @IBOutlet var subjectTxtFld: UITextField!
    @IBOutlet var messageTxtFld: UITextField!
    var activeTextField = UITextField()

    
    @IBOutlet weak var theScrollView: UIScrollView!
    

    override func viewDidLoad() {
        super.viewDidLoad()
        
        let tap: UITapGestureRecognizer = UITapGestureRecognizer(target: self, action: #selector(contactUsVC.dismissKeyboard))
        view.addGestureRecognizer(tap)
        // Do any additional setup after loading the view.
        
        NotificationCenter.default.addObserver(self, selector: #selector(contactUsVC.keyboardWasShown(_:)), name: NSNotification.Name.UIKeyboardWillShow, object: nil)
        
        NotificationCenter.default.addObserver(self, selector: #selector(contactUsVC.keyboardWillBeHidden(_:)), name: NSNotification.Name.UIKeyboardWillHide, object: nil)
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    override func viewWillAppear(_ animated: Bool)
    {
        
    }
    
    func dismissKeyboard()
    {
        view.endEditing(true)
    }

    
    @IBAction func submit(_ sender: AnyObject)
    {
        
        dismissKeyboard()
        
        if Reachability.isConnectedToNetwork() == true {
            if (self.usernameTxtFld.text == ""  || self.emailTxtFld.text == "" || subjectTxtFld.text == "" || self.messageTxtFld.text == "")
            {
                
                self.displayAlert("Alert Message", message: "Please enter all fields")
                
            }else {
                
                self.showProgress()
                
                let body = String(format:"name=%@&emailid=%@&subject=%@&message=%@", self.usernameTxtFld.text!,self.emailTxtFld.text!,self.subjectTxtFld.text!,self.messageTxtFld.text!)
                
                let task = "contactus"
                WebService().sendAPIRequest(UrlClass.baseUrl, body: body,task: task) { (result, error) -> Void in
                    
                    if result["status"] as! Int == 1
                    {
                        self.usernameTxtFld.text = ""
                        self.emailTxtFld.text = ""
                        self.messageTxtFld.text = ""
                        self.subjectTxtFld.text = ""
                        DispatchQueue.main.async(execute: { () -> Void in
                            self.hideProgress()
                            self.displayAlert("Alert Message", message: result["msg"] as! String)
                        })
                    } else if result["status"] as! Int == 0  || result["status"] as! Int == -1
                    {
                        DispatchQueue.main.async(execute: { () -> Void in
                            self.hideProgress()
                            
                            self.displayAlert("Alert Message", message: result["msg"] as! String)
                        })
                    }
                }
            }
        } else {
            self.displayAlert("Alert Message", message: "Please Check Internet connection")
        }
            }
    
//    
//        func displayAlert(title: String, message: String) {
//            let alertController = UIAlertController(title: title, message: message, preferredStyle: .Alert)
//            alertController.addAction(UIAlertAction(title: "OK", style: .Default, handler: nil))
//            presentViewController(alertController, animated: true, completion: nil)
//            return
//        }
    
    
    
    
    func keyboardWasShown(_ notification: Notification) {
        // Step 1: Get the size of the keyboard.
        let info : NSDictionary = (notification as NSNotification).userInfo! as NSDictionary
//        let keyboardSize = ((info.object(forKey: UIKeyboardFrameBeginUserInfoKey) as AnyObject).cgRectValue as CGRect!).size
        let keyboardSize = (info[UIKeyboardFrameBeginUserInfoKey] as? NSValue)!.cgRectValue
        // Step 2: Adjust the bottom content inset of your scroll view by the keyboard height.
        let contentInsets: UIEdgeInsets = UIEdgeInsetsMake(0.0, 0.0, keyboardSize.height, 0.0)
        self.theScrollView.contentInset = contentInsets
        self.theScrollView.scrollIndicatorInsets = contentInsets
        // Step 3: Scroll the target text field into view.
        var aRect: CGRect = self.view.frame
        aRect.size.height -= keyboardSize.height
        if !aRect.contains(activeTextField.frame.origin)
        {
            let scrollPoint: CGPoint = CGPoint(x: 0.0, y: activeTextField.frame.origin.y - (keyboardSize.height - 15))
            self.theScrollView.setContentOffset(scrollPoint, animated: true)
        }
    }
    
    func keyboardWillBeHidden(_ notification: Notification) {
        let contentInsets: UIEdgeInsets = UIEdgeInsets.zero
        self.theScrollView.contentInset = contentInsets
        self.theScrollView.scrollIndicatorInsets = contentInsets
    }
    
    
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool
    {
        return textField.resignFirstResponder()
    }
    
    
    override func viewWillDisappear(_ animated: Bool)
    {
        NotificationCenter.default.removeObserver(self, name: NSNotification.Name.UIKeyboardDidHide, object: nil)
        NotificationCenter.default.removeObserver(self, name: NSNotification.Name.UIKeyboardWillHide, object: nil)
    }
    


    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
