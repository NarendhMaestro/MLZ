//
//  UIArgView.h
//  Dinamalar News
//
//  Created by Aravind SCS on 20/09/16.
//  Copyright © 2016 Softcraft Systems & Solutions Private Limited.,. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIArgView : UIView
{
    id argument1;
    id argument2;
}

@property (nonatomic, retain) id argument1;
@property (nonatomic, retain) id argument2;

@end
