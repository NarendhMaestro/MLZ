//
//  RedeemVC.swift
//  MyLuckyZone
//
//  Created by Adodis on 27/05/16.
//  Copyright © 2016 Adodis. All rights reserved.
//

import UIKit

class RedeemVC: UIViewController ,UITextFieldDelegate {

    @IBOutlet var theCouponTextField: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool
    {
        return textField.resignFirstResponder()
    }
    
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(true)
    }
    
    
    @IBAction func submit(_ sender: AnyObject) {
        
        if Reachability.isConnectedToNetwork() == true {
            if (self.theCouponTextField.text == "" )
            {
                self.displayAlert("Alert Message", message: "Please Enter Redeem Coupon code")
                
            }else {
                
                self.showProgress()
                
                let body = String(format:"token=%@&couponcode=%@", UserDefaults.standard.object(forKey: "token") as! String,self.theCouponTextField.text!)
                
                let task = "redeemcouponcode"
                WebService().sendAPIRequest(UrlClass.baseUrl, body: body,task: task) { (result, error) -> Void in
                    DispatchQueue.main.async(execute: { () -> Void in
                        self.hideProgress()
                        self.displayAlert("Alert Message", message: (result["msg"] as? String)!)
                    })
                }
            }
        } else {
            self.displayAlert("Alert Message", message: "Please Check Internet connection")
        }

        
           }
    
    
//    func displayAlert(title: String, message: String) {
//     let alertController = UIAlertController(title: title, message: message, preferredStyle: .Alert)
//        alertController.addAction(UIAlertAction(title: "OK", style: .Default, handler: nil))
//        presentViewController(alertController, animated: true, completion: nil)
//        }


    
        /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
