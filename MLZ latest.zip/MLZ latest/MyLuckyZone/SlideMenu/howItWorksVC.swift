//
//  howItWorksVC.swift
//  MyLuckyZone
//
//  Created by Adodis on 26/05/16.
//  Copyright © 2016 Adodis. All rights reserved.
//

import UIKit

class howItWorksVC: UIViewController ,UIWebViewDelegate  {

    
    @IBOutlet weak var theWebView: UIWebView!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
    }
    

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(true)
        
        
        if Reachability.isConnectedToNetwork() == true {
        self.howWorkIt()
        } else {
        self.displayAlert("Alert Message", message: "Please Check Internet connection")
        }
    }
    
    
    
    func howWorkIt()
    {
        self.showProgress()

        let body = ""
        
        let task = "howitworks"
        WebService().sendAPIRequest(UrlClass.baseUrl, body: body,task: task) { (result, error) -> Void in
            
            if result["status"] as! Int == 1
           {
            DispatchQueue.main.async(execute: {
                
                let urlString = String(format: "%@/%@", WebService.sharedInstance.getBaseURL, (result["path"] as? String)!)
                
                let url : URL! = URL(string: urlString)
                
                self.self.theWebView.loadRequest(URLRequest(url: url))
            });
            
            
            
            } else if result["status"] as! Int == 0 || result["status"] as! Int == -1
            {
            self.displayAlert("Alert Message", message: result["msg"] as! String)

            }

        }
    }
    
    
   func webViewDidStartLoad(_ webView: UIWebView)
   {
    

    
    }
    func webViewDidFinishLoad(_ webView: UIWebView)
    {
        
        DispatchQueue.main.async(execute: {
            
            self.hideProgress()
            
        });
        
    }
    func webView(_ webView: UIWebView, didFailLoadWithError error: Error)
    {
        self.displayAlert("Alert Message", message: error.localizedDescription)

    }
    
    
   

    
    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        
            }
    
            /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}

 
