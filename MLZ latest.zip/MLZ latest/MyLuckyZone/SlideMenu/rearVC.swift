//
//  rearVC.swift
//  MyLuckyZone
//
//  Created by G.Abhisek on 19/05/16.
//  Copyright © 2016 Adodis. All rights reserved.
//

import UIKit

class rearVC: UIViewController
{

//       @IBOutlet weak var rearTableView: UITableView!
    var tableDataArray = NSMutableArray()
    var storyBoardIdArray:[String]!
    
    
    override func viewDidLoad()
    {
        super.viewDidLoad()
//        rearTableView.separatorStyle = .none
        
        
        // Do any additional setup after loading the view.
    }
    
    override func viewWillAppear(_ animated: Bool)
    {
        //create a table data array comprising each cell's logo,title & corresponding VC's Storyboard ID
        
        tableDataArray = [["image":"dashboard_icon","title":"DASHBOARD","storyBoardId":"dashboardVC"],["image":"profile_icon","title":"MY PROFILE","storyBoardId":"profileVC"],["image":"chg_pass_icon","title":"CHANGE PASSWORD","storyBoardId":"changePasswordVC"],["image":"contact_icon","title":"CONTACT US","storyBoardId":"contactUsVC"],["image":"howit_icon","title":"HOW IT WORKS","storyBoardId":"howItWorksVC"],["image":"redeem_icon","title":"REDEEM COUPON","storyBoardId":"RedeemVC"],
            ["image":"forum","title":"FORUM","storyBoardId":"ForumVC"],
            ["image":"testimonial","title":"TESTIMONAILS","storyBoardId":"testimonialsVC"],//testimonails
            ["image":"chat_menu","title":"CHAT","storyBoardId":"chatVC"],//chat
            ["image":"video_folder","title":"VIDEO","storyBoardId":"VideoVC"],
            ["image":"howit_icon","title":"FAQ"]
        ]
        
//        self.rearTableView.backgroundColor = UIColor.black
       
    }

    override func didReceiveMemoryWarning()
    {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
//    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int
//    {
//        return tableDataArray.count+1
//    }
//
//
//    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell
//    {
//
//        if (indexPath as NSIndexPath).row == 0
//        {
//            let cell = rearTableView.dequeueReusableCell(withIdentifier: "emptyCell", for: indexPath)
//            cell.selectionStyle = .none
//
//            return cell
//
//        }
//        else
//        {
//            let cell = rearTableView.dequeueReusableCell(withIdentifier: "contentCell", for: indexPath) as! rearTVC
//
//            cell.selectionStyle = .none
//
//            cell.titleLabel.text = (tableDataArray[(indexPath as NSIndexPath).row-1] as AnyObject).value(forKey: "title") as? String
//
//            cell.logoImge.image = UIImage(named: ((tableDataArray[(indexPath as NSIndexPath).row-1] as AnyObject).value(forKey: "image") as? String)!)
//            return cell
//        }
//
//
//    }
    
//    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath)
//    {
//        if (indexPath as NSIndexPath).row != 0
//        {
//            if (indexPath as NSIndexPath).row == 11 {
//                let result = WebService.sharedInstance.getProfile()
//                if(result != nil) {
////                    let profile = result!["profile"] as? NSDictionary
////                    let country = profile!["country"] as? String
//                    var url : String?
//
////                    if country == nil || country?.characters.count == 0 {
////                        let bundleID = NSBundle.mainBundle().bundleIdentifier?.lowercaseString
////                        var range = bundleID?.rangeOfString("usa")
////                        if range != nil {
////                            url = "https://myluckyzone.com/usa/site/faqm"
////                        } else {
////                            range = bundleID?.rangeOfString("ngr")
////                            if range != nil {
////                                url = "https://myluckyzone.com/ngr/site/faqm"
////                            } else {
////                                url = "https://myluckyzone.com/usa/site/faqm"
////                            }
////                        }
////                    } else if country == "dev" {
////                        url = "https://dev.myluckyzone.com/site/faqm"
////                    } else {
////                        url = "https://myluckyzone.com/" + country! + "/site/faqm"
////                    }
//
//                    let bundleID = Bundle.main.bundleIdentifier?.lowercased()
//                    var range = bundleID?.range(of: "usa")
//                    if range != nil {
//                        url = "https://myluckyzone.com/usa/site/faqm"
//                    } else {
//                        range = bundleID?.range(of: "ngr")
//                        if range != nil {
//                            url = "https://myluckyzone.com/ngr/site/faqm"
//                        } else {
//                            url = "https://myluckyzone.com/usa/site/faqm"
//                        }
//                    }
//
//
//                    UIApplication.shared.openURL(URL(string: url!)!)
//                    self.performSegue(withIdentifier: "revealVCPush", sender: self)
//                }
//            }else if (indexPath as NSIndexPath).row == 8
//            {
//                let identifier = "testimonailsVC"// (tableDataArray[indexPath.row - 1] as! NSDictionary).value(forKey: "storyBoardId") as! String
//                let viewTosend: [String:String] = ["storyboardidentifier": identifier, "senderTag":"rearVC"]
//                UserDefaults.standard.set(viewTosend, forKey: "slideMenuView")
//                self.performSegue(withIdentifier: "revealVCPush", sender: self)
//
//            }
//            else if (indexPath as NSIndexPath).row == 9 //CHAT
//            {
//                let identifier = "ChatListVC"// (tableDataArray[indexPath.row - 1] as! NSDictionary).value(forKey: "storyBoardId") as! String
//                let viewTosend: [String:String] = ["storyboardidentifier": identifier, "senderTag":"rearVC"]
//                UserDefaults.standard.set(viewTosend, forKey: "slideMenuView")
//                self.performSegue(withIdentifier: "revealVCPush", sender: self)
//            }
//            else {
//                let identifier = (tableDataArray[indexPath.row - 1] as! NSDictionary).value(forKey: "storyBoardId") as! String
//                let viewTosend: [String:String] = ["storyboardidentifier": identifier, "senderTag":"rearVC"]
//                UserDefaults.standard.set(viewTosend, forKey: "slideMenuView")
//                self.performSegue(withIdentifier: "revealVCPush", sender: self)
//            }
//        }
//    }
//
    
    @IBAction func logout(_ sender: AnyObject) {
        self.logout()
    }
    
    
    
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
