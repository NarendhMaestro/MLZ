//
//  profileVC.swift
//  zoomInZoomOut
//
//  Created by G.Abhisek on 27/05/16.
//  Copyright © 2016 Adodis. All rights reserved.
//

import UIKit
fileprivate func < <T : Comparable>(lhs: T?, rhs: T?) -> Bool {
    switch (lhs, rhs) {
    case let (l?, r?):
        return l < r
    case (nil, _?):
        return true
    default:
        return false
    }
}

fileprivate func > <T : Comparable>(lhs: T?, rhs: T?) -> Bool {
    switch (lhs, rhs) {
    case let (l?, r?):
        return l > r
    default:
        return rhs < lhs
    }
}


class profileVC: UIViewController,UITextFieldDelegate,UIPickerViewDataSource,UIPickerViewDelegate,UIScrollViewDelegate
{
    
    @IBOutlet weak var theScrollView: UIScrollView!
    
    @IBOutlet var textFieldPickerView: UIPickerView!
    
    @IBOutlet var textFieldView: UIView!
    
    @IBOutlet var maleButton: UIButton!
    
    @IBOutlet var femaleButton: UIButton!
    @IBOutlet weak var firstNameTxtFld: UITextField!
    @IBOutlet weak var lastNameTxtFld: UITextField!
    @IBOutlet weak var dateTxtFld: UITextField!
    @IBOutlet weak var monthTxtFld: UITextField!
    @IBOutlet weak var yearTxtFld: UITextField!
    @IBOutlet weak var mobileNumberTxtFld: UITextField!
    //@IBOutlet weak var alternativeMobNumbrTxtFld: UITextField!
    @IBOutlet weak var professionTxtFld: UITextField!
    @IBOutlet weak var addressTxtFld: UITextField!
    @IBOutlet weak var cityTxtFld: UITextField!
    @IBOutlet weak var stateTxtFld: UITextField!
   // @IBOutlet weak var countryTxtFld: UITextField!
    @IBOutlet weak var postalCodeTxtFld: UITextField!
    var activeTextField = UITextField()
    
    @IBOutlet weak var viewScroll: UIView!
    @IBOutlet var referrerTextField: UITextField!
    @IBOutlet var referrerDetailsView: UIView!
    @IBOutlet var enterReferrerDeatailsHeight: NSLayoutConstraint!
    
    @IBOutlet var referrerDetailsHeight: NSLayoutConstraint!
    @IBOutlet var referrerMailId: UILabel!
    @IBOutlet var referrerName: UILabel!
    @IBOutlet var enterReferrerDetailsView: UIView!
    var stateArray = NSArray()
    var pickerViewDataArray = NSMutableArray()
    var TextFieldTag:String!
    var pickerViewSelectedText:String!
    
    @IBOutlet var updateTopConstraint: NSLayoutConstraint!
    var genderSelected:String!
    
    
    override func viewDidLoad()
    {
        super.viewDidLoad()
        
        dateTxtFld.inputView = textFieldView
        monthTxtFld.inputView = textFieldView
        stateTxtFld.inputView = textFieldView
        yearTxtFld.inputView = textFieldView
        // Do any additional setup after loading the view.
        
        //theScrollView.contentSize = UIView(frame: CGRectMake(0, 0, 400, 2300))
        //theScrollView.contentSize.width = self.view.frame.width
        // theScrollView.contentSize.height = 1350+1350
        //
        theScrollView.delegate = self
        
        NotificationCenter.default.addObserver(self, selector: #selector(profileVC.keyboardWasShown(_:)), name: NSNotification.Name.UIKeyboardWillShow, object: nil)
        
        NotificationCenter.default.addObserver(self, selector: #selector(profileVC.keyboardWillBeHidden(_:)), name: NSNotification.Name.UIKeyboardWillHide, object: nil)
        
        
        
        
    }
    
    override func didReceiveMemoryWarning()
    {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
    func getmyprofile(){
        DispatchQueue.main.async(execute: { () -> Void in
        self.showProgress()
        })
        
        if Reachability.isConnectedToNetwork() == true {
            let body = String(format:"token=\(UserDefaults.standard.object(forKey: "token") as! String)")
            
            let task = "getmyprofile"
            WebService().sendAPIRequest(UrlClass.baseUrl, body: body,task: task) { (result, error) -> Void in
                print(result)
                if result["status"] as! Int == 1
                {
                    DispatchQueue.main.async(execute: { () -> Void in
                        self.hideProgress()
                        self.firstNameTxtFld.text = (result["profile"] as? NSDictionary)!.value(forKey: "firstname") as? String
                        self.lastNameTxtFld.text = (result["profile"] as? NSDictionary)!.value(forKey: "lastname") as? String
                        self.addressTxtFld.text = (result["profile"] as? NSDictionary)!.value(forKey: "address") as? String
                        // self.alternativeMobNumbrTxtFld.text = (result["profile"] as? NSDictionary)!.value(forKey: "altphone") as? String
                        self.dateTxtFld.text = (result["profile"] as? NSDictionary)!.value(forKey: "birthdate") as? String
                        self.monthTxtFld.text = (result["profile"] as? NSDictionary)!.value(forKey: "birthmonth") as? String
                        self.yearTxtFld.text = (result["profile"] as? NSDictionary)!.value(forKey: "birthyear") as? String
                        self.cityTxtFld.text = (result["profile"] as? NSDictionary)!.value(forKey: "city") as? String
                        //self.countryTxtFld.text = (result["profile"] as? NSDictionary)!.value(forKey: "country") as? String
                        
                        //Checking Valid Mobile Number or not
                        let mobileNubr = (result["profile"] as? NSDictionary)!.value(forKey: "mobile") as? String
                        self.mobileNumberTxtFld.text = mobileNubr
                        
                        let bundleID = Bundle.main.bundleIdentifier?.lowercased()
                        var appName = 11
                        let range = bundleID?.range(of: "usa")
                        if range != nil {
                            appName = 10
                        }
                        
                        self.view.viewWithTag(212)?.removeFromSuperview()
                        self.mobileNumberTxtFld.isEnabled = true
                        
                        if mobileNubr?.characters.count == Int(appName)
                        {
                            self.mobileNumberTxtFld.isEnabled = false
                            
                            let btnChangeRequest = UIButton(frame : CGRect(x: self.view.frame.size.width - 90, y:self.mobileNumberTxtFld.frame.origin.y - 20, width: 60, height:40))
                            btnChangeRequest.tag = 212
                            btnChangeRequest.addTarget(self, action: #selector(profileVC.changeMobileNubrRequest(_:)), for:.touchUpInside)
                            btnChangeRequest.backgroundColor = UIColor.init(colorLiteralRed: 156.0/255.0, green: 27.0/255.0, blue: 47.0/255.0, alpha: 1.0)
                            btnChangeRequest.titleLabel?.numberOfLines = 0;
                            btnChangeRequest.titleLabel?.font = UIFont.systemFont(ofSize: 12.0)
                            btnChangeRequest.titleLabel?.adjustsFontSizeToFitWidth = true
                            btnChangeRequest.titleLabel?.lineBreakMode = NSLineBreakMode.byWordWrapping
                            
                            btnChangeRequest.layer.cornerRadius = 3.0
                            btnChangeRequest.clipsToBounds = true
                            
                            
                            btnChangeRequest.setTitle("Change\nNumber", for:UIControlState.normal)
                            self.viewScroll.addSubview(btnChangeRequest)
                        }
                        
                        self.professionTxtFld.text = (result["profile"] as? NSDictionary)!.value(forKey: "profession") as? String
                        self.stateTxtFld.text = (result["profile"] as? NSDictionary)!.value(forKey: "state") as? String
                        self.postalCodeTxtFld.text = (result["profile"] as? NSDictionary)!.value(forKey: "zipcode") as? String
                        self.dateTxtFld.text = (result["profile"] as? NSDictionary)!.value(forKey: "birthdate") as? String
                        self.monthTxtFld.text = (result["profile"] as? NSDictionary)!.value(forKey: "birthmonth") as? String
                       // self.countryTxtFld.text = "USA"
                        
                        if (result["profile"] as? NSDictionary)!.value(forKey: "gender") as? String == "1"
                        {
                            self.genderSelected = "1"
                            self.maleButton.setImage(UIImage(named: "radioButton_Selected"), for: UIControlState())
                            self.femaleButton.setImage(UIImage(named: "radioButton_unSelected"), for: UIControlState())
                        }
                        else
                        {
                            self.genderSelected = "2"
                            self.femaleButton.setImage(UIImage(named: "radioButton_Selected"), for: UIControlState())
                            self.maleButton.setImage(UIImage(named: "radioButton_unSelected"), for: UIControlState())
                        }
                        
                        var referrername = (result["profile"] as? NSDictionary)!.value(forKey: "referrername") as? String
                        
                        if referrername?.characters.count > 0 {
                            self.enterReferrerDetailsView.isHidden = true
                            //  self.enterReferrerDeatailsHeight.constant = 0
                            self.referrerDetailsView.isHidden = false
                            self.referrerName.text = "Referrer : \(referrername!)"
                        } else {
                            //                            self.referrerDetailsView.isHidden = true
                            //                            self.referrerDetailsHeight.constant = 0
                            //                            self.enterReferrerDetailsView.isHidden = false
                        }
                    })
                }
            }
            getStatesArray()
        } else {
            self.displayAlert("Alert Message", message: "Please Check Internet connection")
            
        }
    }
    
    override func viewWillAppear(_ animated: Bool)
    {
        self.getmyprofile()
    }
    
    func getStatesArray()
    {
        let body = String(format:"token=\(UserDefaults.standard.object(forKey: "token") as! String)")
        
        let task = "listallstates"
        WebService().sendAPIRequest(UrlClass.baseUrl, body: body,task: task) { (result, error) -> Void in
            
            if result["status"] as! Int == 1
            {
                self.stateArray = result["statelist"] as! NSArray
            }
        }
    }
    
    func textFieldDidBeginEditing(_ textField: UITextField)
    {
        if textField == dateTxtFld
        {
            let dateArray = NSMutableArray()
            
            for i in 0...31
            {
                dateArray.insert(String(i), at:i)
            }
            dateArray.removeObject(at: 0)
            
            print(dateArray)
            
            pickerViewDataArray = dateArray
            
            TextFieldTag = "dateTxtFld"
        }
        else if textField == monthTxtFld
        {
            pickerViewDataArray = ["JAN","FEB","MAR","APR","MAY","JUN","JUL","AUG","SEP","OCT","NOV","DEC"]
            TextFieldTag = "monthTxtFld"
        }
        else if textField == stateTxtFld
        {
            pickerViewDataArray = stateArray.mutableCopy() as! NSMutableArray
            
            TextFieldTag = "stateTxtFld"
        }else if textField == yearTxtFld
        {
            let yearArray = NSMutableArray()
            
            //            let formatter = DateFormatter()
            //            formatter.dateFormat = "yyyy/MM/dd HH:mm"
            //            let someDateTime_ = formatter.date(from: "2015/10/26 18:31")
            //            let DATE = someDateTime_?.description
            //            let getYear_ = DATE?.index((DATE?.startIndex)!,offsetBy: 4)
            //            let getYear = DATE?.substring(to: getYear_!)
            
            
            let date = NSDate()
            let calendar = NSCalendar.current
            let components = calendar.dateComponents([.year, .month, .day, .hour, .minute], from: date as Date)
            
            let year =  components.year
            let month = components.month
            let day = components.day
            
            
            //dateArray = [NSMutableArray arrayWithCapacity: 6];
            
            
            for i in (1950...Int(year!)).reversed()
            {
                
                yearArray.add(String(i))
                //yearArray.insert(String(i), at:i)
            }
            yearArray.removeObject(at: 0)
            
            print(yearArray)
            
            pickerViewDataArray = yearArray
            
            TextFieldTag = "yearTxtFld"
        }
        textFieldPickerView.reloadAllComponents()
    }
    
    //MARK:Pickerview data source methods
    func numberOfComponents(in pickerView: UIPickerView) -> Int
    {
        return 1
    }
    
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int
    {
        return pickerViewDataArray.count
    }
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String?
    {
        return pickerViewDataArray[row] as? String
    }
    
    //PickerView delegate method
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int)
    {
        pickerViewSelectedText = pickerViewDataArray[row] as? String
    }
    
    
    @IBAction func changeMobileNubrRequest(_ sender: AnyObject)
    {
        performSegue(withIdentifier:"ChangeNumber", sender: nil)
    }
    
    @IBAction func cancelButton(_ sender: AnyObject)
    {
        self.view.endEditing(true)
    }
    
    @IBAction func OkButton(_ sender: AnyObject)
    {
        if TextFieldTag == "dateTxtFld"
        {
            dateTxtFld.text = pickerViewSelectedText
            dateTxtFld.resignFirstResponder()
        }
        else if TextFieldTag == "monthTxtFld"
        {
            monthTxtFld.text = pickerViewSelectedText
            monthTxtFld.resignFirstResponder()
        }
        else if TextFieldTag == "stateTxtFld"
        {
            stateTxtFld.text = pickerViewSelectedText
            stateTxtFld.resignFirstResponder()
        }else if TextFieldTag == "yearTxtFld"
        {
            yearTxtFld.text = pickerViewSelectedText
            yearTxtFld.resignFirstResponder()
        }
    }
    
    @IBAction func selectMaleGender(_ sender: AnyObject)
    {
        genderSelected = "1"
        
        self.maleButton.setImage(UIImage(named: "radioButton_Selected"), for: UIControlState())
        self.femaleButton.setImage(UIImage(named: "radioButton_unSelected"), for: UIControlState())
    }
    
    @IBAction func selectFemaleGender(_ sender: AnyObject)
    {
        genderSelected = "2"
        self.femaleButton.setImage(UIImage(named: "radioButton_Selected"), for: UIControlState())
        
        self.maleButton.setImage(UIImage(named: "radioButton_unSelected"), for: UIControlState())
    }
    
    
    @IBAction func updateProfile(_ sender: AnyObject)
    {
        if Reachability.isConnectedToNetwork() == true {
            DispatchQueue.main.async(execute: { () -> Void in
            self.showProgress()
            })
            
            genderSelected = genderSelected.replacingOccurrences(of: "(", with: "")
            genderSelected = genderSelected.replacingOccurrences(of: ")", with: "")
            genderSelected = genderSelected.replacingOccurrences(of: "Optional", with: "")
            
            
            let bundleID = Bundle.main.bundleIdentifier?.lowercased()
            var appName = "Nigiria"
            let range = bundleID?.range(of: "usa")
            if range != nil {
                appName = "USA"
            }
            
            var strAlert = ""
            
            
            if firstNameTxtFld.text != "" {
                if lastNameTxtFld.text != "" {
                    if yearTxtFld.text != "" {
                        if monthTxtFld.text != "" {
                            if cityTxtFld.text != "" {
                                if stateTxtFld.text != "" {
                                    if postalCodeTxtFld.text != "" {
                                        if mobileNumberTxtFld.text != "" {
                                            
                                            let body = String(format:"token=\(UserDefaults.standard.object(forKey: "token") as! String)&firstname=\(firstNameTxtFld.text!)&lastname=\(lastNameTxtFld.text!)&gender=\(genderSelected!)&birthdate=\(dateTxtFld.text!)&birthmonth=\(monthTxtFld.text!)&birthyear=\(yearTxtFld.text!)&mobile=\(mobileNumberTxtFld.text!)&profession=\(professionTxtFld.text!)&address=\(addressTxtFld.text!)&city=\(cityTxtFld.text!)&state=\(stateTxtFld.text!)&zipcode=\(postalCodeTxtFld.text!)&referreremail=\(referrerTextField.text!)&country=%@", appName)
                                            let task = "updatemyprofile"
                                            WebService().sendAPIRequest(UrlClass.baseUrl, body: body,task: task) { (result, error) -> Void in
                                                
                                                if result["status"] as! Int == 1
                                                {
                                                    DispatchQueue.main.async(execute: { () -> Void in
                                                        self.hideProgress()
                                                        self.displayAlert("Alert Message", message: (result["msg"] as? String)!)
                                                        
                                                        self.theScrollView.setContentOffset(CGPoint.zero, animated: true)
                                                    })
                                                } else if result["status"] as! Int == 0 || result["status"] as! Int == -1
                                                {
                                                    DispatchQueue.main.async(execute: { () -> Void in
                                                        self.hideProgress()
                                                        self.displayAlert("Alert Message", message: (result["msg"] as? String)!)
                                                    })
                                                }
                                                self.getmyprofile()
                                            }
                                        }else{strAlert = "Mobile Number"}
                                    }else{strAlert = "Postal Code"}
                                }else{strAlert = "State"}
                            }else{strAlert = "City"}
                        }else{strAlert = "Birth Month"}
                    }else{strAlert = "Birth Year"}
                }else{strAlert = "Last Name"}
            }else{strAlert = "First Name"}
            if strAlert != ""{
                self.displayAlert("Alert Message", message: String(format:"%@ is Missing", strAlert))
            }
            DispatchQueue.main.async(execute: { () -> Void in
                self.hideProgress()
            })
        } else {
            self.displayAlert("Alert Message", message: "Please Check Internet connection")
        }
    }
    
    
    
    //        func displayAlert(title: String, message: String) {
    //            let alertController = UIAlertController(title: title, message: message, preferredStyle: .Alert)
    //            alertController.addAction(UIAlertAction(title: "OK", style: .Default, handler: nil))
    //            presentViewController(alertController, animated: true, completion: nil)
    //            return
    //        }
    
    
    
    func keyboardWasShown(_ notification: Notification) {
        // Step 1: Get the size of the keyboard.
        let info : NSDictionary = (notification as NSNotification).userInfo! as NSDictionary
        //        let keyboardSize = ((info.object(forKey: UIKeyboardFrameBeginUserInfoKey) as AnyObject).cgRectValue as CGRect!).size
        let keyboardSize = (info[UIKeyboardFrameBeginUserInfoKey] as? NSValue)!.cgRectValue
        // Step 2: Adjust the bottom content inset of your scroll view by the keyboard height.
        
        //        let contentInsets: UIEdgeInsets = UIEdgeInsetsMake(0.0, 0.0, keyboardSize.height+keyboardSize.height, 0.0)
        //        self.theScrollView.contentInset = contentInsets
        //        self.theScrollView.scrollIndicatorInsets = contentInsets
        
        if(UIScreen.main.traitCollection.userInterfaceIdiom == .pad){
            
            let contentInsets: UIEdgeInsets = UIEdgeInsetsMake(0.0, 0.0, keyboardSize.height+keyboardSize.height, 0.0)
            self.theScrollView.contentInset = contentInsets
            self.theScrollView.scrollIndicatorInsets = contentInsets
        }else{
            let contentInsets: UIEdgeInsets = UIEdgeInsetsMake(0.0, 0.0, keyboardSize.height, 0.0)
            self.theScrollView.contentInset = contentInsets
            self.theScrollView.scrollIndicatorInsets = contentInsets
        }
        
        // Step 3: Scroll the target text field into view.
        var aRect: CGRect = self.view.frame
        aRect.size.height -= keyboardSize.height
        if !aRect.contains(activeTextField.frame.origin)
        {
            let scrollPoint: CGPoint = CGPoint(x: 0.0, y: activeTextField.frame.origin.y - (keyboardSize.height - 15))
            self.theScrollView.setContentOffset(scrollPoint, animated: true)
        }
    }
    
    func keyboardWillBeHidden(_ notification: Notification) {
        //let contentInsets: UIEdgeInsets = UIEdgeInsets.zero
        let info : NSDictionary = (notification as NSNotification).userInfo! as NSDictionary
        //        let keyboardSize = ((info.object(forKey: UIKeyboardFrameBeginUserInfoKey) as AnyObject).cgRectValue as CGRect!).size
        let keyboardSize = (info[UIKeyboardFrameBeginUserInfoKey] as? NSValue)!.cgRectValue
        
        
        if(UIScreen.main.traitCollection.userInterfaceIdiom == .pad){//scrollview gap for iPad
            
            let contentInsets: UIEdgeInsets = UIEdgeInsetsMake(0.0, 0.0, keyboardSize.height+keyboardSize.height, 0.0)
            self.theScrollView.contentInset = contentInsets
            self.theScrollView.scrollIndicatorInsets = contentInsets
        }else{//scrollview for iPhone
            
            let contentInsets: UIEdgeInsets = UIEdgeInsetsMake(0.0, 0.0, keyboardSize.height, 0.0)
            self.theScrollView.contentInset = contentInsets
            self.theScrollView.scrollIndicatorInsets = contentInsets
        }
    }
    
    
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool
    {
        return textField.resignFirstResponder()
    }
    
    
    override func viewWillDisappear(_ animated: Bool)
    {
        NotificationCenter.default.removeObserver(self, name: NSNotification.Name.UIKeyboardDidHide, object: nil)
        NotificationCenter.default.removeObserver(self, name: NSNotification.Name.UIKeyboardWillHide, object: nil)
    }
    
    
}
