//
//  ChangeNumberVC.swift
//  MyLuckyZone
//
//  Created by Maestro_MAC1 on 24/05/17.
//  Copyright © 2017 Adodis. All rights reserved.
//

import UIKit

class ChangeNumberVC: UIViewController, UITextFieldDelegate {

    @IBOutlet weak var txtMsg : UITextField!
    @IBOutlet weak var txtMobile :  UITextField!
    @IBOutlet weak var scroll: UIScrollView!
    
    var tapGesture = UITapGestureRecognizer()
    
    
    
    override func viewDidLayoutSubviews() {
         scroll.contentSize = CGSize(width: self.view.frame.size.width, height: self.view.frame.size.height + 200)
        
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.navigationController?.navigationBar.backItem?.backBarButtonItem?.image = UIImage.init(named: "backButtonNavigation.png")
        self.navigationItem.backBarButtonItem?.image = UIImage.init(named: "backButtonNavigation.png")
        
        
        NotificationCenter.default.addObserver(self, selector: #selector(profileVC.keyboardWasShown(_:)), name: NSNotification.Name.UIKeyboardWillShow, object: nil)
        
        
        NotificationCenter.default.addObserver(self, selector: #selector(profileVC.keyboardWillBeHidden(_:)), name: NSNotification.Name.UIKeyboardWillHide, object: nil)
        
        // Do any additional setup after loading the view.
    }
    
    func keyboardWasShown(_ notification: Notification) {
        tapGesture = UITapGestureRecognizer(target: self, action: #selector(self.dismissKeyboard(_:)))
        self.view.addGestureRecognizer(tapGesture)
        
    }
    
    func dismissKeyboard(_ sender: UITapGestureRecognizer) {
        
       txtMobile.resignFirstResponder()
        txtMsg.resignFirstResponder()
    }
    
    
    func keyboardWillBeHidden(_ notification: Notification) {
        scroll.setContentOffset(CGPoint(x: 0, y: 0), animated: true)
        
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
//    func textFieldDidEndEditing(_ textField: UITextField) {
//        if textField == txtMobile{
//            scroll.setContentOffset(CGPoint(x: 0, y: 0), animated: true)
//        }
//    }
    
    
    func textFieldDidBeginEditing(_ textField: UITextField) {
        
        if textField == txtMobile{
            scroll.setContentOffset(CGPoint(x: 0, y: txtMobile.frame.origin.y - 50), animated: true)
        }
        
    }
    
    @IBAction func submitButtonClicked(_ sender: AnyObject) {
        //deviceuserchangerequest
        
        let message = self.txtMsg.text
        let mobileNubr = self.txtMobile.text
        
        
        let bundleID = Bundle.main.bundleIdentifier?.lowercased()
        var appName = 11
        let range = bundleID?.range(of: "usa")
        if range != nil {
            appName = 10
        }
        
        if message! != "" {
            if mobileNubr?.characters.count == Int(appName)
            {
                
                let str = "\(UserDefaults.standard.object(forKey: "token") as! String)"
                
                let body = String(format:"token=%@&devicetype=%d&deviceid=%@&message=%@&newnumber=%@",str, WebService.sharedInstance.DEVICE_TYPE_IOS, WebService.sharedInstance.getDeviceUUID()!,message!, mobileNubr!)
                let task = "contactnumberchangerequest"
                
                WebService().sendAPIRequest(UrlClass.baseUrl, body: body,task: task) { (result, error) -> Void in
                    DispatchQueue.main.async {
                        let alert = UIAlertController(title: "Alert", message: (result["msg"] as! String), preferredStyle: UIAlertControllerStyle.alert)
                        alert.addAction(UIAlertAction(title: "OK", style: UIAlertActionStyle.default, handler: {(alert: UIAlertAction!) in self.navigationController?.popViewController(animated: true)}))
                        self.present(alert, animated: true, completion:nil)
                    }
                }
            }
            else{
                let alert = UIAlertController(title: "Alert", message: "Enter \(appName) digit Mobile Number", preferredStyle: UIAlertControllerStyle.alert)
                alert.addAction(UIAlertAction(title: "OK", style: UIAlertActionStyle.default, handler: nil))
                self.present(alert, animated: true, completion:nil)
            }
        }else{
            let alert = UIAlertController(title: "Alert", message: "Please Describe Why?", preferredStyle: UIAlertControllerStyle.alert)
            alert.addAction(UIAlertAction(title: "OK", style: UIAlertActionStyle.default, handler: nil))
            self.present(alert, animated: true, completion:nil)
        }
    }
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        textField.resignFirstResponder()
        return true
    }
    
    @IBAction func back(_ sender: AnyObject) {
        self.navigationController?.popViewController(animated: true)
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
