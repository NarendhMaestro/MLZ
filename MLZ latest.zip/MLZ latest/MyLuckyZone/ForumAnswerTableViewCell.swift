//
//  ForumAnswerTableViewCell.swift
//  MyLuckyZone
//
//  Created by TechnoTackle on 29/12/16.
//  Copyright © 2016 Adodis. All rights reserved.
//

import UIKit

class ForumAnswerTableViewCell: UITableViewCell {

    @IBOutlet weak var bestAnswerView: UIView!
    @IBOutlet weak var bestAnswerImage: UIImageView!
    @IBOutlet weak var bestAnswerBtn: UIButton!
    @IBOutlet weak var BestAnswerLabel: UILabel!
    @IBOutlet weak var editBtn: UIButton!
    @IBOutlet weak var userImage: UIImageView!
    @IBOutlet weak var userLbl: UILabel!
    @IBOutlet weak var mailLbl: UILabel!
    @IBOutlet weak var dateLbl: UILabel!
    @IBOutlet weak var likeCountLbl: UILabel!
    @IBOutlet weak var likeBtn: UIButton!
    @IBOutlet weak var likeImage: UIImageView!
    
    
     @IBOutlet weak var likeBtnExt: UIButton!
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
