//
//  ChatMediaCell.h
//  VP Chat
//
//  Created by Maestro_MAC1 on 03/06/17.
//  Copyright © 2017 TechnoTackle. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ChatMediaCell : UITableViewCell
@property (weak, nonatomic) IBOutlet UILabel *chatSendNamelbl;
@property (weak, nonatomic) IBOutlet UILabel *chatSendMsgLbl;
@property (weak, nonatomic) IBOutlet UILabel *chatSendTimeLbl;
@property (weak, nonatomic) IBOutlet UIImageView *chatSendUserImageView;
@property (weak, nonatomic) IBOutlet UIImageView *chatSendMediaImageView;
@property (weak, nonatomic) IBOutlet UIButton *btnMsg;

@end
