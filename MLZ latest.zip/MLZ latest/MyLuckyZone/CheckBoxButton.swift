//
//  CheckBoxButton.swift
//  MyLuckyZone
//
//  Created by Prabhu Swaminathan on 25/07/16.
//  Copyright © 2016 Adodis. All rights reserved.
//

import UIKit
import Foundation

class CheckBoxButton : UIButton {
    let checkedStateImage = UIImage(named: "checked")
    let uncheckedStateImage = UIImage(named: "unchecked")
    
    override init(frame: CGRect) {
        super.init(frame: frame)
    }
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        self.addTarget(self, action: #selector(CheckBoxButton.buttonClicked(_:)), for: UIControlEvents.touchUpInside)
    }
    
    func buttonClicked(_ sender: UIButton) {
        self.isSelected = !self.isSelected
    }
}
