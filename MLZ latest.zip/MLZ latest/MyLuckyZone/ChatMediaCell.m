//
//  ChatMediaCell.m
//  VP Chat
//
//  Created by Maestro_MAC1 on 03/06/17.
//  Copyright © 2017 TechnoTackle. All rights reserved.
//

#import "ChatMediaCell.h"

@implementation ChatMediaCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
