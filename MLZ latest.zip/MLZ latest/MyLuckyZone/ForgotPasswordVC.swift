//
//  ForgotPasswordVC.swift
//  MyLuckyZone
//
//  Created by Kavya Mishra on 5/17/16.
//  Copyright © 2016 Adodis. All rights reserved.
//

import UIKit

class ForgotPasswordVC: UIViewController ,UITextFieldDelegate {
    
    @IBOutlet var theEmailTextField: UITextField!
    var activeTextField = UITextField()


    @IBOutlet var theScrollView: UIScrollView!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        theEmailTextField.layer.borderWidth = 1
        theEmailTextField.layer.borderColor = UIColor.white.cgColor
        
        // Do any additional setup after loading the view.
        let backgroundImage = UIImageView(frame: UIScreen.main.bounds)
        backgroundImage.image = UIImage(named: "bg2.png")
        backgroundImage.contentMode = UIViewContentMode.scaleAspectFill
        self.view.insertSubview(backgroundImage, at: 0)
        
        NotificationCenter.default.addObserver(self, selector: #selector(ForgotPasswordVC.keyboardWasShown(_:)), name: NSNotification.Name.UIKeyboardWillShow, object: nil)
        
        NotificationCenter.default.addObserver(self, selector: #selector(ForgotPasswordVC.keyboardWillBeHidden(_:)), name: NSNotification.Name.UIKeyboardWillHide, object: nil)

    }
    
    
    @IBAction func submit(_ sender: AnyObject) {
        if Reachability.isConnectedToNetwork() == true {
            if (self.theEmailTextField.text == "" )
            {
                self.displayAlert("Alert Message", message: "Please Enter EmailId")
            }else {
                self.showProgress()
                let body = String(format:"emailid=%@", self.theEmailTextField.text!)
                let task = "forgotpassword"
                WebService().sendAPIRequest(UrlClass.baseUrl, body: body,task: task) { (result, error) -> Void in
                    if result["status"] as! Int == 1
                    {
                        //print("1st....")
                        OperationQueue.main.addOperation {
                            self.hideProgress()
                            self.displayAlert("Alert Message ", message: result["msg"] as! String)
                        }
//                        DispatchQueue.main.async(execute: { () -> Void in
//                            self.hideProgress()
//                            self.displayAlert("Alert Message", message: result["msg"] as! String)
//                        })
                    } else if result["status"] as! Int == 0
                    {
                        
                        //print("2nd")

//                        DispatchQueue.main.async(execute: { () -> Void in
//                            self.hideProgress()
//                            self.displayAlert("Alert Message :: ", message: result["msg"] as! String)
//                        })
                        OperationQueue.main.addOperation {
                            self.hideProgress()
                            self.displayAlert("Alert Message ", message: result["msg"] as! String)
                        }
                    
                    }
                }
            }
            
        } else {
            self.displayAlert("Alert Message", message: "Please Check Internet connection")
            
        }

            }
    
    
//    func displayAlert(title: String, message: String) {
//        let alertController = UIAlertController(title: title, message: message, preferredStyle: .Alert)
//        alertController.addAction(UIAlertAction(title: "OK", style: .Default, handler: nil))
//        presentViewController(alertController, animated: true, completion: nil)
//        return
//    }
    

    func keyboardWasShown(_ notification: Notification) {
        // Step 1: Get the size of the keyboard.
        let info : NSDictionary = (notification as NSNotification).userInfo! as NSDictionary
//        let keyboardSize = ((info.object(forKey: UIKeyboardFrameBeginUserInfoKey) as AnyObject).cgRectValue as CGRect!).size
        let keyboardSize = (info[UIKeyboardFrameBeginUserInfoKey] as? NSValue)!.cgRectValue
        // Step 2: Adjust the bottom content inset of your scroll view by the keyboard height.
        let contentInsets: UIEdgeInsets = UIEdgeInsetsMake(0.0, 0.0, keyboardSize.height, 0.0)
        self.theScrollView.contentInset = contentInsets
        self.theScrollView.scrollIndicatorInsets = contentInsets
        // Step 3: Scroll the target text field into view.
        var aRect: CGRect = self.view.frame
        aRect.size.height -= keyboardSize.height
        if !aRect.contains(activeTextField.frame.origin)
        {
            let scrollPoint: CGPoint = CGPoint(x: 0.0, y: activeTextField.frame.origin.y - (keyboardSize.height - 15))
            self.theScrollView.setContentOffset(scrollPoint, animated: true)
        }
    }
    
    func keyboardWillBeHidden(_ notification: Notification) {
        let contentInsets: UIEdgeInsets = UIEdgeInsets.zero
        self.theScrollView.contentInset = contentInsets
        self.theScrollView.scrollIndicatorInsets = contentInsets
    }
    
    
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool
    {
        return textField.resignFirstResponder()
    }
    
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    override func viewWillDisappear(_ animated: Bool)
    {
        NotificationCenter.default.removeObserver(self, name: NSNotification.Name.UIKeyboardDidHide, object: nil)
        NotificationCenter.default.removeObserver(self, name: NSNotification.Name.UIKeyboardWillHide, object: nil)
    }
    

    

    @IBAction func back(_ sender: AnyObject) {
        self.dismiss(animated: true, completion: nil)

    }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
