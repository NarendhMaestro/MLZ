//
//  MyrewardsTableViewCell.swift
//  MyLuckyzone
//
//  Created by Mastero on 02/12/17.
//  Copyright © 2017 Adodis. All rights reserved.
//

import UIKit

class MyrewardsTableViewCell: UITableViewCell {
    @IBOutlet weak var imageview: UIImageView!
    @IBOutlet weak var headerLable: UILabel!
    @IBOutlet weak var rickyAction: UILabel!
    @IBOutlet weak var HighestBitter: UILabel!
    @IBOutlet weak var MyBit: UILabel!
    @IBOutlet weak var status: UILabel!
    @IBOutlet weak var probarlable: UIProgressView!
    @IBOutlet weak var problable: UILabel!
    
   
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
//
       
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
