//
//  ShareVC.swift
//  MyLuckyZone
//
//  Created by Adodis on 27/05/16.
//  Copyright © 2016 Adodis. All rights reserved.
//

import UIKit
import SDWebImage

class ShareVC: UIViewController,ZHDropDownMenuDelegate2,UITableViewDelegate, UITableViewDataSource  {
    
    var senderTag = " "
    
    var receivedStoryboardID:String!
    
    @IBOutlet weak var MyRewardsLable: SMIconLabel!
    @IBOutlet weak var filterBar: ZHDropDownMenu2!
    @IBOutlet weak var tableview: UITableView!
    var auctiontype:[String]! = []
    var barclass:[String]! = []
    var bartext:[String]! = []
    var barwidth:[String]! = []
    var followingtype:[String]! = []
    var highestbidder:[String]! = []
    var imagepath:[String]! = []
    var points:[String]! = []
    var rewardid:[String]! = []
    var rewardtype:[String]! = []
    var status:[String]! = []
    var sweepstaketype:[String]! = []
    var title1:[String]! = []
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        filterBar.delegate = self
        filterBar.options = ["All","Sweepstake","Auction","Purchases","Elite Purchases","Watch List"]

        MyRewardsLable.text = "My Rewards"
        MyRewardsLable.icon = UIImage(named: "favorites")
        MyRewardsLable.iconPosition = ( .left, .center )
        MyRewardsLable.textColor = .blue
        
        getData()
        // Do any additional setup after loading the view.
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        NotificationCenter.default.removeObserver(self)
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(true)
        
        //if you are coming from the rear vc
        if let receivedViewDict = UserDefaults.standard.object(forKey: "slideMenuView")  as? [String:AnyObject]
        {
            print(receivedViewDict)
            
            if let receivedID = receivedViewDict["storyboardidentifier"] as? String
            {
                receivedStoryboardID = receivedID
            }
            
            let viewToAdd = self.storyboard?.instantiateViewController(withIdentifier: receivedStoryboardID)
            addChildViewController(viewToAdd!)
            viewToAdd!.view.frame = self.view.bounds
            viewToAdd!.view.tag = 666
            view.addSubview(viewToAdd!.view)
            viewToAdd!.didMove(toParentViewController: self)
            //remove the object from nsuserDefaults after you have retrieved the dictionary
            UserDefaults.standard.removeObject(forKey: "slideMenuView")
            
        }
        else
        {
            //write codes in this block when you come normally in a flow not from yhe rear view controller
            print("Nothing stored in NSUserDefaults yet. Set a value.")
        }
        NotificationCenter.default.addObserver(self, selector: #selector(ShareVC.removeSideViewIfPresent(_:)), name:NSNotification.Name(rawValue: "RemoveSideMenuView"), object: nil)
    }
    
    func removeSideViewIfPresent(_ notification: Notification)
    {
        //Take Action on Notification
        self.view.viewWithTag(666)?.removeFromSuperview()
    }
    
    public func dropDownMenu2(_ menu: ZHDropDownMenu2!, didChoose index: Int, didInput text: String!) {
        
    }
    
    
    
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        
        return title1.count
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 126
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath ) as! MyrewardsTableViewCell
        
        cell.headerLable.text = title1[indexPath.row]
        cell.problable.text = bartext[indexPath.row]
        cell.HighestBitter.text = "Highest Bitter : \(highestbidder[indexPath.row])"
        cell.MyBit.text = "My Bit : \(points[indexPath.row])"
        cell.problable.text = bartext[indexPath.row]
//        cell.progresBar.transform = CGAffineTransform(scaleX: 1, y: 10)
        let baseurl = "http://dev.myluckyzone.com\(imagepath[indexPath.row])"
        cell.imageview.sd_setImage(with: URL(string:baseurl)
            , placeholderImage: nil
            , options: SDWebImageOptions.retryFailed
            , progress: {(receivedSize: Int, expectedSize: Int) in
        }
            , completed:{(image: UIImage?, error: Error?, cacheType: SDImageCacheType, imageURL: URL?) in
                if (image != nil) {
                    cell.imageview.image = image
                }
        })
        if auctiontype[indexPath.row] == "1"||auctiontype[indexPath.row] == ""{
        cell.rickyAction.isHidden = true
        }
        else {
            
             cell.rickyAction.isHidden = false
        }
        
        cell.status.text = status[indexPath.row]
        
        

        return cell
    }
    
    
    
    
    func getData()
    {
        //        self.showProgress()
        
        
        let body = String(format: "token=%@&filter_opt=%@",UserDefaults.standard.object(forKey: "token") as! String,1)
        
        
        
        let task = "myrewards"
        WebService().sendAPIRequest(UrlClass.baseUrl, body: body,task: task) { (result, error) -> Void in
            if(result.count>0){
                if result["status"] as! Int == 1
                {

                    let resultss = result["myrewardslist"] as! NSArray
//
                    
                    
                    DispatchQueue.main.async(execute: { () -> Void in
                       
                        for i in 0..<resultss.count {
                        let resultsss = resultss[i] as! NSDictionary
                        print(resultsss["title"] as! String)
                         self.title1.append(resultsss["title"] as! String)
                         self.auctiontype.append(resultsss["auctiontype"] as! String)
                        self.barclass.append(String(describing: resultsss["barclass"]!))
                         self.bartext.append(resultsss["bartext"] as! String)
                         self.barwidth.append(String(describing: resultsss["barwidth"]!))
                         self.followingtype.append(resultsss["followingtype"] as! String)
                         self.highestbidder.append(resultsss["highestbidder"] as! String)
                         self.imagepath.append(resultsss["imagepath"] as! String)
                         self.points.append(String(describing: resultsss["points"]!))
                         self.rewardid.append(String(describing: resultsss["rewardid"]!))
                         self.rewardtype.append(String(describing: resultsss["rewardtype"]!))
                         self.status.append(resultsss["status"] as! String)
                        self.sweepstaketype.append(resultsss["sweepstaketype"] as! String)
                        self.status.append(resultsss["status"] as! String)
                        }
//                        String(describing: resultsss["rewardtype"]
                        self.tableview.reloadData()
                    })
                  
                    
                }
                else if(result["status"] as! Int == 0 || result["status"] as! Int == -1)
                {
                    //                    DispatchQueue.main.async(execute: { () -> Void in
                    //                        self.hideProgress()
                    //                        self.displayAlert("Alert Message", message: result["msg"] as! String)
                    ////                        self.productTableView.reloadData()
                    //                    })
                }else{
                    print("no messg")
                    //                    DispatchQueue.main.async(execute: { () -> Void in
                    //                        self.hideProgress()
                    //                        if(result.count>0){
                    //                            self.displayAlert("Alert Message", message: result["msg"] as! String)}
                    //                        else{
                    //                            self.displayAlert("Alert Message", message: "Try again")
                    //                        }
                    //                    })
                }
            } else{
                print("no net")
                //self.displayAlert("Alert Message", message: "Please Check Internet connection")
                DispatchQueue.main.async(execute: { () -> Void in
                    //                    self.hideProgress()
                })
            }
        }
    }
    
    
    
    
    
//    func share()
//    {
//        if Reachability.isConnectedToNetwork() == true {
//
//
//            do{
//
//                self.showProgress()
//                let body = String(format:"token=%@", UserDefaults.standard.object(forKey: "token") as! String)
//
//                let task = "sharemyreferrallink"
//
//
//                try WebService().sendAPIRequest(UrlClass.baseUrl, body: body,task: task) { (result, error) -> Void in
//
//
//                    if result.count>0{
//
//                    if result["status"] as! Int == 1
//                    {
//                        DispatchQueue.main.async(execute: { () -> Void in
//                            self.hideProgress()
//                            self.displayShareSheet(result["url"] as! String)
//                        })
//                    } else if result["status"] as! Int == 0 || result["status"] as! Int == -1
//                    {
//                        DispatchQueue.main.async(execute: { () -> Void in
//
//                            self.hideProgress()
//                            self.displayAlert("Alert Message", message: result["msg"] as! String)
//                        })
//                    }
//                    }else{
//                        print("error")
//                        DispatchQueue.main.async(execute: { () -> Void in
//                            self.hideProgress()
//                            self.share()
//                            //self.displayAlert("Alert Message", message: result["msg"] as! String)
//                        })
//                    }
//
//
//                }
//            }catch{
//                print("error")
//                self.hideProgress()
//                share()
//            }
//        } else {
//            self.displayAlert("Alert Message", message: "Please Check Internet connection")
//
//        }
//
//
//    }
    
    //       func displayAlert(title: String, message: String) {
    //        let alertController = UIAlertController(title: title, message: message, preferredStyle: .Alert)
    //        alertController.addAction(UIAlertAction(title: "OK", style: .Default, handler: nil))
    //        presentViewController(alertController, animated: true, completion: nil)
    //        return
    //    }
    
    
//    func displayShareSheet(_ shareContent:String) {
//
//        let activityViewController = UIActivityViewController(activityItems: [shareContent as NSString], applicationActivities: nil)
//
//
//
//        if (UI_USER_INTERFACE_IDIOM() == UIUserInterfaceIdiom.phone) {
//
//            present(activityViewController, animated: true, completion: {})
//
//        }else{
//            if let myWebsite = NSURL(string: shareContent) {
//                let objectsToShare = ["", myWebsite] as [Any]
//                let activityVC = UIActivityViewController(activityItems: objectsToShare, applicationActivities: nil)
//
//                var nav = UINavigationController(rootViewController: activityVC)
//                nav.modalPresentationStyle = UIModalPresentationStyle.popover
//                var popover = nav.popoverPresentationController as UIPopoverPresentationController!
//                //activityVC.preferredContentSize = CGSizeMake(500,600)
//                popover?.sourceView = self.view
//                // popover?.sourceRect = CGRectMake(100,100,0,0)
//
//                self.present(nav, animated: true, completion: nil)
//            }
//        }
//    }
    /*
     // MARK: - Navigation
     
     // In a storyboard-based application, you will often want to do a little preparation before navigation
     override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
     // Get the new view controller using segue.destinationViewController.
     // Pass the selected object to the new view controller.
     }
     */
    
}
