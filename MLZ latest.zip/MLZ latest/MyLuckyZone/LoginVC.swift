    //
//  LoginVC.swift
//  MyLuckyZone
//
//  Created by Kavya Mishra on 5/17/16.
//  Copyright © 2016 Adodis. All rights reserved.
//

import UIKit

class LoginVC: UIViewController , UITextFieldDelegate {
    
    @IBOutlet var theBottomView: UIView!

    @IBOutlet weak var theScrollView: UIScrollView!
    
    @IBOutlet var thePasswordTextField: UITextField!
    
    @IBOutlet var privacyLabel: UILabel!
    @IBOutlet var signInDifferentUser: UIButton!
    var activeTextField = UITextField()
    var versionverified = 1
    
    var handler : ((UIAlertAction) -> Void)?
    var message : String!
    
//    @IBOutlet var forgotPasswordBottomConstraint: NSLayoutConstraint!
    @IBOutlet var theUserNameTextField: UITextField!
    
    @IBOutlet var btnLoginWithRC : UIButton!
    
    @IBOutlet weak var rawcasterbutton: UIButton!
    @IBOutlet weak var gobutton: UIButton!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
        
        let backgroundImage = UIImageView(frame: UIScreen.main.bounds)
        backgroundImage.image = UIImage(named: "bg1.png")
        backgroundImage.contentMode = UIViewContentMode.scaleAspectFill
        self.view.insertSubview(backgroundImage, at: 0)
        
        thePasswordTextField.layer.borderWidth = 1
        thePasswordTextField.layer.borderColor = UIColor.white.cgColor
        theUserNameTextField.layer.borderWidth = 1
        theUserNameTextField.layer.borderColor = UIColor.white.cgColor
        rawcasterbutton.isHidden = true
        gobutton.layer.cornerRadius = 20
        self.theScrollView.contentSize = CGSize(width:self.view.frame.size.width, height:1000)
        
        
        NotificationCenter.default.addObserver(self, selector: #selector(LoginVC.keyboardWasShown(_:)), name: NSNotification.Name.UIKeyboardWillShow, object: nil)
        
        NotificationCenter.default.addObserver(self, selector: #selector(LoginVC.keyboardWillBeHidden(_:)), name: NSNotification.Name.UIKeyboardWillHide, object: nil)
        
        let tapGesture = UITapGestureRecognizer()
        tapGesture.addTarget(self, action: #selector(LoginVC.Register))
        self.theBottomView.addGestureRecognizer(tapGesture)
        
        let version = Bundle.main.infoDictionary?["CFBundleShortVersionString"] as! String

        
        self.privacyLabel.text = "By downloading and using this app (v\(version)), you agree to the policy, privacy terms and conditions of use specified by "
        
        showProgress();
        self.handler =  {(UIAlertAction) -> Void in
            let bundleID = Bundle.main.bundleIdentifier?.lowercased()
            let url : String?
            let range = bundleID?.range(of: "usa")
            if range != nil {
                url = "https://itunes.apple.com/us/app/myluckyzone-usa/id1124300983?ls=1&mt=8"
            } else {
                url = "https://itunes.apple.com/us/app/myluckyzone-nigeria/id1133993562?ls=1&mt=8"
            }
            //UIApplication.shared.openURL(URL(string: url!)!)
            if self.message != nil {
                self.displayAlert("Alert Message", message: self.message, handler:self.handler)
            }
        }
        
        NotificationCenter.default.addObserver(self, selector: #selector(LoginVC.checkDevice), name: NSNotification.Name(rawValue: "checkDevice") , object: nil)
        self.checkDevice()
    }
    
    func checkDevice()
    {
        WebService.sharedInstance.checkDevice( { (result: [String : AnyObject], error: AnyObject?)-> Void in
            DispatchQueue.main.async {
                self.hideProgress()
                if error == nil {
                    self.message = nil
                    let status : Int? = result["status"] as? Int
                    if status == 1 {
                        let username = result["username"] as? String
                        if username != nil {
                            self.theUserNameTextField.text = username
                            self.theUserNameTextField.isEnabled = false
                            //Hiding Login with Rawcaster option
                            var frame = self.btnLoginWithRC.frame
                            frame.size.height = 0
                            self.btnLoginWithRC.frame = frame
                            self.btnLoginWithRC.setTitle(" ", for: UIControlState.normal)
                            self.signInDifferentUser.isHidden = false
                            self.hideProgress()
                            return
                        }
                    } else if status == 3 || status == 0 {
                        self.versionverified = 0
                        if status == 3 {
                            self.message = result["msg"] as! String
                        }
                        self.displayAlert("Alert Message", message: result["msg"] as! String, handler:self.handler)
                    } else if status == 2 {
//                        self.forgotPasswordBottomConstraint.constant = 44
                        self.theBottomView.isHidden = false
                    }
                    self.theUserNameTextField.isEnabled = true
                    
                    //Hiding Login with Rawcaster option
                    var frame = self.btnLoginWithRC.frame
                    frame.size.height = 40
                    self.btnLoginWithRC.setTitle("Login with Rawcaster", for: UIControlState.normal)
                    self.btnLoginWithRC.frame = frame
                    
                    
                    self.signInDifferentUser.isHidden = true
                } else {
                    self.displayAlert("Alert", message: error as! String)
                }
            }
        });
    }
    
    
    override func viewWillAppear(_ animated: Bool)
    {
        super.viewWillAppear(true)
        
        self.checkDevice()
    }
    
    
    @IBAction func login(_ sender: AnyObject) {
        
        if Reachability.isConnectedToNetwork() == true {
            if (self.theUserNameTextField.text == "" || self.thePasswordTextField.text == "" )
            {
                displayAlert("Alert Message", message: "Please Enter EmailId and Password")
                
            }else {
                
                self.showProgress()
                let Raw_Code:String = String(format:"%@%@%@",WebService().getSALT,WebService.sharedInstance.getDeviceUUID()!,self.theUserNameTextField.text!)
                let AUTH_CODE:String = WebService().SHA1(Raw_Code)
                //let AUTH_CODE:String = String(format:"authcode=%@",EN_DATA)
                var body = String(format:"username=%@&password=%@&devicetype=%d&deviceid=%@&authcode=%@&versionverified=\(self.versionverified)",self.theUserNameTextField.text!,self.thePasswordTextField.text!, WebService.sharedInstance.DEVICE_TYPE_IOS, WebService.sharedInstance.getDeviceUUID()!,AUTH_CODE)
                
                
                if UserDefaults.standard.string(forKey: "APNSID") != nil{
                  body = body.appending(String(format:"&apnsid=%@", UserDefaults.standard.string(forKey: "APNSID")!))
                }
                
                
                let task = "login"
                WebService().sendAPIRequest(UrlClass.baseUrl, body: body,task: task) { (result, error) -> Void in
                    
                    if(result.count>0){
                    
                    if result["status"] as! Int == 1
                    {
                        UserDefaults.standard.set(result["token"], forKey: "token")
                        //saving user name for chat
                         UserDefaults.standard.set(self.theUserNameTextField.text!, forKey: "userName")
                        
                        WebService.sharedInstance.getProfile(nil);
                        DispatchQueue.main.async(execute: { () -> Void in
                            self.hideProgress()
                            self.performSegue(withIdentifier: "login", sender: self)
                        })
                        
                    } else if result["status"] as! Int == 0
                    {
                        DispatchQueue.main.async(execute: { () -> Void in
                            self.hideProgress()
                            self.displayAlert("Alert Message", message: result["msg"] as! String, handler: self.handler)
                        })
                    }
                        
                    }
                    else{
                        self.displayAlert("Alert Message", message: "Please Check Internet connection")
                        self.hideProgress()
                        
                    }
                }
            }
            

            
        } else {
            self.displayAlert("Alert Message", message: "Please Check Internet connection")
            
        }

            }
    
    @IBAction func loginWithRawcaster(_ sender: AnyObject) {
        self.present(UIViewController (nibName: "rawCasterLoginVC", bundle: nil), animated:true, completion: nil)
       // self.performSegue(withIdentifier: "rawCasterLoginVC", sender: self)
    }
    
    
    
//        func displayAlert(title: String, message: String) {
//            let alertController = UIAlertController(title: title, message: message, preferredStyle: .Alert)
//            alertController.addAction(UIAlertAction(title: "OK", style: .Default, handler: nil))
//            presentViewController(alertController, animated: true, completion: nil)
//        }
    
    

    func keyboardWasShown(_ notification: Notification) {
        // Step 1: Get the size of the keyboard.
        let info : NSDictionary = (notification as NSNotification).userInfo! as NSDictionary
        let keyboardSize = (info[UIKeyboardFrameBeginUserInfoKey] as? NSValue)?.cgRectValue
        if(keyboardSize != nil) {
            // Step 2: Adjust the bottom content inset of your scroll view by the keyboard height.
            let contentInsets: UIEdgeInsets = UIEdgeInsetsMake(0.0, 0.0, keyboardSize!.height, 0.0)
            self.theScrollView.contentInset = contentInsets
            self.theScrollView.scrollIndicatorInsets = contentInsets
            // Step 3: Scroll the target text field into view.
            var aRect: CGRect = self.view.frame
            aRect.size.height -= keyboardSize!.height
            if !aRect.contains(activeTextField.frame.origin)
            {
                let scrollPoint: CGPoint = CGPoint(x: 0.0, y: activeTextField.frame.origin.y - (keyboardSize!.height - 15))
                self.theScrollView.setContentOffset(scrollPoint, animated: true)
            }
        }
    }
    
    func keyboardWillBeHidden(_ notification: Notification) {
        let contentInsets: UIEdgeInsets = UIEdgeInsets.zero
        self.theScrollView.contentInset = contentInsets
        self.theScrollView.scrollIndicatorInsets = contentInsets
    }
    
    
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool
    {
        return textField.resignFirstResponder()
    }
    
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    override func viewWillDisappear(_ animated: Bool)
    {
        NotificationCenter.default.removeObserver(self, name: NSNotification.Name.UIKeyboardDidHide, object: nil)
        NotificationCenter.default.removeObserver(self, name: NSNotification.Name.UIKeyboardWillHide, object: nil)
    }
    
    
    
    func Register()
    {
        self.performSegue(withIdentifier: "register", sender: self)
    }

    

    
    @IBAction func registerButton(_ sender: AnyObject) {
        Register()
    }
    
    // MARK: - ABV
    
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    //override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
   /// }
   // */

}
