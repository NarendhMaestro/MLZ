//
//  RCRegister.swift
//  MyLuckyZone
//
//  Created by Maestro_MAC1 on 23/05/17.
//  Copyright © 2017 Adodis. All rights reserved.
//

import UIKit

class RCRegister: UIViewController, UITextFieldDelegate {

    @IBOutlet var mobileNumberTxtField: UITextField!
    @IBOutlet var btnSubmit: UIButton!
     @IBOutlet var tosCheckBoxButton: CheckBoxButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    
    func getMlzInfo(_ tag : NSInteger)
    {
        //        let body = String(format:"token=%@&pagenumer=1", NSUserDefaults.standardUserDefaults().objectForKey("token") as! String)
        let task = "getmlzinfo"
        WebService().sendAPIRequest(UrlClass.baseUrl, body: "",task: task) { (result, error) -> Void in
            if result["status"] as! Int == 1
            {
                var htmlString : String? = nil
                var title  = ""
                if tag == 1
                {
                    htmlString = result["termsofservice"] as? String
                    title = "Terms of Service"
                } else {
                    htmlString = result["privacypolicy"] as? String
                    title = "Privacy Policy"
                }
                htmlString = self.escapeHTMLCharacters(htmlString)
                DispatchQueue.main.async(execute: { () -> Void in
                    let data : [String]? = [htmlString!, title]
                    self.performSegue(withIdentifier: "infoSegue", sender: data)
                })
            }
        }
    }
    func escapeHTMLCharacters(_ htmlString : String?) -> String? {
        let entities = [
            "&quot;"    : "\"",
            "&amp;"     : "&",
            "&apos;"    : "'",
            "&lt;"      : "<",
            "&gt;"      : ">",
            ]
        var newString = htmlString
        for (name,value) in entities {
            newString = newString?.replacingOccurrences(of: name, with: value)
        }
        return newString
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        
        if segue.identifier as String! == "infoSegue"
        {
            let destinationVC = segue.destination as? WebViewController
            let data = sender as! [String]
            destinationVC?.htmlString = data[0]
            destinationVC?.title = data[1]
        }
    }
    
    
    @IBAction func termsofService(_ sender: AnyObject) {
       
       let button = sender as! UIButton
        self.getMlzInfo(button.tag)
    }
    
    @IBAction func Submit(_ sender: AnyObject)
    {
            let bundleID = Bundle.main.bundleIdentifier?.lowercased()
            let range = bundleID?.range(of: "usa")
            var n = 11
            if range != nil
            {//USA
                n = 10
            }
        if mobileNumberTxtField.text?.characters.count == n{
            
            if self.tosCheckBoxButton.isSelected {
                self.registerNew()
                
            }else{
                let alert = UIAlertController(title: "Alert", message: "Please agree to Terms of Service and Privacy Policy.", preferredStyle: UIAlertControllerStyle.alert)
                alert.addAction(UIAlertAction(title: "OK", style: UIAlertActionStyle.default, handler: nil))
                self.present(alert, animated: true, completion: nil)
            }
        }else{
            let alert = UIAlertController(title: "Alert", message: "PleaseEnter Valid Mobile Number.", preferredStyle: UIAlertControllerStyle.alert)
            alert.addAction(UIAlertAction(title: "OK", style: UIAlertActionStyle.default, handler: nil))
            self.present(alert, animated: true, completion: nil)
        }
    }
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool
    {
       // btnSubmit.sendActions(for: UIControlEvents.touchUpInside)
        return textField.resignFirstResponder()
    }

    
    @IBAction func back(_ sender: AnyObject)   {
    self.navigationController?.popViewController(animated: true)
        self.dismiss(animated: true, completion: nil)
    }
    
    
    func registerNew()
    {
        print(UserDefaults.standard.string(forKey: "reftmpid")!)
        print(self.mobileNumberTxtField.text!)
        print(WebService.sharedInstance.DEVICE_TYPE_IOS)
        print(WebService.sharedInstance.getDeviceUUID()!)
        
        
        //Creating new account
        let body2 = String(format:"reftmpid=%@&mobilenumber=%@&devicetype=%d&deviceid=%@&apnsid=%@&versionverified=1", UserDefaults.standard.string(forKey: "reftmpid")!, self.mobileNumberTxtField.text! ,WebService.sharedInstance.DEVICE_TYPE_IOS,  WebService.sharedInstance.getDeviceUUID()! )
        let task2 = "createuserfromrawcaster"
        
        WebService().sendAPIRequest(UrlClass.baseUrl, body: body2,task: task2) { (result, error) -> Void in
            
            
            if result["status"] as! Int == 1
            {
                UserDefaults.standard.set(result["token"], forKey: "token")
                WebService.sharedInstance.getProfile(nil);
                DispatchQueue.main.async(execute: { () -> Void in
                    self.hideProgress()
                    self.performSegue(withIdentifier: "login", sender: self)
                })
                
            } else if result["status"] as! Int == 0
            {
                DispatchQueue.main.async(execute: { () -> Void in
                    self.hideProgress()
                    self.displayAlert("Alert Message", message: result["msg"] as! String, handler: nil)
                })
            }
        }
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
