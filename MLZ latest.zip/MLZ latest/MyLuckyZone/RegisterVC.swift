//
//  RegisterVC.swift
//  MyLuckyZone
//
//  Created by Kavya Mishra on 5/17/16.
//  Copyright © 2016 Adodis. All rights reserved.
//

import UIKit
fileprivate func < <T : Comparable>(lhs: T?, rhs: T?) -> Bool {
  switch (lhs, rhs) {
  case let (l?, r?):
    return l < r
  case (nil, _?):
    return true
  default:
    return false
  }
}

fileprivate func > <T : Comparable>(lhs: T?, rhs: T?) -> Bool {
  switch (lhs, rhs) {
  case let (l?, r?):
    return l > r
  default:
    return rhs < lhs
  }
}


class RegisterVC: UIViewController ,UITextFieldDelegate ,UIAlertViewDelegate {

    @IBOutlet var referrerCheckbox: CheckBoxButton!
    @IBOutlet var theScrollView: UIScrollView!
    
    @IBOutlet var referrerLabel: UILabel!
    
    @IBOutlet var referrerLabelHeight: NSLayoutConstraint!
    @IBOutlet var firstNameTextField: UITextField!
    @IBOutlet weak var mobilenumber: UITextField!
    
    @IBOutlet var theCustomView: UIView!
    
    var activeTextField = UITextField()

    @IBOutlet var emaiTextField: UITextField!
    
//    @IBOutlet var confirmEmailTextField: UITextField!
    @IBOutlet var passwordTextField: UITextField!
    
    @IBOutlet var confirmPasswordTextField: UITextField!

    @IBOutlet var referredTextField: UITextField!
    
    @IBOutlet var lastNameTextField: UITextField!
    
    @IBOutlet var tosCheckBoxButton: CheckBoxButton!
    
    var counter:Int = 30
    var timer: Timer?
    var label = ""
    var message = "in "
     var alertController: UIAlertController!
    
    
    
    
    //    @IBOutlet var theMainView: UIView!
    override func viewDidLoad() {
        super.viewDidLoad()
        
        let backgroundImage = UIImageView(frame: UIScreen.main.bounds)
        backgroundImage.image = UIImage(named: "bg2.png")
        backgroundImage.contentMode = UIViewContentMode.scaleAspectFill
        self.view.insertSubview(backgroundImage, at: 0)
        
        
        
        firstNameTextField.delegate = self
        lastNameTextField.delegate = self
        emaiTextField.delegate = self
//        confirmEmailTextField.delegate = self
        passwordTextField.delegate = self
        confirmPasswordTextField.delegate = self
        mobilenumber.delegate = self

        referredTextField.delegate = self
//        self.referrerLabelHeight.constant = 0
        
        
        firstNameTextField.layer.borderWidth = 1
        firstNameTextField.layer.borderColor = UIColor.white.cgColor
        lastNameTextField.layer.borderWidth = 1
        lastNameTextField.layer.borderColor = UIColor.white.cgColor
        emaiTextField.layer.borderWidth = 1
        emaiTextField.layer.borderColor = UIColor.white.cgColor
//        confirmEmailTextField.layer.borderWidth = 1
//        confirmEmailTextField.layer.borderColor = UIColor.white.cgColor
        passwordTextField.layer.borderWidth = 1
        passwordTextField.layer.borderColor = UIColor.white.cgColor
        confirmPasswordTextField.layer.borderWidth = 1
        confirmPasswordTextField.layer.borderColor = UIColor.white.cgColor
        mobilenumber.layer.borderWidth = 1
        mobilenumber.layer.borderColor = UIColor.white.cgColor
        NotificationCenter.default.addObserver(self, selector: #selector(RegisterVC.keyboardWasShown(_:)), name: NSNotification.Name.UIKeyboardWillShow, object: nil)
        NotificationCenter.default.addObserver(self, selector: #selector(RegisterVC.keyboardWillBeHidden(_:)), name: NSNotification.Name.UIKeyboardWillHide, object: nil)
    }
    
    
    override func viewDidLayoutSubviews() {
        self.theScrollView.contentSize = CGSize(width: self.view.frame.width, height: self.theCustomView.frame.height + 100)
    }
    
    
    func checkReferrer(_ referrerId : String?) {
        self.showProgress()
        let body = String(format:"referrer=%@", referrerId!)
        let task = "checkreferrer"
        WebService().sendAPIRequest(UrlClass.baseUrl, body: body,task: task) { (result, error) -> Void in
            DispatchQueue.main.async(execute: { () -> Void in
                self.hideProgress()
                if result["status"] as? Int == 1
                {
                    let name = result["referrername"] as! String
                    self.referrerLabel.text = "Referrer Name : \(name)"
                    self.referrerLabelHeight.constant = 21
                    self.referredTextField.text = result["referreremailid"] as! String
                } else {
                    self.displayAlert("Alert Message", message: result["msg"] as! String)
                    self.referrerCheckbox.isSelected = false
                }
            })
        }
    }
    
    func showInvalidReferrerId() {
        let alertNew = UIAlertController(title: "Alert", message: "Please enter a valid referral Email Address.", preferredStyle: UIAlertControllerStyle.alert)
        alertNew.addAction(UIAlertAction(title: "OK", style: UIAlertActionStyle.default, handler: {(UIAlertAction) -> Void in
            self.getReferrerId()
        }))
        self.present(alertNew, animated: true, completion: nil)
        
    }
    
    func getReferrerId() {
        let alert = UIAlertController(title: "Alert", message: "Enter your referrer email id", preferredStyle: UIAlertControllerStyle.alert)
        alert.addAction(UIAlertAction(title: "Ok", style: UIAlertActionStyle.default, handler: {(UIAlertAction) -> Void in
            if !self.isValidEmail(alert.textFields![0].text) {
                self.showInvalidReferrerId()
                return
            } else {
                self.checkReferrer(alert.textFields![0].text)
            }
            
        }))
        alert.addAction(UIAlertAction(title: "Cancel", style: UIAlertActionStyle.cancel, handler: {(UIAlertAction) -> Void in
            if alert.textFields![0].text?.characters.count > 0 {
                self.referredTextField.text = alert.textFields![0].text
            } else {
                self.referrerCheckbox.isSelected = false
            }
        }))
        alert.addTextField(configurationHandler: {(textField: UITextField!) in
            textField.placeholder = "Referrer Email ID"
        })
        self.present(alert, animated: true, completion: nil)
    }
    
    func isValidEmail(_ testStr:String?) -> Bool {
        // print("validate calendar: \(testStr)")
        let emailRegEx = "[A-Z0-9a-z._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,}"
        
        let emailTest = NSPredicate(format:"SELF MATCHES %@", emailRegEx)
        return emailTest.evaluate(with: testStr)
    }
    
    @IBAction func submit(_ sender: AnyObject) {
        
        if Reachability.isConnectedToNetwork() == true {
            
            if (self.emaiTextField.text == "" || self.firstNameTextField.text == "" || self.lastNameTextField.text == "" || self.passwordTextField.text == "" || self.mobilenumber.text == "")
            {
                let alert = UIAlertController(title: "Alert", message: "Please Enter all fields", preferredStyle: UIAlertControllerStyle.alert)
                alert.addAction(UIAlertAction(title: "OK", style: UIAlertActionStyle.default, handler: nil))
                self.present(alert, animated: true, completion: nil)
                
            }  else if self.passwordTextField.text != self.confirmPasswordTextField.text {
                let alert = UIAlertController(title: "Alert", message: "Confirmation Password must match your Password", preferredStyle: UIAlertControllerStyle.alert)
                alert.addAction(UIAlertAction(title: "OK", style: UIAlertActionStyle.default, handler: nil))
                self.present(alert, animated: true, completion: nil)
            } else if !self.tosCheckBoxButton.isSelected {
                let alert = UIAlertController(title: "Alert", message: "Please agree to Terms of Service and Privacy Policy.", preferredStyle: UIAlertControllerStyle.alert)
                alert.addAction(UIAlertAction(title: "OK", style: UIAlertActionStyle.default, handler: nil))
                self.present(alert, animated: true, completion: nil)
            }
            else {
                self.showProgress()
                let body = String(format:"firstname=%@&lastname=%@&emailid=%@&password=%@&mobileno=%@&devicetype=1&deviceid=%@&referrerid=%@",self.firstNameTextField.text!,self.lastNameTextField.text!,self.emaiTextField.text!,self.passwordTextField.text!,self.mobilenumber.text!, (WebService.sharedInstance.getDeviceUUID()!), self.referredTextField.text!)
                
                let task = "Signup"
                WebService().sendAPIRequest(UrlClass.baseUrl, body: body,task: task) { (result, error) -> Void in
                    if result["status"] as! Int == 1
                    {
                        DispatchQueue.main.async(execute: { () -> Void in
                            self.hideProgress()
                            self.emaiTextField.text = ""
                            self.firstNameTextField.text = ""
                            self.lastNameTextField.text = ""
                            self.passwordTextField.text = ""
                            self.confirmPasswordTextField.text = ""
                            self.mobilenumber.text = ""
                            
                            

                            let refid = result["refid"] as! String
                            ///
                            self.alertController = UIAlertController(title: result["msg"] as? String, message:self.countDownString(), preferredStyle: .alert)
                            
                            
                            self.alertController.addAction(UIAlertAction(title: "Send", style: .default, handler: {
                                alert -> Void in
                                let textField = self.alertController.textFields![0] as UITextField
                                print(textField.text!)
                                self.timer!.invalidate()
                                //////
                                ////
                                let Raw_Code:String = String(format:"%@%@%@",WebService().getSALT,WebService.sharedInstance.getDeviceUUID()!,textField.text!,refid)
                                let AUTH_CODE:String = WebService().SHA1(Raw_Code)
                                
//                                self.showProgress()
                                let body = String(format:"otp=%@&refid=%@&authcode=%@", textField.text!,refid,AUTH_CODE)
                                let task = "verifyotp"
                                WebService().sendAPIRequest(UrlClass.baseUrl, body: body,task: task) { (result, error) -> Void in
                                    if result["status"] as! Int == 1
                                    {
                                        
                                        print("narendh")
                                        
                                    } else if result["status"] as! Int == 0
                                    {
                                        
                                        print("sumi")
                                        
                                        
                                    }
                                }
                                
                                
                                
                                
                                
                                
                                
                                
                                
                                
                                
                                
                                // do something with textField
                            }))
                            self.alertController.addAction(UIAlertAction(title: "Cancel", style: .cancel, handler: nil))
                            
                            self.alertController.addTextField(configurationHandler: {(textField : UITextField!) -> Void in
                                textField.placeholder = "OTP"
                            })
                            
//                            self.present(self.alertController, animated: true, completion: nil)
                            self.present(self.alertController, animated: true){
                                self.timer = Timer.scheduledTimer(timeInterval: 1, target: self, selector: #selector(self.decrease), userInfo: nil, repeats: true)
                            }
                            ///
                            
                            
                            
                            
                            
                            
//                            self.Alert("Alert Message", message: result["msg"] as! String)
                        })
                    } else if result["status"] as! Int == 0
                    {
                        DispatchQueue.main.async(execute: { () -> Void in
                            self.hideProgress()
                            self.displayAlert("Alert Message", message: result["msg"] as! String)
                        })
                        
                    }
                }
            }
            
            
        } else {
            self.displayAlert("Alert Message", message: "Please Check Internet connection")
            
        }

           }
    
    
    func alertView(_ alertView: UIAlertView, clickedButtonAt buttonIndex: Int)
    {
        if (buttonIndex == 0)
        {
        self.dismiss(animated: true, completion: nil)
        }
    }

   
    func keyboardWasShown(_ notification: Notification) {
        // Step 1: Get the size of the keyboard.
        let info : NSDictionary = (notification as NSNotification).userInfo! as NSDictionary
//        let keyboardSize = ((info.object(forKey: UIKeyboardFrameBeginUserInfoKey) as AnyObject).cgRectValue as CGRect!).size
        let keyboardSize = (info[UIKeyboardFrameBeginUserInfoKey] as? NSValue)!.cgRectValue
        // Step 2: Adjust the bottom content inset of your scroll view by the keyboard height.
        let contentInsets: UIEdgeInsets = UIEdgeInsetsMake(0.0, 0.0, keyboardSize.height, 0.0)
        self.theScrollView.contentInset = contentInsets
        self.theScrollView.scrollIndicatorInsets = contentInsets
        // Step 3: Scroll the target text field into view.
        var aRect: CGRect = self.view.frame
        aRect.size.height -= keyboardSize.height
        if !aRect.contains(activeTextField.frame.origin)
        {
            let scrollPoint: CGPoint = CGPoint(x: 0.0, y: activeTextField.frame.origin.y - (keyboardSize.height - 15))
            self.theScrollView.setContentOffset(scrollPoint, animated: true)
        }
    }
    
    func keyboardWillBeHidden(_ notification: Notification) {
        let contentInsets: UIEdgeInsets = UIEdgeInsets.zero
        self.theScrollView.contentInset = contentInsets
        self.theScrollView.scrollIndicatorInsets = contentInsets
    }
    
    
    ///
    @objc func decrease()
    {
        var minutes: Int
        var seconds: Int
        if(counter > 0) {
            self.counter -= 1
            print(counter)  // Correct value in console
            minutes = (counter % 3600) / 60
            seconds = (counter % 3600) % 60
            alertController.message = String(format: "%02d:%02d", minutes, seconds)
            print("\(minutes):\(seconds)")  // Correct value in console
        }
        else{
            
            self.alertController.addAction(UIAlertAction(title: "Resend", style: .default, handler: {
                alert -> Void in
                print("sumi")
                // do something with textField
            }))
//            dismiss(animated: true, completion: nil)
            timer!.invalidate()
        }
    }
    
    func alertMessage() -> String {
        print(message+"\(self.label)")
        return(message+"\(self.label)")
    }
    
    func countDownString() -> String {
        print("\(counter) seconds")
        return "\(counter) seconds"
    }
    ///
    
    
    
    
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool
    {
        if textField == referredTextField {
            return textField.resignFirstResponder()
        }
        let tag = textField.tag + 1
        let nextTextView = self.view.viewWithTag(tag) as? UITextField
        if nextTextView == nil {
            return textField.resignFirstResponder()
        }
        return nextTextView!.becomeFirstResponder()
    }
    
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    override func viewWillDisappear(_ animated: Bool)
    {
        NotificationCenter.default.removeObserver(self, name: NSNotification.Name.UIKeyboardDidHide, object: nil)
        NotificationCenter.default.removeObserver(self, name: NSNotification.Name.UIKeyboardWillHide, object: nil)
    }
    
    
    @IBAction func back(_ sender: AnyObject) {
        
        self.dismiss(animated: true, completion: nil)
    }
    
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
    }
    
    
    func getMlzInfo(_ tag : NSInteger)
    {
//        let body = String(format:"token=%@&pagenumer=1", NSUserDefaults.standardUserDefaults().objectForKey("token") as! String)
        
        let task = "getmlzinfo"
        WebService().sendAPIRequest(UrlClass.baseUrl, body: "",task: task) { (result, error) -> Void in
            if result["status"] as! Int == 1
            {
                var htmlString : String? = nil
                var title  = ""
                if tag == 1
                {
                    htmlString = result["termsofservice"] as? String
                    title = "Terms of Service"
                } else {
                    htmlString = result["privacypolicy"] as? String
                    title = "Privacy Policy"
                }
                htmlString = self.escapeHTMLCharacters(htmlString)
                DispatchQueue.main.async(execute: { () -> Void in
                    let data : [String]? = [htmlString!, title]
                    self.performSegue(withIdentifier: "infoSegue", sender: data)
                })
                
            }
        }
    }
    
    func escapeHTMLCharacters(_ htmlString : String?) -> String? {
        let entities = [
            "&quot;"    : "\"",
            "&amp;"     : "&",
            "&apos;"    : "'",
            "&lt;"      : "<",
            "&gt;"      : ">",
            ]
        var newString = htmlString
        for (name,value) in entities {
            newString = newString?.replacingOccurrences(of: name, with: value)
        }
        return newString
    }
    
    
    func Alert(_ title: String, message: String) {
        
        
        let createAccountErrorAlert = UIAlertView()
        
        createAccountErrorAlert.delegate = self
        
            createAccountErrorAlert.title = title
            createAccountErrorAlert.message = message
            createAccountErrorAlert.addButton(withTitle: "OK")
            createAccountErrorAlert.show()
    }
    
    
    @IBAction func termsofService(_ sender: AnyObject) {
        self.getMlzInfo(1)
    }

    @IBAction func privacyPolicy(_ sender: AnyObject) {
        self.getMlzInfo(2)
    }

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        let destinationVC = segue.destination as? WebViewController
        
        let data = sender as! [String]
        destinationVC?.htmlString = data[0]
        destinationVC?.title = data[1]
    }

    @IBAction func referrerCheckboxClicked(_ sender: AnyObject) {
        let button = sender as? CheckBoxButton
        if button?.isSelected == true {
            self.getReferrerId()
        } else {
            self.referrerLabel.text = ""
            self.referredTextField.text = ""
            self.referrerLabelHeight.constant = 0
        }
    }
}


