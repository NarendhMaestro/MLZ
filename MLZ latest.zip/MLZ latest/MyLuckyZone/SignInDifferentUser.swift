//
//  SignInDifferentUser.swift
//  MyLuckyZone
//
//  Created by Prabhu Swaminathan on 06/07/16.
//  Copyright © 2016 Adodis. All rights reserved.
//

import UIKit
import Foundation

class SignInDifferentUser : UIViewController, UITextFieldDelegate {
    @IBOutlet var messageTextView: UITextField!
    override func viewDidLoad() {
        super.viewDidLoad()
        self.messageTextView.delegate = self
        let backgroundImage = UIImageView(frame: UIScreen.main.bounds)
        backgroundImage.image = UIImage(named: "bg2.png")
        backgroundImage.contentMode = UIViewContentMode.scaleAspectFill
        self.view.insertSubview(backgroundImage, at: 0)
        
        messageTextView.layer.borderWidth = 1
        messageTextView.layer.borderColor = UIColor.white.cgColor
        
        
    }
    @IBAction func submitButtonClicked(_ sender: AnyObject) {
        //deviceuserchangerequest
        let message = self.messageTextView.text
        WebService.sharedInstance.deviceUserChangeRequest(message!, callback:  { (result: [String : AnyObject], error: AnyObject?)-> Void in
            DispatchQueue.main.async {
                self.dismiss(animated: true, completion: nil)
            }
        });
        
    }

    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        self.messageTextView.resignFirstResponder()
        return true
    }
    
    @IBAction func back(_ sender: AnyObject) {
        self.dismiss(animated: true, completion: nil)
    }
}
