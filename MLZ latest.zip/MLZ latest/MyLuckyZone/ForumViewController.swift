//
//  ForumViewController.swift
//  MyLuckyZone
//
//  Created by TechnoTackle on 28/12/16.
//  Copyright © 2016 Adodis. All rights reserved.
//

import UIKit
import AVKit
import AVFoundation

class ForumViewController: UIViewController,UITableViewDataSource , UITableViewDelegate {
    
    @IBOutlet weak var tableView: UITableView!
    var tableDataArray =  NSArray()
    var currentPage = NSInteger()
    var totalPage = NSInteger()
    var refreshControl: UIRefreshControl!
    
    override func viewDidLoad() {
        super.viewDidLoad()
    
        self.tableView.tableFooterView = UIView()
        // Do any additional setup after loading the view.
        refreshControl = UIRefreshControl()
        //refreshControl.attributedTitle = NSAttributedString(string: "Pull to refresh")
        refreshControl.addTarget(self, action: #selector(ForumViewController.refresh(_:)), for: UIControlEvents.valueChanged)
        self.tableView.addSubview(refreshControl)
        
        // Do any additional setup after loading the view.
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        self.tableView.isHidden = true
        self.currentPage = 1
        self.forumDataList()
    }
    
    func refresh(_ sender:AnyObject) {
        
        self.forumDataList()
        refreshControl.endRefreshing()
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
    
    func forumDataList()
    {
        if Reachability.isConnectedToNetwork() == true {
            self.showProgress()
            
            let body = String(format:"token=%@&pagenumer=%@", UserDefaults.standard.object(forKey: "token") as! String,String(currentPage))
            
            let task = "listallthreads"
            WebService().sendAPIRequest(UrlClass.baseUrl, body: body,task: task) { (result, error) -> Void in
                
                if result["status"] as! Int == 1
                {
                    self.totalPage = result ["totalpages"] as! NSInteger
                    
                    if(self.currentPage == 1)
                    {
                        self.tableDataArray = (result["threadslist"] as! NSArray).mutableCopy() as! NSMutableArray
                        
                    }
                    else
                    {
                        let newPageArr = result["threadslist"] as! NSArray
                        
                        let newArr = self.tableDataArray.mutableCopy() as? NSMutableArray
                        
                        for i in self.tableDataArray.count ..< self.tableDataArray.count+newPageArr.count
                        {
                            newArr!.insert(newPageArr[i-self.tableDataArray.count], at: i)
                        }
                        //self.tableDataArray
                        self.tableDataArray = newArr!
                        
                    }
                    print("Array.",self.tableDataArray)
                    
                    
                    DispatchQueue.main.async(execute: { () -> Void in
                        self.tableView.isHidden = false
                        self.hideProgress()
                        self.tableView .reloadData()
                    })
                    
                } else if result["status"] as! Int == 0 || result["status"] as! Int == -1
                {
                    DispatchQueue.main.async(execute: { () -> Void in
                        self.hideProgress()
                        self.displayAlert("Alert Message", message: result["msg"] as! String)
                    })
                }
                
            }
        }else{
            self.tableView.isHidden = true
            print("Nothing stored in NSUserDefaults yet. Set a value.")
        }
    }
    
    func numberOfSections(in tableView: UITableView) -> Int
    {
        return 1;
        
    }
    
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int
    {
        return self.tableDataArray.count
    }
    
    func calculateHeight(inString:String) -> CGFloat
        {
            let messageString = inString
            let attributes : [String : Any] = [NSFontAttributeName : UIFont.systemFont(ofSize: 15.0)]
            
            
            
            
            
            let paragraphStyle = NSMutableParagraphStyle();
            paragraphStyle.alignment = NSTextAlignment.center
            
            let attributedString = NSMutableAttributedString(string: messageString, attributes: attributes);
            attributedString.addAttribute(NSParagraphStyleAttributeName, value: paragraphStyle, range: NSMakeRange(0, messageString.characters.count))
            let rect : CGRect = attributedString.boundingRect(with: CGSize(width: 222.0, height: CGFloat.greatestFiniteMagnitude), options: .usesLineFragmentOrigin, context: nil)
    
            let requredSize:CGRect = rect
            return requredSize.height
        }
    
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        let messageString = try (self.tableDataArray.value(forKey: "title") as! NSArray)[indexPath.row] as? String
        
        print(messageString)
        
        let attributes : [String : Any] = [NSFontAttributeName : UIFont.systemFont(ofSize: 18.0)]
        let attributedString : NSAttributedString = NSAttributedString(string: messageString!, attributes: attributes)
        var rect : CGRect = attributedString.boundingRect(with: CGSize(width: self.view.frame.size.width - 20, height: CGFloat.greatestFiniteMagnitude), options: .usesLineFragmentOrigin, context: nil)
        rect.size.height += 30
        
        let requredSize:CGRect = rect
        
        return requredSize.height + 110.0
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell
    {
        //let cell = self.tableView.dequeueReusableCell(withIdentifier: "forumCell") as! UITableViewCell ForumTableViewCell
        let cell = self.tableView.dequeueReusableCell(withIdentifier: "forumCell", for: indexPath) as! ForumTableViewCell
        cell.selectionStyle = UITableViewCellSelectionStyle.none
        
        var value = "Answer :"
        do {
            //(cell.contentView.viewWithTag(1) as! UILabel).text = (self.tableDataArray.value(forKey: "title") as! NSArray)[indexPath.row] as? String
            
            let html = try (self.tableDataArray.value(forKey: "title") as! NSArray)[indexPath.row] as? String
            
            let htmlText = NSString(format: "<font style=\"font-size:18px\"><center> %@ </center></font>", html!)
            
            
            //cell.titleLbl.text = htmlText
            
            var atrStr = NSAttributedString()
            if let htmlData = htmlText.data(using: String.Encoding.unicode.rawValue) {
                do {
                    atrStr = try NSAttributedString(data: htmlData, options: [NSDocumentTypeDocumentAttribute: NSHTMLTextDocumentType], documentAttributes: nil)
                } catch let e as NSError {
                }
            }
            
             var recta : CGRect = atrStr.boundingRect(with: CGSize(width: self.view.frame.size.width - 20, height: CGFloat.greatestFiniteMagnitude), options: .usesLineFragmentOrigin, context: nil)
            recta.size.width = self.view.frame.size.width - 15
            recta.size.height += 30
            recta.origin.y = 7
            cell.titleLbl.frame = recta
            cell.titleLbl.attributedText = atrStr
            
            //@"<font face='HelveticaNeue-CondensedBold' size=20 stroke=1>Text with strokes</font> "
            
            
//            let aStr = String(format: "<font face='HelveticaNeue' size=15><p>%@</p></font>",htmlText!)
//            self.view.viewWithTag(indexPath.row * 9)?.removeFromSuperview()
//            let lbll = RTLabel(frame: cell.titleLbl.bounds)
//            lbll.tag = indexPath.row * 9
//            lbll.text = aStr
//            cell.titleLbl .addSubview(lbll)
            
            
            
            
            
            
            /*cell.titleLbl.numberOfLines = 0
            let messageString =  try (self.tableDataArray.value(forKey: "title") as! NSArray)[indexPath.row] as? String
            let attributes : [String : Any] = [NSFontAttributeName : UIFont.systemFont(ofSize: 15.0)]
            let attributedString : NSAttributedString = NSAttributedString(string: messageString!, attributes: attributes)
            var rect : CGRect = attributedString.boundingRect(with: CGSize(width: 230.0, height: CGFloat.greatestFiniteMagnitude), options: .usesLineFragmentOrigin, context: nil)
            // let requredSize:CGRect = rect
            rect.size.width = self.view.frame.size.width - 15
            rect.size.height += 30
            rect.origin.y = 7
            cell.titleLbl.frame = rect*/
            
            
            
//            do{
//                let aStr = String(format: "<!DOCTYPE html><html><body style=\"background-color:rgba(100, 100, 100, 0.1);\"><p>%@<p></body></html>", htmlText!) as NSString
//                let webPage = UIWebView(frame: cell.titleLbl.bounds)
//                webPage.loadHTMLString(aStr as String, baseURL: nil)
//                webPage.frame = rect
//                webPage.backgroundColor = UIColor.clear
//                cell.titleLbl.addSubview(webPage)
//                cell.titleLbl.backgroundColor = UIColor.clear
//            }
            
        } catch {
            //(cell.contentView.viewWithTag(1) as! UILabel).text = ""
            cell.titleLbl.text = ""
            print(error)
        }
        
        
        if cell.viewBottom != nil{
            var frames = try(cell.viewBottom.frame)
            frames.origin.y = cell.titleLbl.frame.size.height + 10
            cell.viewBottom.frame = frames
        }else{
            
        }
        
        do {
            //(cell.contentView.viewWithTag(10) as! UILabel).text = (self.tableDataArray.value(forKey: "createdby") as! NSArray)[indexPath.row] as? String
            
            cell.userLbl.text = try (self.tableDataArray.value(forKey: "createdby") as! NSArray)[indexPath.row] as? String
            
        }catch{
            // (cell.contentView.viewWithTag(10) as! UILabel).text = ""
            cell.userLbl.text = ""
            print(error)
        }
        do {
            //(cell.contentView.viewWithTag(20) as! UILabel).text = (self.tableDataArray.value(forKey: "createddate") as! NSArray)[indexPath.row] as? String
            
            cell.dateLbl.text = (self.tableDataArray.value(forKey: "createddate") as! NSArray)[indexPath.row] as? String
            
        }catch{
            //(cell.contentView.viewWithTag(20) as! UILabel).text = ""
            cell.dateLbl.text = ""
            print(error)
        }
        do {
            value.append(((self.tableDataArray.value(forKey: "noofanswers") as! NSArray)[indexPath.row] as? String)!)
            //(cell.contentView.viewWithTag(30) as! UILabel).text = value; //as? String
            cell.infoLbl.text = value
            
        }catch{
            //(cell.contentView.viewWithTag(30) as! UILabel).text = ""
            cell.infoLbl.text = ""
            print(error)
        }
        
        do{
            let value1 = (self.tableDataArray.value(forKey: "canmodify") as! NSArray)[indexPath.row] as? Int
            
            if(value1 == 1){
                cell.editView.isHidden = false
            }else
            {
                cell.editView.isHidden = true
            }
            
            cell.editBtn.addTarget(self, action: #selector(ForumViewController.editClick(_:)), for: .touchUpInside)
            cell.editBtn.tag = indexPath.row
            
        }catch{
            
        }
        
        cell.cellBtn.addTarget(self, action: #selector(ForumViewController.cellClicked(_:)), for: .touchUpInside)
        cell.cellBtn.tag = indexPath.row
        
        return cell
    }
    
    func cellClicked(_ sender:UIButton){
        
//        let ForumInnerViewController = storyboard?.instantiateViewController(withIdentifier: "ForumInnnerVC") as! FonumInnnerViewController
//        ForumInnerViewController.selectedId = (self.tableDataArray.value(forKey: "threadid") as! NSArray)[sender.tag] as? String
//        ForumInnerViewController.selectedDate = (self.tableDataArray.value(forKey: "createddate") as! NSArray)[sender.tag] as? String
//        ForumInnerViewController.selectedUser = (self.tableDataArray.value(forKey: "createdby") as! NSArray)[sender.tag] as? String
//        ForumInnerViewController.selectedTitle = (self.tableDataArray.value(forKey: "title") as! NSArray)[sender.tag] as? String
//        ForumInnerViewController.selectedAnswerCount = (self.tableDataArray.value(forKey: "noofanswers") as! NSArray)[sender.tag] as? String
//        self.navigationController?.pushViewController(ForumInnerViewController, animated: true)
        
        
        let ForumInnerViewController = storyboard?.instantiateViewController(withIdentifier: "ForumDetailVC") as! ForumDetailVC
        ForumInnerViewController.selectedId = (self.tableDataArray.value(forKey: "threadid") as! NSArray)[sender.tag] as? String
        ForumInnerViewController.selectedDate = (self.tableDataArray.value(forKey: "createddate") as! NSArray)[sender.tag] as? String
        ForumInnerViewController.selectedUser = (self.tableDataArray.value(forKey: "createdby") as! NSArray)[sender.tag] as? String
        ForumInnerViewController.selectedTitle = (self.tableDataArray.value(forKey: "title") as! NSArray)[sender.tag] as? String
        ForumInnerViewController.selectedAnswerCount = (self.tableDataArray.value(forKey: "noofanswers") as! NSArray)[sender.tag] as? String
        self.navigationController?.pushViewController(ForumInnerViewController, animated: true)
    }
    
    func editClick(_ sender:AnyObject) {
        
        view.endEditing(true)
        var tag : String!
        tag = (self.tableDataArray.value(forKey: "threadid") as! NSArray)[sender.tag] as? String//as! String
        print(tag)
        
        let alertController = UIAlertController(title: "Alert Message", message: "Do you want to Edit Or Delete the thread", preferredStyle: .alert)
        
        // Create the actions
        let okAction = UIAlertAction(title: "Edit", style: UIAlertActionStyle.default) {
            UIAlertAction in
            DispatchQueue.main.async(execute: { () -> Void in
                if Reachability.isConnectedToNetwork() == true {
                    self.showProgress()
                    
                    let body = String(format:"token=%@&threadid=%@", UserDefaults.standard.object(forKey: "token") as! String,tag!)
                    
                    let task = "getthreaddetail"
                    WebService().sendAPIRequest(UrlClass.baseUrl, body: body,task: task) { (result, error) -> Void in
                        
                        if result["status"] as! Int == 1
                        {
                            
                            DispatchQueue.main.async(execute: { () -> Void in
                                self.hideProgress()
                                
                                let addorEditViewController = self.storyboard?.instantiateViewController(withIdentifier: "AddorEditVC") as! AddorEditViewController
                                
                                addorEditViewController.TYPE = "Edit Your Answer"
                                addorEditViewController.Field1 = (result ["thread"] as AnyObject).value(forKey: "title") as! String!
                                
                                addorEditViewController.Field2 = (result ["thread"] as AnyObject).value(forKey: "description") as! String!
                                
                                addorEditViewController.selectedId = tag
                                
                                self.navigationController?.pushViewController(addorEditViewController, animated: true)
                                
                                
                            })
                            
                        } else if result["status"] as! Int == 0 || result["status"] as! Int == -1
                        {
                            DispatchQueue.main.async(execute: { () -> Void in
                                self.hideProgress()
                                self.displayAlert("Alert Message", message: result["msg"] as! String)
                            })
                        }
                        
                    }
                }else{
                    //self.tableView.isHidden = true
                    print("Nothing stored in NSUserDefaults yet. Set a value.")
                }
                
                
            })
        }
        let deleteAction = UIAlertAction(title: "Delete", style: UIAlertActionStyle.destructive) {
            UIAlertAction in
            DispatchQueue.main.async(execute: { () -> Void in
                self.deletePost(tag)
            })
        }
        let cancelAction = UIAlertAction(title: "Cancel", style: UIAlertActionStyle.cancel) {
            UIAlertAction in
            DispatchQueue.main.async(execute: { () -> Void in
                // self.navigationController?.popToRootViewController(animated: true)
                //self.navigationController?.popViewController(animated: true)
            })
        }
        
        alertController.addAction(okAction)
        alertController.addAction(deleteAction)
        alertController.addAction(cancelAction)
        
        // Present the controller
        self.present(alertController, animated: true, completion: nil)
    }
    
    func isNotNSNull(_ object:AnyObject) -> Bool {
        return object.classForCoder != NSNull.classForCoder()
    }
    
    func deletePost(_ sender:String){
        let alertController = UIAlertController(title: "Alert Message", message: "Do want to delete this thread", preferredStyle: .alert)
        
        // Create the actions
        let okAction = UIAlertAction(title: "Yes", style: UIAlertActionStyle.destructive) {
            UIAlertAction in
            DispatchQueue.main.async(execute: { () -> Void in
                //
                if Reachability.isConnectedToNetwork() == true {
                    self.showProgress()
                    
                    let body = String(format:"token=%@&threadid=%@", UserDefaults.standard.object(forKey: "token") as! String,sender)
                    
                    let task = "removethread"
                    WebService().sendAPIRequest(UrlClass.baseUrl, body: body,task: task) { (result, error) -> Void in
                        
                        if result["status"] as! Int == 1
                        {
                            DispatchQueue.main.async(execute: { () -> Void in
                                
                                self.hideProgress()
                                self.forumDataList()
                            })
                            
                        } else if result["status"] as! Int == 0 || result["status"] as! Int == -1
                        {
                            DispatchQueue.main.async(execute: { () -> Void in
                                self.hideProgress()
                                self.displayAlert("Alert Message", message: result["msg"] as! String)
                            })
                        }
                        
                    }
                }else{
                    //self.tableView.isHidden = true
                    print("Nothing stored in NSUserDefaults yet. Set a value.")
                }
            })
        }
        let deleteAction = UIAlertAction(title: "No", style: UIAlertActionStyle.cancel) {
            UIAlertAction in
            DispatchQueue.main.async(execute: { () -> Void in
                
            })
        }
        
        alertController.addAction(okAction)
        alertController.addAction(deleteAction)
        
        
        // Present the controller
        self.present(alertController, animated: true, completion: nil)
        
    }
    
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
//        let ForumInnerViewController = storyboard?.instantiateViewController(withIdentifier: "ForumInnnerVC") as! FonumInnnerViewController
//        ForumInnerViewController.selectedId = (self.tableDataArray.value(forKey: "threadid") as! NSArray)[indexPath.row] as? String
//        ForumInnerViewController.selectedDate = (self.tableDataArray.value(forKey: "createddate") as! NSArray)[indexPath.row] as? String
//        ForumInnerViewController.selectedUser = (self.tableDataArray.value(forKey: "createdby") as! NSArray)[indexPath.row] as? String
//        ForumInnerViewController.selectedTitle = (self.tableDataArray.value(forKey: "title") as! NSArray)[indexPath.row] as? String
//        ForumInnerViewController.selectedAnswerCount = (self.tableDataArray.value(forKey: "noofanswers") as! NSArray)[indexPath.row] as? String
//        self.navigationController?.pushViewController(ForumInnerViewController, animated: true)
        
        //self.performSegue(withIdentifier: "ForumInnner", sender: ["index" : (indexPath as NSIndexPath).row])// as UIViewController
        
    }
    func scrollViewDidEndDragging(_ scrollView: UIScrollView, willDecelerate decelerate: Bool) {
        
        let currentOffset = scrollView.contentOffset.y
        
        let maximumOffset = scrollView.contentSize.height - scrollView.frame.size.height
        
        
        if (maximumOffset - currentOffset <= 10)
        {
            
            if (self.currentPage == totalPage)
            {
                
            } else {
                self.currentPage = self.currentPage + 1
                
                //print(self.currentPage)
                
                self.forumDataList()
            }
            
        }
        
    }
    
    @IBAction func addThreadClick(_ sender: Any) {
        let addorEditViewController = storyboard?.instantiateViewController(withIdentifier: "AddorEditVC") as! AddorEditViewController
        addorEditViewController.TYPE = "Add New Thread"
        addorEditViewController.Field1 = ""
        addorEditViewController.Field2 = ""
        addorEditViewController.selectedId = ""
        
        self.navigationController?.pushViewController(addorEditViewController, animated: true)
        
        
    }
    
}
