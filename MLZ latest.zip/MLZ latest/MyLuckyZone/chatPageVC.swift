//
//  chatPageVC.swift
//  MyLuckyZone
//
//  Created by Maestro_MAC1 on 26/05/17.
//  Copyright © 2017 Adodis. All rights reserved.
//

import UIKit
import SDWebImage
import QuartzCore
import CoreFoundation

class chatPageVC: UIViewController, UITableViewDelegate, UITextViewDelegate, UITableViewDataSource, UIScrollViewDelegate, STBubbleTableViewCellDelegate, STBubbleTableViewCellDataSource, UIImagePickerControllerDelegate, UINavigationControllerDelegate {
    
    @IBOutlet var tableMain : UITableView!
    @IBOutlet var txtOwnMsg : UITextView!
    @IBOutlet var scroll : UIScrollView!
    @IBOutlet var viewForFooter : UIView!
    @IBOutlet var btnSend : UIButton!
    var messages = NSMutableArray()
    
    
    var timer = Timer()
    
    var totalPages : Int = 1
    var currentPage : Int = 1
    
    var unreadCount = 0
    var strDateToDisplay : NSString?
    
    var imageUrl : NSString?
    var strName : NSString?
    var userid : NSString?
    var receiverid : NSString?
    
    var lblHeader = UILabel()
    
    
    var arrMutable = NSMutableArray()
    
    var country : NSString!
    let baseUrlChat = "https://rawcaster.com/mlzwebservice/"
    let baseUrlImages = "https://rawcaster.com/"
    
    var nSelfValue = 0
    
    var activeField: UITextView?
    
    
    @IBOutlet weak var lblName: UILabel!
    @IBOutlet weak var profileImage: UIImageView!
    let refreshControl = UIRefreshControl()
    
    func refresh(sender:AnyObject) {
        
        if currentPage < totalPages{
            
            self.tableMain.headerView(forSection: 0)?.setNeedsDisplay()
            self.tableMain.headerView(forSection: 0)?.setNeedsLayout()
            
            refreshControl.attributedTitle = NSAttributedString(string: "Loading...")
            self.currentPage = self.currentPage + 1
            getConversationFormlzChat()
        }else{
            refreshControl.attributedTitle = NSAttributedString(string: "No More Messages...")
        }
        refreshControl.endRefreshing()
    }
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        
         self.tableMain.register(UINib.init(nibName: "chatMediaCell1", bundle: nil), forCellReuseIdentifier: "sendCell")
         self.tableMain.register(UINib.init(nibName: "ChatMediaCell", bundle: nil), forCellReuseIdentifier: "sentCell")
        self.tableMain.register(UINib.init(nibName: "ChatSendCell", bundle: nil), forCellReuseIdentifier: "chatSend")
        self.tableMain.register(UINib.init(nibName: "ChatReceiveCell", bundle: nil), forCellReuseIdentifier: "chatReceive")
        
        lblHeader = UILabel(frame: CGRect(x: (self.view.frame.size.width/2) - 40, y:75, width: 80, height:20))
        lblHeader.textAlignment = NSTextAlignment.center
        lblHeader.font = UIFont.systemFont(ofSize: 12.0)
        lblHeader.layer.cornerRadius = 5.0
        lblHeader.clipsToBounds = true
        lblHeader.backgroundColor = UIColor.init(colorLiteralRed: 175.0/255.0, green: 47.0/255.0, blue: 62.0/255.0, alpha: 1.0)
        self.view.addSubview(lblHeader)
        
        strDateToDisplay = ""
        
        print("%@",userid!)
        print("%@",receiverid!)
        
        currentPage = 1
        totalPages = 1
        
        let tap = UITapGestureRecognizer(target: self, action: #selector(chatPageVC.dismissKeyboard(_:)))
        self.view.addGestureRecognizer(tap)
        
        
        tableMain.delegate = self
        
        txtOwnMsg.layer.cornerRadius = 9.0
        txtOwnMsg.layer.borderWidth = 0.5
        txtOwnMsg.layer.borderColor = UIColor.black.cgColor
        txtOwnMsg.clipsToBounds = true
        
        
        refreshControl.attributedTitle = NSAttributedString(string: "Loading...")
        refreshControl.addTarget(self, action: #selector(self.refresh), for: UIControlEvents.valueChanged)
        tableMain.addSubview(refreshControl)
        
        
        DispatchQueue.main.async(execute: { () -> Void in
            self.lblName.text = self.strName! as String
            print(self.imageUrl!)
            self.profileImage.sd_setImage(with: URL(string: String(format:"https://rawcaster.com/%@" ,self.imageUrl! as String)))
            self.showProgress()
            self.getConversationFormlzChat()
        })
        
        
        let bundleID = Bundle.main.bundleIdentifier?.lowercased()
        self.country = "Nigiria"
        let range = bundleID?.range(of: "usa")
        if range != nil {
            self.country = "USA"
        }
        
        NotificationCenter.default.addObserver(self, selector: #selector(chatPageVC.keyboardWasShown(notification:)), name: .UIKeyboardDidShow, object: nil)
        NotificationCenter.default.addObserver(self, selector: #selector(chatPageVC.keyboardWillBeHidden(aNotification:)), name: .UIKeyboardDidHide, object: nil)
        

        //        viewForFooter.removeFromSuperview()
        //        self.tableMain.tableFooterView = viewForFooter
    }
    
    func makeMessage (str: NSString) -> (Message){
        return Message(string:str as String!)
    }
    
    override func viewWillAppear(_ animated: Bool) {
//        timer = Timer.scheduledTimer(timeInterval: 5, target: self, selector: #selector(self.updateMessages), userInfo: nil, repeats: true);
//        RunLoop.main.add(timer, forMode: RunLoopMode.commonModes)
        
        NotificationCenter.default.addObserver(self, selector: #selector(chatPageVC.updateMessage(notification:)), name: NSNotification.Name(rawValue: "checkMessages") , object: nil)
        self.updateMessages()
    }
    
    override func viewDidLayoutSubviews() {
        //        var frame = self.scroll.frame
        //        frame.size.height = self.view.frame.size.height - 70
        //        frame.origin.y = 70
        //        scroll.frame = frame
        //        //table
        //        frame.size.height -= 50
        //        self.tableMain.frame = frame
        //
        //        frame.size.height = 50
        //        frame.origin.y = self.scroll.frame.size.height - 50
        //        self.viewForFooter.frame = frame
    }
    
    
    func keyboardWasShown(notification: NSNotification)
    {
        var userInfo = notification.userInfo!
        var keyboardFrame:CGRect = (userInfo[UIKeyboardFrameBeginUserInfoKey] as! NSValue).cgRectValue
        keyboardFrame = self.view.convert(keyboardFrame, from: nil)
        
        var contentInset:UIEdgeInsets = self.scroll.contentInset
        contentInset.bottom = keyboardFrame.size.height
        self.scroll.contentInset = contentInset
        
        let bottomOffset = CGPoint(x: 0, y: scroll.contentSize.height - self.view.bounds.size.height + keyboardFrame.size.height + 70)
        scroll.setContentOffset(bottomOffset, animated: true)
    }
    
    func keyboardWillBeHidden(aNotification: NSNotification) {
        let contentInset:UIEdgeInsets = UIEdgeInsets.zero
        self.scroll.contentInset = contentInset
    }
    
    
    @IBAction func onBack(_ sender: Any) {
        self.dismiss(animated: true, completion: nil)
        self.navigationController?.popViewController(animated: true)
    }
    
    @IBAction func attach(_ sender: Any) {
        
        let imagePickerController = UIImagePickerController()
        imagePickerController.sourceType = UIImagePickerControllerSourceType.photoLibrary
        imagePickerController.delegate = self
        self.present(imagePickerController, animated: true, completion: nil)
    }
    
    //    - (void)uploadingData: (NSString *)fileName {
    //
    //    NSArray *directoryPathsArray = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
    //    NSString *documentsDirectory = [directoryPathsArray objectAtIndex:0];
    //
    //    NSString *absoluteFilePath = [NSString stringWithFormat:@"%@/%@/%@", documentsDirectory, baseDirName, fileName];
    //
    //    NSData *zipFileData = [NSData dataWithContentsOfFile:absoluteFilePath];
    //
    //    NSString *base64String = [zipFileData base64EncodedStringWithOptions:0];
    //
    //    base64String = [base64String stringByReplacingOccurrencesOfString:@"/"
    //    withString:@"_"];
    //
    //    base64String = [base64String stringByReplacingOccurrencesOfString:@"+"
    //    withString:@"-"];
    //
    //    // Adding to JSON and upload goes here.
    //    }
    
    
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [String : Any]) {
        let imageFile = info as NSDictionary
        let image = imageFile[UIImagePickerControllerOriginalImage] as! UIImage
        let imageData:NSData = UIImagePNGRepresentation(image)! as NSData
        
       // let strBase64 = imageData.base64EncodedString(options:NSData.Base64EncodingOptions(rawValue: 0))
       // print(strBase64)
        picker.dismiss(animated: true, completion: nil)
        
       // self.uploadImgeUsingAFNetwork(image: image)
       // self.UploadRequest(imageUP: image)
        self.sendChatWithImage("sendChatWithImage", image: image)
    }
    
    func sendChatWithImage(_ urlpath:String, image: UIImage)
    {
        let stringURl = "https://rawcaster.com/mlzwebservice/sendchat"
        let url:URL = URL(string: stringURl as String)!
        
        let request = NSMutableURLRequest(url: url)
        request.httpMethod = "POST"
        request.httpShouldHandleCookies = true
        
        let boundary = "------VohpleBoundary4QuqLuM1cE5lMwCy"
        
        let contentType = String(format:"multipart/form-data; boundary=%@", boundary)
        request.setValue(contentType, forHTTPHeaderField: "Content-Type")
        
        let ddata = txtOwnMsg.text.data(using: String.Encoding.nonLossyASCII)! as NSData
        let strr = " test message"//NSString(data: ddata as Data, encoding: String.Encoding.utf8.rawValue)// \ud83d\ude01
        let parameters = NSMutableDictionary()
        
        parameters.setValue(receiverid, forKey: "destination_id")
        parameters.setValue(strr, forKey: "message")
        parameters.setValue(UserDefaults.standard.string(forKey: "tokenChat"), forKey: "token")
        if(self.country == "USA")
        {
            parameters.setValue("2", forKey: "country")
        }else{
            parameters.setValue("1", forKey: "country")
        }
        
        print(parameters)
        
        let bodydata = NSMutableData()
       
        for (param1, params2) in parameters
        {
            let KeyValue = param1 as! String
            bodydata.append((String(format:"--%@\r\n", boundary).data(using: String.Encoding.utf8))!)
            bodydata.append((String(format:"Content-Disposition: form-data; name=\"%@\"\r\n\r\n", KeyValue).data(using: String.Encoding.utf8))!)
            bodydata.append((String(format:"%@\r\n", (parameters.value(forKey: KeyValue) as? String)!).data(using: String.Encoding.utf8))!)
            
        }
        let FileParamConstant = "msg_image"
        
        let imageData: NSData = UIImageJPEGRepresentation(image, 1)! as NSData
        
        if imageData.length != 0
        {
            bodydata.append((String(format:"--%@\r\n", boundary)) .data(using: String.Encoding.utf8)!)
            bodydata.append((String(format:"Content-Disposition: form-data; name=\"%@\"; filename=\"image.jpg\"\r\n", FileParamConstant)) .data(using: String.Encoding.utf8)!)
            bodydata.append(imageData as Data)
            bodydata.append((String(format:"\r\n", boundary)) .data(using: String.Encoding.utf8)!)
        }
        bodydata.append((String(format:"--%@--\r\n", boundary)) .data(using: String.Encoding.utf8)!)
        request.httpBody = bodydata as Data
        request.url = url
        let config = URLSessionConfiguration.default
        config.timeoutIntervalForRequest = 10
        let session = URLSession(configuration: config)
        let task = session.dataTask(with: request as URLRequest, completionHandler: { (data, response, error) -> Void in
            do
            {
                if error == nil {
                    let datastring = NSString(data: data!, encoding: String.Encoding.utf8.rawValue)
                    print("\(String(describing: datastring))")
                    let resultdic = try JSONSerialization.jsonObject(with: data!, options: JSONSerialization.ReadingOptions.allowFragments) as? [String:AnyObject]
                    print("Received Response \(resultdic!)")
                    if resultdic != nil {
                    }
                } else {
                }
            }
            catch
            {
                print("error")
                print(error)
            }
            
        })
        task.resume()
    }

    
    
    func UploadRequest(imageUP: UIImage)
    {
        let url = URL(string: "https://rawcaster.com/mlzwebservice/sendchat")
        
        let request = NSMutableURLRequest(url: url!)
        request.httpMethod = "POST"
        
        let boundary = generateBoundaryString()
        
        
        //request.setValue("multipart/form-data; boundary=\(boundary)", forHTTPHeaderField: "Content-Type")
        
        
        let image_data = UIImagePNGRepresentation(imageUP)
        if(image_data == nil)
        {
            return
        }
        let body = NSMutableData()
        
        let fname = "test.png"
        let mimetype = "image/png"
        
        
        
        
        //1
        body.append("--\(boundary)\r\n".data(using: String.Encoding.utf8)!)
        let ddata = txtOwnMsg.text.data(using: String.Encoding.nonLossyASCII)! as NSData
        var body1 = String(format:"token=%@&message=%@&destination_id=\(receiverid!)&country=",UserDefaults.standard.string(forKey: "tokenChat")!, "msssage image")
        if(self.country == "USA")
        {
            body1 = body1.appending("2")
        }else{
            body1 = body1.appending("1")
        }
        //Image
        //1
        body1 = body1.appending("&type=1")
        let bodyData = NSMutableData()
        bodyData.append(body1.data(using: String.Encoding.utf8)!)
        //2
//        body.append("--\(boundary)\r\n".data(using: String.Encoding.utf8)!)
//        body.append("Content-Disposition:form-data; name=\"test\"\r\n\r\n".data(using: String.Encoding.utf8)!)
//         body.append("\r\n".data(using: String.Encoding.utf8)!)
//        //3
//        body.append("--\(boundary)\r\n".data(using: String.Encoding.utf8)!)
//        body.append("Content-Disposition:form-data; name=\"msg_image\"; filename=\"\(fname)\"\r\n".data(using: String.Encoding.utf8)!)
//        body.append("Content-Type: \(mimetype)\r\n\r\n".data(using: String.Encoding.utf8)!)
//       // body.append(image_data!)
//        body.append("\r\n".data(using: String.Encoding.utf8)!)
//        body.append("--\(boundary)--\r\n".data(using: String.Encoding.utf8)!)
        
        
        request.httpBody = body as Data
        let session = URLSession.shared
        
        
        let task = session.dataTask(with: request as URLRequest, completionHandler: {
            (
            data, response, error) in
            do
            {
                if error == nil {
                    let datastring = NSString(data: data!, encoding: String.Encoding.utf8.rawValue)
                    print("\(datastring)")
                    let resultdic = try JSONSerialization.jsonObject(with: data!, options: JSONSerialization.ReadingOptions.allowFragments) as? [String:AnyObject]
                    print("Received Response \(resultdic!)")
                    
                    if resultdic?["status"] as! Int == 0{
                    self.displayAlert("Alert", message: resultdic?["msg"] as! String)
                    }
                } else
                {
                }
            }
            catch
            {
                print("error")
                print(error)
            }
            
            
            
            if let dataString = NSString(data: data!, encoding: String.Encoding.utf8.rawValue)
            {
                print(dataString)
            }
            
        })
        
        task.resume()
        
        
    }
    
    
    func generateBoundaryString() -> String
    {
        return "Boundary-\(UUID().uuidString)"
    }
    
    
    
    func uploadImage(image : UIImage)
    {
        let imageData = UIImagePNGRepresentation(image);
    
        let urlString = "https://rawcaster.com/mlzwebservice/sendchat"
        
               let ddata = txtOwnMsg.text.data(using: String.Encoding.nonLossyASCII)! as NSData
        let strr = NSString(data: ddata as Data, encoding: String.Encoding.utf8.rawValue)// \ud83d\ude01
        var body = String(format:"token=%@&message=%@&destination_id=\(receiverid!)&country=",UserDefaults.standard.string(forKey: "tokenChat")!, strr!)
        if(self.country == "USA")
        {
            body = body.appending("2")
        }else{
            body = body.appending("1")
        }
        //Image
        body = body.appending("&type=1")
        
        
        
        //New
        let stringURl = urlString as String
        let url:URL = URL(string: stringURl as String)!
        let request = NSMutableURLRequest(url: url)
        request.httpMethod = "POST"
        
        let bodydata = body.data(using: String.Encoding(rawValue: String.Encoding.utf8.rawValue))
        
        print("Making Request : \(stringURl)\nPost Data : \(body)")
        
        request.httpBody = bodydata
        
        let config = URLSessionConfiguration.default
        
        config.timeoutIntervalForRequest = 10
        
        let session = URLSession(configuration: config)
        
        let task = session.dataTask(with: request as URLRequest, completionHandler: { (data, response, error) -> Void in
            do
            {
                if error == nil {
                    var datastring = NSString(data: data!, encoding: String.Encoding.utf8.rawValue)
                    print("\(datastring)")
                    let resultdic = try JSONSerialization.jsonObject(with: data!, options: JSONSerialization.ReadingOptions.allowFragments) as? [String:AnyObject]
                    print("Received Response \(resultdic!)")
                    if resultdic != nil {
                    }
                } else {
                }
            }
            catch
            {
                print("error")
                print(error)
            }
            
        })
        task.resume()
        
        
    }
    
    
    
    
    
    func sendChat()
    {
        if Reachability.isConnectedToNetwork() == true {
            
            let ddata = txtOwnMsg.text.data(using: String.Encoding.nonLossyASCII)! as NSData
            let strr = NSString(data: ddata as Data, encoding: String.Encoding.utf8.rawValue)// \ud83d\ude01
            
            var body = String(format:"token=%@&message=%@&destination_id=\(receiverid!)&country=",UserDefaults.standard.string(forKey: "tokenChat")!, strr!)
            if(self.country == "USA")
            {
                body = body.appending("2")
            }else{
                body = body.appending("1")
            }
            let task = "sendchat"
            WebService().sendAPIRequest(baseUrlChat, body: body,task: task) { (result, error) -> Void in
                
                print(result)
                if result["status"] as! Int == 1
                {
                    DispatchQueue.main.async(execute: { () -> Void in
                        
                        
                    })
                }
            }
        } else {
            self.displayAlert("Alert Message", message: "Please Check Internet connection")
        }
    }
    
    
    func getConversationFormlzChat()
    {
        //self.showProgress()
        if Reachability.isConnectedToNetwork() == true {
            
            print(self.country)
            
            print( UserDefaults.standard.string(forKey: "userName")!)
            
            let body = String(format:"token=%@&destination_id=\(receiverid ?? "0")&pagenumber=\(currentPage)", UserDefaults.standard.string(forKey: "tokenChat")!)
            let task = "getconversationformlzchat"
            WebService().sendAPIRequest(baseUrlChat, body: body,task: task) { (result, error) -> Void in
                
                print(result)
                if result["status"] as! Int == 1
                {
                    DispatchQueue.main.async(execute: { () -> Void in
                        self.hideProgress()
                        var mtarr = NSMutableArray(array:result["chatlist"] as! NSArray)
                        let cp = result["currentpageno"] as! NSString
                        let tp = result["totalpages"] as AnyObject
                        self.currentPage = cp.integerValue
                        self.totalPages = tp.integerValue
                        let temp = NSMutableArray()
                        
                        //Initial
                        if self.currentPage == 1{
                            for item in mtarr{
                                if (item as! NSDictionary)["msg_content"] is String{
                                    temp.add(item)
                                }
                            }
                            mtarr = temp
                            self.messages =  NSMutableArray(array: mtarr.reverseObjectEnumerator().allObjects).mutableCopy() as! NSMutableArray
                        }else{
                            for item in mtarr{
                                if (item as! NSDictionary)["msg_content"] is String{
                                    temp.add(item)
                                }
                            }
                            mtarr = temp
                            
                            let nextPageMsg = NSMutableArray(array: mtarr.reverseObjectEnumerator().allObjects).mutableCopy() as! NSMutableArray
                            let ar1 = nextPageMsg as NSArray
                            let ar2 = self.messages.copy()
                            
                            self.messages.removeAllObjects()
                            self.messages.setArray(ar1 as! [Any])
                            
                            print(self.messages)
                            print(ar2)
                            
                            for obj in ar2  as! [AnyObject]{
                                //let dicAr = obj as! NSDictionary
                                self.messages.add(obj)
                            }
                        }
                        self.tableMain.reloadData()
                    })
                }else{
                    DispatchQueue.main.async(execute: { () -> Void in
                        self.hideProgress()
                    })
                }
            }
        } else {
            self.displayAlert("Alert Message", message: "Please Check Internet connection")
        }
    }
    
    func convertToString(_ fileName: NSString) -> NSString{
        return " "
    }
    
    

    
    func scrollViewDidScroll(_ scrollView: UIScrollView)
    {
        self.updateHeadr()
    }
    
    
    func scrollViewDidEndDecelerating(_ scrollView: UIScrollView) {
        self.updateHeadr()
    }
    
    @IBAction func sendMessage(_ sender: Any){
        
        if txtOwnMsg.text! != ""{
            self.sendChat()
            let dictMsg = NSMutableDictionary()
            
            let ddata = txtOwnMsg.text.data(using: String.Encoding.nonLossyASCII)! as NSData
            let strr = NSString(data: ddata as Data, encoding: String.Encoding.utf8.rawValue)// \ud83d\ude01
            dictMsg.setValue(strr!, forKey: "msg_content")
            
            let formatter = DateFormatter()
            formatter.dateFormat = "dd-MM-yyy hh:mm:ss"
            let strdate = formatter.string(from: Date())
            dictMsg.setValue(strdate, forKey: "msg_date")
            dictMsg.setValue(receiverid!, forKey: "msg_destinationid")
            //dictMsg.setValue("", forKey: "msg_imagetype")
            dictMsg.setValue(userid!, forKey: "msg_sourceid")
            self.messages.add(dictMsg as NSDictionary)
            self.tableMain.reloadData()
            
            let path = NSIndexPath(row: self.messages.count-1, section: 0)
            self.tableMain.scrollToRow(at: path as IndexPath, at: UITableViewScrollPosition.top, animated: true)
            txtOwnMsg.text = "";
        }
    }
    
    func dismissKeyboard(_ sender: UITapGestureRecognizer) {
        scroll.contentOffset = CGPoint(x:0, y:0)
        self.view.endEditing(true)
    }
    
    func textViewDidBeginEditing(_ textView: UITextView) {
        //scroll.contentOffset = CGPoint(x:0, y:self.view.frame.size.height);
        self.activeField =  txtOwnMsg
        
    }
    
    func textViewDidEndEditing(_ textView: UITextView) {
        self.activeField = nil
    }
    
    
    func numberOfSections(in tableView: UITableView) -> Int {
        // #warning Incomplete implementation, return the number of sections
        return 1
    }
    
    //    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
    //        return 20
    //    }
    
    func seperateSections()
    {
        let arrMut = NSMutableArray()
        for item in self.messages
        {
            let dict = item as! NSDictionary
            if dict["msg_date"] is String{
                let array = (dict["msg_date"] as! NSString).components(separatedBy: " ") as NSArray
                arrMut.add(array.object(at: 0))
            }
        }
        let orderedSet = NSOrderedSet(array:arrMut as! [Any])
        let sections = orderedSet.array
        
        
        let sectionArrays = NSMutableArray()
        for item in self.messages
        {
            let dict = item as! NSDictionary
            let str = dict["msg_date"] as! NSString
            if str.contains(""){
                
            }
        }
    }
    
    //    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
    //
    //        let view = UIView(frame: CGRect(x: 0, y:0, width: self.view.frame.size.width, height:20))
    //        view.backgroundColor = UIColor.clear
    //
    //        let viewHeader = UILabel(frame: CGRect(x: (self.view.frame.size.width/2) - 40, y:0, width: 80, height:20))
    //        viewHeader.textAlignment = NSTextAlignment.center
    //        viewHeader.font = UIFont.systemFont(ofSize: 12.0)
    //        viewHeader.layer.cornerRadius = 5.0
    //        viewHeader.clipsToBounds = true
    //        viewHeader.backgroundColor = UIColor.init(colorLiteralRed: 175.0/255.0, green: 47.0/255.0, blue: 62.0/255.0, alpha: 1.0)
    //        if self.messages.count >  0{
    //
    //            if strDateToDisplay as String? == ""
    //            {
    //                let dict = self.messages.lastObject as! NSDictionary
    //                let array = (dict["msg_date"] as! NSString).components(separatedBy: " ") as NSArray
    //                strDateToDisplay = array.object(at: 0) as? NSString
    //            }
    //            viewHeader.text = strDateToDisplay as String?
    //        }
    //
    //        view.addSubview(viewHeader)
    //        return view
    //    }
    
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return messages.count
    }
    
    func updateMessages()
    {
        self.getConversationFormlzChat()
    }
    
    func updateMessage(notification: NSNotification){
        self.getConversationFormlzChat()
    }
    
    func updateHeadr()
    {
        let visibleRows = self.tableMain.indexPathsForVisibleRows
        let indexes = visibleRows?.last
        let dict = self.messages.object(at: (indexes?.row)!) as! NSDictionary
        let array = (dict["msg_date"] as! NSString).components(separatedBy: " ") as NSArray
        strDateToDisplay = array.object(at: 0) as? NSString
        
        
        if self.messages.count >  0{
            
            if strDateToDisplay as String? == ""
            {
                let dict = self.messages.lastObject as! NSDictionary
                let array = (dict["msg_date"] as! NSString).components(separatedBy: " ") as NSArray
                strDateToDisplay = array.object(at: 0) as? NSString
            }
            
            let date = Date()
            let formatter = DateFormatter()
            formatter.dateFormat = "dd-MM-yyyy"
            let result = formatter.string(from: date)
            if result == strDateToDisplay! as String
            {
                strDateToDisplay = "Today"
            }
            lblHeader.text = strDateToDisplay as String?
        }
        
        //self.tableMain.tableHeaderView = viewHeader
    }
    
    
    func tableView(_ tableView: UITableView, willDisplay cell: UITableViewCell, forRowAt indexPath: IndexPath) {
        self.updateHeadr()
    }
    
    
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        
        //let CellIdentifier = "Bubble Cell"
        
        //var cell = tableView.dequeueReusableCell(withIdentifier: "Bubble Cell", for: indexPath) as! STBubbleTableViewCell
        
        
        
     //  var cell = STBubbleTableViewCell()
       // cell.selectionStyle = UITableViewCellSelectionStyle.none
        
//        if cell == nil{
//            cell = STBubbleTableViewCell()
//        }
       // cell.backgroundColor = UIColor.clear
       // cell.dataSource = self
       // cell.delegate = self
        
        
        //time height
        var strMsg = NSString()
        do {
            strMsg = (self.messages.object(at: indexPath.row) as! NSDictionary).value(forKey: "msg_content") as! NSString
        } catch {
            strMsg = txtOwnMsg.text! as NSString
            let ddata = txtOwnMsg.text.data(using: String.Encoding.nonLossyASCII)! as NSData
            let strr = NSString(data: ddata as Data, encoding: String.Encoding.utf8.rawValue)// \ud83d\ude01
            strMsg = strr!
        }
        
        let emojiEscaped = strMsg as String
        let emojiData = emojiEscaped.data(using: String.Encoding.utf8)
        let emojiString = NSString(data:emojiData! ,encoding:String.Encoding.nonLossyASCII.rawValue)
        strMsg = emojiString!
        
        
        let messages = self.makeMessage(str: strMsg)
        
        
       // cell.textLabel?.font = UIFont.systemFont(ofSize: 14.0)
       // cell.textLabel?.text = messages.message;
       // cell.imageView?.image = messages.avatar;
        
        let dictRow = self.messages.object(at: indexPath.row) as! NSDictionary
        
        if self.isNotNSNull((self.messages.object(at: indexPath.row) as! NSDictionary).value(forKey: "msg_imagetype") as AnyObject)
        {
                if self.isNotNSNull((self.messages.object(at: indexPath.row) as! NSDictionary).value(forKey: "msg_image") as AnyObject)
                {
              //  let imageView = UIImageView(frame: CGRect(x:0, y:0, width:cell.frame.size.height, height:cell.frame.size.height))
                let imageData = Data(base64Encoded: (self.messages.object(at: indexPath.row) as! NSDictionary).value(forKey: "msg_image") as! String, options: Data.Base64DecodingOptions(rawValue: UInt(0)))
                if imageData != nil{
                  //  imageView.image = UIImage.init(data: imageData!)
                  //  cell.addSubview(imageView)
                }
                }
        }
        
        let serializedDate:String = dictRow["msg_date"] as! String
        let dateArr = serializedDate.components(separatedBy: " ") as NSArray
        let dateArr2 = (dateArr.object(at: 1) as! String).components(separatedBy: ":")  as NSArray
        let timeSt = dateArr2.object(at: 0) as! NSString
        var time : Int = 0
        time = timeSt.integerValue
        var strAMPM = ""
        if time > 12{
            time -= 12
            strAMPM = "PM"
        }else{
            strAMPM = "AM"
        }
        let dateString = String(format:"\(time):%@ \(strAMPM)", dateArr2.object(at: 0) as! String, dateArr2.object(at: 1) as! String)
        
        //print(cell.frame)
       // print(cell.bubbleView.frame)
        
        
        var size:(CGRect)
        let attr = [NSFontAttributeName:UIFont.systemFont(ofSize: 18.0)]
        
        size = (messages.message! as NSString).boundingRect(with:CGSize(width:tableMain.frame.size.width - (self.minInset(for: nil, at: indexPath)) - STBubbleWidthOffset, height:9999), options: NSStringDrawingOptions.usesLineFragmentOrigin, attributes: attr, context: nil)
        
        if size.size.height > 150 && size.size.height < 200{
            size.size.height -= 30
        }
        else if size.size.height > 200 && size.size.height < 250{
            size.size.height -= 40
        }
        else if size.size.height > 250 && size.size.height < 300{
            size.size.height -= 50
        }
        else if size.size.height > 300 && size.size.height < 350{
            size.size.height -= 70
        }
        else if size.size.height > 350{
            size.size.height -= 80
        }
        
        
//        let lblDate = UILabel(frame:CGRect(x:cell.frame.size.width, y:cell.bubbleView.frame.size.height + size.size.height, width:70, height:10))
//        lblDate.font = UIFont.systemFont(ofSize: 8.0)
//        lblDate.textAlignment = NSTextAlignment.left
//        lblDate.text = dateString
        
//        let sent = UIImageView(frame:CGRect(x:cell.frame.size.width + 38, y:cell.bubbleView.frame.size.height + size.size.height, width:10, height:10))
//        sent.image = UIImage.init(named: "sent")
        
        
        let str1 = (dictRow["msg_destinationid"] as! NSString).integerValue
        let str2 = userid?.integerValue
        
        if str1 != str2 {
          //  cell.authorType = AuthorType.STBubbleTableViewCellAuthorTypeSelf
          //  cell.bubbleColor = BubbleColor.STBubbleTableViewCellBubbleColorGreen
          //  cell.addSubview(sent)
            
        }else{
          //  cell.authorType = AuthorType.STBubbleTableViewCellAuthorTypeOther;
          //  cell.bubbleColor = BubbleColor.STBubbleTableViewCellBubbleColorGray;
          //  lblDate.frame = CGRect(x:cell.bubbleView.frame.size.width - 40, y:cell.bubbleView.frame.size.height - 15, width:70, height:10)
        }
       // cell.addSubview(lblDate)
        
        if self.isNotNSNull((self.messages.object(at: indexPath.row) as! NSDictionary).value(forKey: "msg_imagetype") as AnyObject)
        {
                if str1 != str2 //self
                {
                    var cel = tableView.dequeueReusableCell(withIdentifier: "sentCell", for: indexPath) as! ChatMediaCell
                    
                    
                    // var celll = (tableView.dequeueReusableCell(withIdentifier: "sendCell") as? chatMediaCell1)
                    
                    if cel == nil{
                        var nib: [Any] = Bundle.main.loadNibNamed("sentCell", owner: self, options: nil)!
                        cel = (nib[0] as? ChatMediaCell)!
                    }
                    
                    cel.selectionStyle = UITableViewCellSelectionStyle.none
                    
                    
                   
                    
                    if self.isNotNSNull((self.messages.object(at: indexPath.row) as! NSDictionary).value(forKey: "msg_image") as AnyObject)
                    {
                         let imageUR = (self.messages.object(at: indexPath.row) as! NSDictionary).value(forKey: "msg_image")
                    cel.chatSendMediaImageView.sd_setImage(with: URL(string: String(format:"https://rawcaster.com/%@" ,imageUR as! String)))
                    }
                    
                    cel.chatSendTimeLbl.text = dateString
                    if self.isNotNSNull(dictRow["msg_content"]  as AnyObject){
                        
                        cel.chatSendMsgLbl.text = dictRow["msg_content"] as! String
                    }else{
                       cel.chatSendMsgLbl.text = "" 
                    }
                    
                    
                    cel.backgroundColor = UIColor.clear
                    return cel
                }
                else
                {
                    var celll = tableView.dequeueReusableCell(withIdentifier: "sendCell", for: indexPath) as! chatMediaCell1

                    
                   // var celll = (tableView.dequeueReusableCell(withIdentifier: "sendCell") as? chatMediaCell1)
                    
                    if celll == nil{
                        var nib: [Any] = Bundle.main.loadNibNamed("sendCell", owner: self, options: nil)!
                        celll = (nib[0] as? chatMediaCell1)!
                    }

                    celll.selectionStyle = UITableViewCellSelectionStyle.none
                    
                    
                    let imageUR = (self.messages.object(at: indexPath.row) as! NSDictionary).value(forKey: "msg_image")
                    celll.chatSendMediaImageView.sd_setImage(with: URL(string: String(format:"https://rawcaster.com/%@" ,imageUR as! String)))
                    
                    celll.chatSendTimeLbl.text = dateString
                    
                    
                    if self.isNotNSNull(dictRow["msg_content"]  as AnyObject){
                        
                        celll.chatSendMsgLbl.text = dictRow["msg_content"] as! String
                    }else{
                        celll.chatSendMsgLbl.text = ""
                    }
                    
                    
                    
                    celll.backgroundColor = UIColor.clear
                    return celll
                }
        }else{
            
            if str1 != str2 //self
            {
                var cel = tableView.dequeueReusableCell(withIdentifier: "chatSend", for: indexPath) as! ChatTableViewCellXIBTableViewCell
                
                if cel == nil{
                    var nib: [Any] = Bundle.main.loadNibNamed("chatSend", owner: self, options: nil)!
                    cel = (nib[0] as? ChatTableViewCellXIBTableViewCell)!
                }
                
                cel.selectionStyle = UITableViewCellSelectionStyle.none
                if self.isNotNSNull((self.messages.object(at: indexPath.row) as! NSDictionary).value(forKey: "msg_image") as AnyObject)
                {
                    let imageUR = (self.messages.object(at: indexPath.row) as! NSDictionary).value(forKey: "msg_image")
                    cel.chatImageView.sd_setImage(with: URL(string: String(format:"https://rawcaster.com/%@" ,imageUR as! String)))
                }
                
                cel.chatTimeLabel.text = dateString
                if self.isNotNSNull(dictRow["msg_content"]  as AnyObject){
                    
                    cel.chatMessageLabel.text = dictRow["msg_content"] as? String
                }else{
                    cel.chatMessageLabel.text = ""
                }
                
                
                cel.backgroundColor = UIColor.clear
                return cel
            }
            else
            {
                var celll = tableView.dequeueReusableCell(withIdentifier: "chatReceive", for: indexPath) as! ChatTableViewCellXIBTableViewCell
                
                
                if celll == nil{
                    var nib: [Any] = Bundle.main.loadNibNamed("chatReceive", owner: self, options: nil)!
                    celll = (nib[0] as? ChatTableViewCellXIBTableViewCell)!
                }
                
                celll.selectionStyle = UITableViewCellSelectionStyle.none
                
            
                let dict = self.messages.object(at: indexPath.row);
                
                if self.isNotNSNull((self.messages.object(at: indexPath.row) as! NSDictionary).value(forKey: "msg_imagetype") as AnyObject)
                {
                    let imageUR = (self.messages.object(at: indexPath.row) as! NSDictionary).value(forKey: "msg_image")
                    celll.chatImageView.sd_setImage(with: URL(string: String(format:"https://rawcaster.com/%@" ,imageUR as! String)))
                }
                if self.isNotNSNull(dateString as AnyObject)
                {
                    celll.chatTimeLabel.text = dateString
                }
                
                
                
                if self.isNotNSNull(dictRow["msg_content"]  as AnyObject){
                    
                    celll.chatMessageLabel.text = dictRow["msg_content"] as? String
                }else{
                    celll.chatMessageLabel.text = ""
                }
                
                
                
                celll.backgroundColor = UIColor.clear
                return celll
        }
    }
        
    }
    
    func isNotNSNull(_ object:AnyObject) -> Bool {
        return object.classForCoder != NSNull.classForCoder()
    }
    
    
    func minInset(for cell: STBubbleTableViewCell!, at indexPath: IndexPath!) -> CGFloat {
        if(UIInterfaceOrientationIsLandscape(self.interfaceOrientation))
        {
            return 100.0;
        }
        return 50.0;
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        
        var message = Message()
        do {
            message = self.makeMessage(str: (self.messages.object(at: indexPath.row) as! NSDictionary).value(forKey: "msg_content") as! NSString)
        } catch {
            message = self.makeMessage(str: txtOwnMsg.text! as NSString)
        }
        
        var size:(CGRect)
        let attr = [NSFontAttributeName:UIFont.systemFont(ofSize: 18.0)]
        
        if (message.avatar != nil)
        {
            size = (message.message! as NSString).boundingRect(with:CGSize(width:tableMain.frame.size.width - (self.minInset(for: nil, at: indexPath)) - STBubbleImageSize - 8.0 - STBubbleWidthOffset, height:9999), options: NSStringDrawingOptions.usesLineFragmentOrigin, attributes: attr, context: nil)
        }else{
            size = (message.message! as NSString).boundingRect(with:CGSize(width:tableMain.frame.size.width - (self.minInset(for: nil, at: indexPath)) - STBubbleWidthOffset, height:9999), options: NSStringDrawingOptions.usesLineFragmentOrigin, attributes: attr, context: nil)
        }
        
        
        if size.size.height + 15.0 < STBubbleImageSize + 4.0 && message.avatar != nil {
            return STBubbleImageSize + 4.0
        }
        
        
        
        if self.isNotNSNull((self.messages.object(at: indexPath.row) as! NSDictionary).value(forKey: "msg_imagetype") as AnyObject)
        {
            var Namesize  = CGSize()
            var Timesize  = CGSize()
            var Messagesize = CGSize()
            var Totalsize = CGSize()
            let dictRow = self.messages.object(at: indexPath.row) as! NSDictionary
            
            // let fontArray = NSArray((UIFont.systemFont(ofSize: 18.0))
            
            Namesize = ((dictRow["msg_destinationid"] as! NSString) as NSString).boundingRect(with: CGSize(width: 220.0, height: .greatestFiniteMagnitude),
                                                                                              options: NSStringDrawingOptions.usesLineFragmentOrigin,
                                                                                              attributes: [NSFontAttributeName: UIFont.systemFont(ofSize: 18.0)],
                                                                                              context: nil).size
            
            if self.isNotNSNull(dictRow["msg_content"]  as AnyObject){
                Messagesize = ((dictRow["msg_content"] as! NSString) as NSString).boundingRect(with: CGSize(width: 220.0, height: .greatestFiniteMagnitude),
                                                                                               options: NSStringDrawingOptions.usesLineFragmentOrigin,
                                                                                               attributes: [NSFontAttributeName: UIFont.systemFont(ofSize: 18.0)],
                                                                                               context: nil).size
            }
            
            
            
            
            Timesize = ((dictRow["msg_date"] as! NSString) as NSString).boundingRect(with: CGSize(width: 220.0, height: .greatestFiniteMagnitude),
                                                                                     options: NSStringDrawingOptions.usesLineFragmentOrigin,
                                                                                     attributes: [NSFontAttributeName: UIFont.systemFont(ofSize: 18.0)],
                                                                                     context: nil).size
            
            
            Totalsize.height = Messagesize.height + Namesize.height + Timesize.height + 48.0
            return Totalsize.height + 45.0;
        }
        return 150.0//size.size.height + 25.0
    }
    func tappedImage(of cell: STBubbleTableViewCell!, at indexPath: IndexPath!) {
        let message = self.messages.object(at: indexPath.row) as! Message
        print(message.message)
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
}
