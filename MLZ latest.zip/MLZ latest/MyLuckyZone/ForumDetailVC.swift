//
//  ForumDetailVC.swift
//  MyLuckyZone
//
//  Created by Maestro_MAC1 on 19/05/17.
//  Copyright © 2017 Adodis. All rights reserved.
//

import UIKit

class ForumDetailVC: UIViewController, UIWebViewDelegate, UITextViewDelegate,UIGestureRecognizerDelegate, UITableViewDataSource, UITableViewDelegate {

    
    var selectedId:String?
    var selectedTitle:String?
    var selectedAnswerCount:String?
    var selectedDate:String?
    var selectedUser:String?
    var selectedDesc:String?
    var selectedAnswerId:String?
    var currentPage = NSInteger()
    var totalPage = NSInteger()
    var arrAnswers = NSArray()
    
    @IBOutlet weak var answerEditView: UIView!
    @IBOutlet weak var txtUpdateView: UITextView!
    
    
    @IBOutlet weak var scroll: UIScrollView!
    @IBOutlet weak var lblTitle: UILabel!
    @IBOutlet weak var lblName: UILabel!
    @IBOutlet weak var lblTime: UILabel!
    @IBOutlet weak var lblAnswersCountTop: UILabel!
    @IBOutlet weak var webPage: UIWebView!
    @IBOutlet weak var txtField: UITextField!
    @IBOutlet weak var viewComment: UIView!
    @IBOutlet weak var viewAnswers: UIView!
    @IBOutlet weak var lblAnswersCount: UILabel!
    @IBOutlet weak var tableMain: UITableView!
    
    @IBOutlet weak var activity: UIActivityIndicatorView!
    @IBOutlet weak var btnPost : UIButton!
    @IBOutlet weak var txtView: UITextView!
    
    var tap = UITapGestureRecognizer()
    
    
    func handleTap(sender: UITapGestureRecognizer? = nil) {
        // handling code
        txtView.endEditing(true)
        txtView.resignFirstResponder()
            }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        self.answerEditView.isHidden = true
        
       // self.tableMain.isHidden = true
        self.currentPage = 1
       // self.loadData()
    }
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        currentPage = 1
        
      //  self.tableMain.register(UITableView.self, forCellReuseIdentifier: "answerForumCell")
       // self.tableMain.register(UITableViewCell.self, forCellReuseIdentifier: "CellAnswer")

        // Do any additional setup after loading the view.
        
        tap = UITapGestureRecognizer(target: self, action: #selector(self.handleTap(sender:)))
        tap.delegate = self
        
        txtField.layer.cornerRadius = 6.0
        txtField.clipsToBounds = true
        
        txtView.layer.borderColor = UIColor.black.cgColor.copy(alpha: 0.5);
        txtView.layer.borderWidth = 1.0;
        txtView.layer.cornerRadius = 5.0;
        
        
        
        webPage.backgroundColor = UIColor.white.withAlphaComponent(0.9)
        
        webPage.layer.borderWidth = 1
        webPage.layer.borderColor = UIColor.gray.cgColor.copy(alpha: 0.2)
        
        
        btnPost.layer.cornerRadius = 5
        btnPost.layer.borderWidth = 1
        btnPost.layer.borderColor = UIColor.black.cgColor
        
        self.tableMain.dataSource = self
        self.tableMain.delegate = self //as! UITableViewDelegate
        
        
         self.loadPrimData()
        self.loadData()
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func loadData()
    {
        //title
        self.lblTitle.text = self.selectedTitle
        self.lblTime.text = selectedDate
        
        let textRange = NSMakeRange(0, (selectedUser?.characters.count)!)
        let attributedText = NSMutableAttributedString(string: selectedUser!)
        attributedText.addAttribute(NSUnderlineStyleAttributeName , value: NSUnderlineStyle.styleSingle.rawValue, range: textRange)
        attributedText.addAttribute(NSFontAttributeName, value: UIFont.italicSystemFont(ofSize: 17.0), range: textRange)
        self.lblName.attributedText = attributedText
        
        
        //Answers count
        
        var str = "Answers("
        if (self.selectedAnswerCount == "0")//(self.selectedAnswerCount?.isEmpty)! || self.selectedAnswerCount as! Integer == 0
        {
          viewAnswers.isHidden = true
          str = "Answers()"
        }
        else
        {
             self.getAnswerData()
            
             viewAnswers.isHidden = false
            str = str.appending(self.selectedAnswerCount!)
            str = str.appending(")")
        }
        self.lblAnswersCount.text = str
        self.lblAnswersCountTop.text = str
        
        //Descriptions
        webPage.isOpaque = false
        webPage.backgroundColor = UIColor.white.withAlphaComponent(0.5)
        
        if self.selectedDesc != nil {
            print(self.selectedDesc!)
            let aStr = String(format: "%@",self.selectedDesc!)
            webPage.loadHTMLString(aStr, baseURL: nil)
        }else{
            
            let aStr = String(format: "<p>%@</p>",self.selectedTitle!)
            webPage.loadHTMLString(aStr, baseURL: nil)
        }
        
        DispatchQueue.main.async(execute: { () -> Void in
            self.hideProgress()
        })
    }
    
    func webViewDidFinishLoad(_ webView: UIWebView) {
        activity.stopAnimating()
        
//        let height = webView.scrollView.contentSize.height
//        var wRect = webView.frame
//        
//        wRect.size.height = height
//        webView.frame = wRect
//        
//        
//        
//        var frame = viewComment.frame
//        var lastYPos = webPage.frame.origin.y + webPage.frame.size.height
//        //comments
//        frame.origin.y = lastYPos
//        viewComment.frame = frame
//        lastYPos = viewComment.frame.size.height + viewComment.frame.origin.y
//        //Answer
//        frame = viewAnswers.frame
//        frame.origin.y = lastYPos
//        viewAnswers.frame = frame
    }
    
    //Text view Delegates
    func textViewDidBeginEditing(_ textView: UITextView) {
        self.view.addGestureRecognizer(tap)
    }
    
    func textViewDidEndEditing(_ textView: UITextView) {
        self.view.removeGestureRecognizer(tap)
    }
    func bestAnswerClick(_ sender:UIButton) {
        
        view.endEditing(true)
        var tag : String!
        tag = (self.arrAnswers.value(forKey: "answerid") as! NSArray)[sender.tag] as? String //as! String
        
        if Reachability.isConnectedToNetwork() == true {
            self.showProgress()
            
            let body = String(format:"token=%@&answerid=%@", UserDefaults.standard.object(forKey: "token") as! String,tag!)
            
            let task = "setbestanswer"
            WebService().sendAPIRequest(UrlClass.baseUrl, body: body,task: task) { (result, error) -> Void in
                
                if result["status"] as! Int == 1
                {
                    DispatchQueue.main.async(execute: { () -> Void in
                        self.currentPage = 1
                        self.arrAnswers = NSMutableArray()
                        self.hideProgress()
                        self.loadData()
                    })
                    
                    
                } else if result["status"] as! Int == 0 || result["status"] as! Int == -1
                {
                    DispatchQueue.main.async(execute: { () -> Void in
                        self.hideProgress()
                        self.displayAlert("Alert Message", message: result["msg"] as! String)
                    })
                }
                
            }
        }else{
            //self.tableView.isHidden = true
            print("Nothing stored in NSUserDefaults yet. Set a value.")
        }
        
        
    }
    func scrollViewDidEndDragging(_ scrollView: UIScrollView, willDecelerate decelerate: Bool) {
        
        let currentOffset = scrollView.contentOffset.y
        
        let maximumOffset = scrollView.contentSize.height - scrollView.frame.size.height
        
        
        if (maximumOffset - currentOffset <= 10)
        {
            
            if (self.currentPage == totalPage)
            {
                
            } else {
                self.currentPage = self.currentPage + 1
                
                //print(self.currentPage)
                
                self.loadData()
            }
        }
    }
    
    func editTapped(){
        print("Editing")
        //AddorEditVC
        let addorEditViewController = storyboard?.instantiateViewController(withIdentifier: "AddorEditVC") as! AddorEditViewController
        addorEditViewController.TYPE = "Edit Your Answer"
        addorEditViewController.Field1 = selectedTitle
        addorEditViewController.Field2 = selectedDesc
        addorEditViewController.selectedId = selectedId
        
        self.navigationController?.pushViewController(addorEditViewController, animated: true)
        
    }
    
    func likePost(_ sender:UIButton) {
        
        view.endEditing(true)
        //var tag : String!
        
        var tag : String!
        var status : String!
        tag = (self.arrAnswers.value(forKey: "answerid") as! NSArray)[sender.tag] as? String //postanswerlike
        
        let value1 = (self.arrAnswers.value(forKey: "canlike") as! NSArray)[sender.tag] as? Int
        
        if(value1 == 1){
            status = "1"
        }else{
            status = "2"
        }
        
        if Reachability.isConnectedToNetwork() == true {
            self.showProgress()
            
            let body = String(format:"token=%@&answerid=%@&status=%@", UserDefaults.standard.object(forKey: "token") as! String,tag!,status!)
            
            let task = "postanswerlike"
            WebService().sendAPIRequest(UrlClass.baseUrl, body: body,task: task) { (result, error) -> Void in
                
                if result["status"] as! Int == 1
                {
                    DispatchQueue.main.async(execute: { () -> Void in
                        
                        self.currentPage = 1
                        self.arrAnswers = NSMutableArray()
                        
                        self.hideProgress()
                        self.loadData()
                    })
                    
                } else if result["status"] as! Int == 0 || result["status"] as! Int == -1
                {
                    DispatchQueue.main.async(execute: { () -> Void in
                        self.hideProgress()
                        self.displayAlert("Alert Message", message: result["msg"] as! String)
                    })
                }
                
            }
        }else{
            //self.tableView.isHidden = true
            print("Nothing stored in NSUserDefaults yet. Set a value.")
        }
    }
    
    func loadPrimData(){
        if Reachability.isConnectedToNetwork() == true {
            self.showProgress()
            
            let body = String(format:"token=%@&threadid=%@", UserDefaults.standard.object(forKey: "token") as! String,selectedId!)
            
            let task = "getthreaddetail"
            WebService().sendAPIRequest(UrlClass.baseUrl, body: body,task: task) { (result, error) -> Void in
                
                if result["status"] as! Int == 1
                {
                    
                    //let values = result ["thread"] as? NSArray//(self.tableDataArray.value(forKey: "answeredby") as! NSArray)[indexPath.row] as? String
                    self.selectedAnswerCount = (result ["thread"] as AnyObject).value(forKey: "noofanswers") as! String! //value ["noofanswers"] as? String
                    //self.selectedId = result ["threadid"] as? String
                    self.selectedTitle = (result ["thread"] as AnyObject).value(forKey: "title") as! String!// value ["title"] as? String
                    self.selectedDate = (result ["thread"] as AnyObject).value(forKey: "createddate") as! String!//value ["createddate"] as? String
                    self.selectedUser = (result ["thread"] as AnyObject).value(forKey: "createdby") as! String! // value [""]["createdby"] as? String
                    self.selectedDesc = (result ["thread"] as AnyObject).value(forKey: "description") as! String!//value ["description"] as? String
                    
                    DispatchQueue.main.async(execute: { () -> Void in
                        
                        if  (result ["thread"] as AnyObject).value(forKey: "canmodify") as! Int == 1
                        {
                            self.navigationItem.rightBarButtonItem = UIBarButtonItem(title: "Edit", style: .plain, target: self, action: #selector(self.editTapped))
                            
                        }
                        self.viewAnswers.isHidden = false
                        self.hideProgress()
                        self.loadData()
                        self.tableMain.reloadData()
                        if self.selectedAnswerCount != "0"{
                            }
                    })
                    
                } else if result["status"] as! Int == 0 || result["status"] as! Int == -1
                {
                    DispatchQueue.main.async(execute: { () -> Void in
                        self.hideProgress()
                        self.displayAlert("Alert Message", message: result["msg"] as! String)
                    })
                }
                
            }
        }else{
            self.viewAnswers.isHidden = true
            print("Nothing stored in NSUserDefaults yet. Set a value.")
        }
        
    }
    func getAnswerData()
    {
        if Reachability.isConnectedToNetwork() == true {
            self.showProgress()
            
            let body = String(format:"token=%@&threadid=%@&pagenumer=%@", UserDefaults.standard.object(forKey: "token") as! String,selectedId!,String(currentPage))
            
            let task = "listallthreadanswers"
            WebService().sendAPIRequest(UrlClass.baseUrl, body: body,task: task) { (result, error) -> Void in
                
                if result["status"] as! Int == 1
                {
                    self.totalPage = result ["totalpages"] as! NSInteger
                    
                    if(self.currentPage == 1)
                    {
                        self.arrAnswers = result["answerslist"] as! NSArray
                    }
                    else
                    {
                        let newPageArr = result["answerslist"] as! NSArray
                        
                        let newArr = self.arrAnswers.mutableCopy() as? NSMutableArray
                        
                        for i in (self.arrAnswers.count) ..< (self.arrAnswers.count)+newPageArr.count
                        {
                            newArr!.insert(newPageArr[i-(self.arrAnswers.count)], at: i)
                        }
                        self.arrAnswers = newArr!
                    }
                    
                    
                    DispatchQueue.main.async(execute: { () -> Void in
                         self.hideProgress()
                        self.tableMain.isHidden = false
                        self.viewAnswers.isHidden = false
                        self.tableMain.reloadData()
                    })
                    
                } else if result["status"] as! Int == 0 || result["status"] as! Int == -1
                {
                    DispatchQueue.main.async(execute: { () -> Void in
                        self.hideProgress()
                        self.tableMain.reloadData()
                        if((self.arrAnswers.count)>0){
                            self.displayAlert("Alert Message", message: result["msg"] as! String)}
                    })
                }
            }
        }else{
            self.viewAnswers.isHidden = true
            print("Nothing stored in NSUserDefaults yet. Set a value.")
        }
    }
    
    func tableView(_ tableView: UITableView, willDisplay cell: UITableViewCell, forRowAt indexPath: IndexPath)
    {
        DispatchQueue.main.async(execute: { () -> Void in
            var frame = self.tableMain.frame;
            frame.size.height = self.tableMain.contentSize.height + 50
            self.tableMain.frame = frame;
//           var frame1 =  self.scroll.contentSize as CGSize
//            frame1.height += self.tableMain.contentSize.height - 100 //- self.tableMain.frame.size.height)
//              self.scroll.contentSize = frame1
           self.scroll.contentSize = CGSize(width: self.view.frame.size.width, height: self.tableMain.contentSize.height + self.tableMain.frame.origin.y + 500)
        })
    }
    
    func numberOfSections(in tableView: UITableView) -> Int
    {
       return 1
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
            return 160
    }
    
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        return 20
    }
    
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        let view = UIView()
        view.backgroundColor = UIColor.clear
        return view
    }
    
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int
    {
        var tab = 0
        if self.arrAnswers.count > 0{
            tab = (arrAnswers.count)
        }
        return tab
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell
    {
        let cell = self.tableMain.dequeueReusableCell(withIdentifier: "answerForumCell", for: indexPath) as!
        ForumAnswerTableViewCell
        
        cell.selectionStyle = UITableViewCellSelectionStyle.none
        
        
        
        cell.contentView.layer.cornerRadius = 2.0
        cell.contentView.layer.borderWidth = 1.0
        cell.contentView.layer.borderColor = UIColor.lightGray.cgColor.copy(alpha: 0.3)
        cell.contentView.layer.masksToBounds = true
        
        cell.layer.shadowColor = UIColor.lightGray.cgColor
        cell.layer.shadowOffset = CGSize(width: 0, height: 2.0)
        cell.layer.shadowRadius = 2.0
        cell.layer.shadowOpacity = 1.0
        cell.layer.masksToBounds = false
        cell.layer.shadowPath = UIBezierPath(roundedRect: cell.bounds, cornerRadius: cell.contentView.layer.cornerRadius).cgPath
        
        
        do{
            (cell.contentView.viewWithTag(10) as! UILabel).text =  (self.arrAnswers.value(forKey: "answeredby") as! NSArray)[indexPath.row] as? String
        }catch{
            (cell.contentView.viewWithTag(10) as! UILabel).text =  ""
        }
        do{
            (cell.contentView.viewWithTag(20) as! UILabel).text = (self.arrAnswers.value(forKey: "createddate") as! NSArray)[indexPath.row] as? String
        }catch{
            (cell.contentView.viewWithTag(20) as! UILabel).text = ""
        }
        
        do{
            (cell.contentView.viewWithTag(30) as! UILabel).text = String(format:"(%@)",((self.arrAnswers.value(forKey: "nooflikes") as! NSArray)[indexPath.row] as? String)!)
        }catch{
            (cell.contentView.viewWithTag(30) as! UILabel).text = ""
        }
        do{
            (cell.contentView.viewWithTag(40) as! UILabel).text = (self.arrAnswers.value(forKey: "answer") as! NSArray)[indexPath.row] as? String
        }catch{
            (cell.contentView.viewWithTag(40) as! UILabel).text = ""
        }
        
        do{
            let likeValue = (self.arrAnswers.value(forKey: "canlike") as! NSArray)[indexPath.row] as? Int
            cell.likeBtn.isEnabled = true
            
            if (likeValue == 1){
                cell.likeBtn.isEnabled = true
                cell.likeImage?.image = UIImage(named:"facebook_like")
                
            }else if (likeValue == 2){
                cell.likeBtn.isEnabled = true
                cell.likeImage?.image = UIImage(named:"liked")
                
            }else{
                cell.likeBtn.isEnabled = false
                cell.likeImage?.image = UIImage(named:"unliked")
            }
            
        }catch{
            
        }
        
        cell.likeBtn.addTarget(self, action: #selector(FonumInnnerViewController.likePost(_:)), for: .touchUpInside)
        cell.likeBtn.tag = indexPath.row
        
        
        cell.likeBtnExt.addTarget(self, action: #selector(FonumInnnerViewController.likePost(_:)), for: .touchUpInside)
        cell.likeBtnExt.tag = indexPath.row
        
        
        do{
            //                if(self.isNotNSNull((self.tableDataArray.value(forKey: "profileimg") as! NSArray)[indexPath.row] as? String as AnyObject))
            //                {
            let imageURl = String(format: "%@%@", WebService.sharedInstance.getBaseURL, ((self.arrAnswers.value(forKey: "profileimg") as! NSArray)[indexPath.row] as? String)!)
            
            let url = URL(string: imageURl.trim())
            DispatchQueue.global(priority: DispatchQueue.GlobalQueuePriority.background).async {
                let data = try? Data(contentsOf: url!)
                DispatchQueue.main.async(execute: {
                    cell.userImage.image = UIImage(data: data!)
                });
            }
            // }
            
        }catch{
            
        }
        do{
            let value1 = (self.arrAnswers.value(forKey: "canmodify") as! NSArray)[indexPath.row] as? Int
            
            if(value1 == 1){
                cell.editBtn.isHidden = false
            }else
            {
                cell.editBtn.isHidden = true
            }
            
            cell.editBtn.addTarget(self, action: #selector(FonumInnnerViewController.editClick(_:)), for: .touchUpInside)
            cell.editBtn.tag = indexPath.row
            
        }catch{
            
        }
        
        do{
            let value2 = (self.arrAnswers.value(forKey: "canselectbestanswer") as! NSArray)[indexPath.row] as? Int
            let value11 = (self.arrAnswers.value(forKey: "isbestanswer") as! NSArray)[indexPath.row] as? String
            
            if(value2 == 0){
                cell.bestAnswerImage.image = UIImage(named:"liked")
                cell.bestAnswerBtn.isHidden = true
                cell.bestAnswerView.isHidden = true
            }else//1 button show
            {
                cell.bestAnswerImage.image = UIImage(named:"facebook_like")
                cell.bestAnswerBtn.isHidden = false
                cell.bestAnswerView.isHidden = false
            }
            
            if(value11 == "0"){
                
                //cell.BestAnswerLabel.text = "set as best answer"
                cell.BestAnswerLabel.textColor = UIColor(red: 14/255, green: 121/255, blue: 238/255, alpha: 1.0)//UIColor.darkGray
                let underlineAttribute = [NSUnderlineStyleAttributeName: NSUnderlineStyle.styleSingle.rawValue]
                let underlineAttributedString = NSAttributedString(string: "set as best answer", attributes: underlineAttribute)
                cell.BestAnswerLabel.attributedText = underlineAttributedString
            }else//show green text
            {
                cell.bestAnswerBtn.isHidden = true
                cell.bestAnswerView.isHidden = false
                cell.bestAnswerImage.image = UIImage(named:"checked")
                cell.BestAnswerLabel.text = "Best Answer"
                cell.BestAnswerLabel.textColor = UIColor.green
            }
            
            cell.bestAnswerBtn.addTarget(self, action: #selector(FonumInnnerViewController.bestAnswerClick(_:)), for: .touchUpInside)
            cell.bestAnswerBtn.tag = indexPath.row
            
        }catch{
            
        }
        
        
        return cell
    }
    
 
    
    
    
    @IBAction func postCmmentTapped(_ sender: Any) {
        view.endEditing(true)
        let comments = self.txtView.text
        print("Comment Text :",comments!)
        
        if((comments?.characters.count)!>0){
            
            if Reachability.isConnectedToNetwork() == true {
                self.showProgress()
                
                let body = String(format:"token=%@&threadid=%@&answer=%@", UserDefaults.standard.object(forKey: "token") as! String,selectedId!,comments!)
                
                let task = "postanswer"
                WebService().sendAPIRequest(UrlClass.baseUrl, body: body,task: task) { (result, error) -> Void in
                    
                    if result["status"] as! Int == 1
                    {
                        
                        DispatchQueue.main.async(execute: { () -> Void in
                            //                            self.tableView.isHidden = false
                            self.txtView.text = ""
                            self.loadPrimData()
                            self.hideProgress()
                            //                          self.tableView .reloadData()
                        })
                        
                    } else if result["status"] as! Int == 0 || result["status"] as! Int == -1
                    {
                        DispatchQueue.main.async(execute: { () -> Void in
                            self.hideProgress()
                            self.displayAlert("Alert Message", message: result["msg"] as! String)
                        })
                    }
                    
                }
            }else{
                // self.tableView.isHidden = true
                print("Nothing stored in NSUserDefaults yet. Set a value.")
            }
        }else{
            
        }
    }
    
    @IBAction func answerViewHolderClicked(_ sender: Any) {
        self.answerEditView.isHidden = true
    }
    @IBAction func updateAnswerEditClicked(_ sender: Any) {
        
        txtUpdateView.endEditing(true)
        txtUpdateView.resignFirstResponder()
        
        view.endEditing(true)
        if Reachability.isConnectedToNetwork() == true {
            self.showProgress()
            
            let body = String(format:"token=%@&answerid=%@&answer=%@", UserDefaults.standard.object(forKey: "token") as! String,self.selectedAnswerId!,(self.txtUpdateView.text)!)
            
            let task = "updateanswer"
            WebService().sendAPIRequest(UrlClass.baseUrl, body: body,task: task) { (result, error) -> Void in
                
                if result["status"] as! Int == 1
                {
                    DispatchQueue.main.async(execute: { () -> Void in
                        self.answerEditView.isHidden = true
                        self.hideProgress()
                        self.loadPrimData()
                    })
                    
                } else if result["status"] as! Int == 0 || result["status"] as! Int == -1
                {
                    DispatchQueue.main.async(execute: { () -> Void in
                        self.hideProgress()
                        self.displayAlert("Alert Message", message: result["msg"] as! String)
                    })
                }
                
            }
        }else{
            //self.tableView.isHidden = true
            print("Nothing stored in NSUserDefaults yet. Set a value.")
        }
        
    }
    
    @IBAction func cancelAnswerEditClicked(_ sender: Any) {
        self.answerEditView.isHidden = true
        txtUpdateView.endEditing(true)
        txtUpdateView.resignFirstResponder()
    }
    
    
    func CGRectMake(_ x: CGFloat, _ y: CGFloat, _ width: CGFloat, _ height: CGFloat) -> CGRect {
        return CGRect(x: x, y: y, width: width, height: height)
    }
    
    func editClick(_ sender:UIButton) {
        
        let frame = CGRectMake(scroll.contentOffset.x, scroll.contentOffset.y, scroll.contentOffset.x + scroll.bounds.size.width, scroll.contentOffset.y + scroll.bounds.size.height)
        answerEditView.frame = frame
        
        view.endEditing(true)
        var tag : String!
        tag = (self.arrAnswers.value(forKey: "answerid") as! NSArray)[sender.tag] as? String //as! String
        var tag1 : String!
        tag1 = (self.arrAnswers.value(forKey: "answer") as! NSArray)[sender.tag] as? String //as! String
        print(tag)
        
        let alertController = UIAlertController(title: "Alert Message", message: "Do you want to Edit Or Delete Post", preferredStyle: .alert)
        
        // Create the actions
        let okAction = UIAlertAction(title: "Edit", style: UIAlertActionStyle.default) {
            UIAlertAction in
            DispatchQueue.main.async(execute: { () -> Void in
                self.showEdit(tag,tag1)
                
               // self.editTapped()
               // self.answerEditView.isHidden = false
                //self.txtUpdateView.text = tag1
                self.selectedAnswerId = tag
            })
        }
        let deleteAction = UIAlertAction(title: "Delete", style: UIAlertActionStyle.destructive) {
            UIAlertAction in
            DispatchQueue.main.async(execute: { () -> Void in
                self.deletePost(tag)
                
            })
        }
        let cancelAction = UIAlertAction(title: "Cancel", style: UIAlertActionStyle.cancel) {
            UIAlertAction in
            DispatchQueue.main.async(execute: { () -> Void in
                
            })
        }
        
        alertController.addAction(okAction)
        alertController.addAction(deleteAction)
        alertController.addAction(cancelAction)
        
        // Present the controller
        self.present(alertController, animated: true, completion: nil)
    }
    
    
    func deletePost(_ sender:String){
        let alertController = UIAlertController(title: "Alert Message", message: "Do want to delete post", preferredStyle: .alert)
        
        // Create the actions
        let okAction = UIAlertAction(title: "Yes", style: UIAlertActionStyle.destructive) {
            UIAlertAction in
            DispatchQueue.main.async(execute: { () -> Void in
                //
                if Reachability.isConnectedToNetwork() == true {
                    self.showProgress()
                    
                    let body = String(format:"token=%@&answerid=%@", UserDefaults.standard.object(forKey: "token") as! String,sender)
                    
                    let task = "removeanswer"
                    WebService().sendAPIRequest(UrlClass.baseUrl, body: body,task: task) { (result, error) -> Void in
                        
                        if result["status"] as! Int == 1
                        {
                            DispatchQueue.main.async(execute: { () -> Void in
                                
                                self.hideProgress()
                                self.loadPrimData()
                            })
                            
                        } else if result["status"] as! Int == 0 || result["status"] as! Int == -1
                        {
                            DispatchQueue.main.async(execute: { () -> Void in
                                self.hideProgress()
                                self.displayAlert("Alert Message", message: result["msg"] as! String)
                            })
                        }
                        
                    }
                }else{
                    //self.tableView.isHidden = true
                    print("Nothing stored in NSUserDefaults yet. Set a value.")
                }
            })
        }
        let deleteAction = UIAlertAction(title: "No", style: UIAlertActionStyle.cancel) {
            UIAlertAction in
            DispatchQueue.main.async(execute: { () -> Void in
                
            })
        }
        
        alertController.addAction(okAction)
        alertController.addAction(deleteAction)
        
        
        // Present the controller
        self.present(alertController, animated: true, completion: nil)
        
    }
    
    
    func showEdit(_ sender:String ,_ sender1:String){
        
        let alert = UIAlertController(title: "Edit Answer", message: "", preferredStyle: .alert)
        
        alert.addTextField { (textField) in
            textField.text = sender1
        }
        
        alert.addAction(UIAlertAction(title: "OK", style: .default, handler: { [weak alert] (_) in
            let textField = alert?.textFields![0] // Force unwrapping because we know it exists.
            print("Text field: \(textField?.text)")
            if Reachability.isConnectedToNetwork() == true {
                self.showProgress()
                
                let body = String(format:"token=%@&answerid=%@&answer=%@", UserDefaults.standard.object(forKey: "token") as! String,sender,(textField?.text)!)
                
                let task = "updateanswer"
                WebService().sendAPIRequest(UrlClass.baseUrl, body: body,task: task) { (result, error) -> Void in
                    
                    if result["status"] as! Int == 1
                    {
                        DispatchQueue.main.async(execute: { () -> Void in
                            
                            self.hideProgress()
                            self.loadPrimData()
                        })
                        
                    } else if result["status"] as! Int == 0 || result["status"] as! Int == -1
                    {
                        DispatchQueue.main.async(execute: { () -> Void in
                            self.hideProgress()
                            self.displayAlert("Alert Message", message: result["msg"] as! String)
                        })
                    }
                    
                }
            }else{
                //self.tableView.isHidden = true
                print("Nothing stored in NSUserDefaults yet. Set a value.")
            }
            
        }))
        
        alert.addAction(UIAlertAction(title: "Cancel", style: .cancel, handler: { [weak alert] (_) in
            
        }))
        // 4. Present the alert.
        self.present(alert, animated: true, completion: nil)
    }

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
