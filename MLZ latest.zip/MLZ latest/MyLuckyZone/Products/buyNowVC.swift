//
//  buyNowVC.swift
//  MyLuckyZone
//
//  Created by G.Abhisek on 01/06/16.
//  Copyright © 2016 Adodis. All rights reserved.
//

import UIKit
fileprivate func < <T : Comparable>(lhs: T?, rhs: T?) -> Bool {
  switch (lhs, rhs) {
  case let (l?, r?):
    return l < r
  case (nil, _?):
    return true
  default:
    return false
  }
}

fileprivate func > <T : Comparable>(lhs: T?, rhs: T?) -> Bool {
  switch (lhs, rhs) {
  case let (l?, r?):
    return l > r
  default:
    return rhs < lhs
  }
}


class buyNowVC: UIViewController,UITextFieldDelegate {

    @IBOutlet weak var theScrollView: UIScrollView!
    
    var productID = NSString()
    
    var tagID = NSString()

    @IBOutlet weak var requiredQuantityTxtFld: UITextField!
    @IBOutlet weak var firstNameTxtFld: UITextField!
    @IBOutlet weak var lastNameTxtFld: UITextField!
    @IBOutlet weak var mobileNumberTxtFld: UITextField!
    @IBOutlet weak var addressTxtFld: UITextField!
    @IBOutlet weak var cityTxtFld: UITextField!
    @IBOutlet weak var countryTxtFld: UITextField!
    @IBOutlet weak var postalcodeTxtFld: UITextField!
    
    var allowedQty : Int?
    
    
    var activeTextField = UITextField()
    
    override func viewDidLoad()
    {
        super.viewDidLoad()

        NotificationCenter.default.addObserver(self, selector: #selector(buyNowVC.keyboardWasShown(_:)), name: NSNotification.Name.UIKeyboardWillShow, object: nil)
        
        NotificationCenter.default.addObserver(self, selector: #selector(buyNowVC.keyboardWillBeHidden(_:)), name: NSNotification.Name.UIKeyboardWillHide, object: nil)
        
        
        // Do any additional setup after loading the view.
    }
    
    
    override func viewWillDisappear(_ animated: Bool)
    {
        NotificationCenter.default.removeObserver(self, name: NSNotification.Name.UIKeyboardDidHide, object: nil)
        NotificationCenter.default.removeObserver(self, name: NSNotification.Name.UIKeyboardWillHide, object: nil)
    }
    

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func keyboardWasShown(_ notification: Notification) {
        
        // Step 1: Get the size of the keyboard.
        let info : NSDictionary = (notification as NSNotification).userInfo! as NSDictionary
//        let keyboardSize = ((info.object(forKey: UIKeyboardFrameBeginUserInfoKey) as AnyObject).cgRectValue as CGRect!).size
        let keyboardSize = (info[UIKeyboardFrameBeginUserInfoKey] as? NSValue)!.cgRectValue
        // Step 2: Adjust the bottom content inset of your scroll view by the keyboard height.
        let contentInsets: UIEdgeInsets = UIEdgeInsetsMake(0.0, 0.0, keyboardSize.height, 0.0)
        self.theScrollView.contentInset = contentInsets
        self.theScrollView.scrollIndicatorInsets = contentInsets
        // Step 3: Scroll the target text field into view.
        var aRect: CGRect = self.view.frame
        aRect.size.height -= keyboardSize.height
        if !aRect.contains(activeTextField.frame.origin)
        {
            let scrollPoint: CGPoint = CGPoint(x: 0.0, y: activeTextField.frame.origin.y)
            self.theScrollView.setContentOffset(scrollPoint, animated: true)
        }
    }
    
    func keyboardWillBeHidden(_ notification: Notification)
    {
        let contentInsets: UIEdgeInsets = UIEdgeInsets.zero
        self.theScrollView.contentInset = contentInsets
        self.theScrollView.scrollIndicatorInsets = contentInsets
    }
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool
    {
        return textField.resignFirstResponder()
    }
    
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(true)
        
        self.getmyprofile()
    }
    
    
    
    func getmyprofile()
    {
        WebService.sharedInstance.getProfile({ (result, error) -> Void in
            if result["status"] as! Int == 1
            {
                DispatchQueue.main.async(execute: { () -> Void in
                    
                    self.firstNameTxtFld.text = (result["profile"] as? NSDictionary)!.value(forKey: "firstname") as? String
                    self.lastNameTxtFld.text = (result["profile"] as? NSDictionary)!.value(forKey: "lastname") as? String
                    self.mobileNumberTxtFld.text = (result["profile"] as? NSDictionary)!.value(forKey: "mobile") as? String

                    self.addressTxtFld.text = (result["profile"] as? NSDictionary)!.value(forKey: "address") as? String
                    self.cityTxtFld.text = (result["profile"] as? NSDictionary)!.value(forKey: "city") as? String
                    //self.countryTxtFld.text = "USA"
                    self.postalcodeTxtFld.text = (result["profile"] as? NSDictionary)!.value(forKey: "zipcode") as? String
                    self.countryTxtFld.text = (result["profile"] as? NSDictionary)!.value(forKey: "country") as? String
                })
            }
        })
    }


    
    @IBAction func submit(_ sender: AnyObject)
    {
        if (self.requiredQuantityTxtFld.text == "" || self.firstNameTxtFld.text == "" || self.lastNameTxtFld.text == "" || self.mobileNumberTxtFld.text == "" || self.addressTxtFld.text == "" || self.cityTxtFld.text == "" || self.postalcodeTxtFld.text == "" || self.postalcodeTxtFld.text == "")
        {
        self.displayAlert("Alert Message", message: "Please Enter all fields")

        }else{
            
            if let requiredQuantity = Int(self.requiredQuantityTxtFld.text!) {
                if allowedQty != nil {
                    if requiredQuantity < 1 || requiredQuantity > self.allowedQty {
                        if self.allowedQty == 1 {
                            self.displayAlert("Alert Message", message: "Please enter at least 1 for Required Quantity.")
                        } else {
                            self.displayAlert("Alert Message", message: "Please enter value between 1 and \(self.allowedQty!) for Required Quantity.")
                        }
                        return
                    }
                }
            }
            
            let body = String(format:"token=%@&shippingaddress=%@&productid=%@&qty=%@", UserDefaults.standard.object(forKey: "token") as! String,self.addressTxtFld.text!,self.productID,self.requiredQuantityTxtFld.text!)
            
            var task = ""
            if(tagID == "1")
            {
             task = "buysalesproducts"
            }else{
             task = "buyrefsalesproducts"
            }
            WebService().sendAPIRequest(UrlClass.baseUrl, body: body,task: task) { (result, error) -> Void in
                
                if result["status"] as! Int == 1
                {
                    DispatchQueue.main.async(execute: { () -> Void in
                    self.displayAlert("Alert Message", message: result["msg"] as! String)
                    })
                } else if result["status"] as! Int == 0
                {
                    DispatchQueue.main.async(execute: { () -> Void in
                        
                        self.displayAlert("Alert Message", message: result["msg"] as! String)
                        
                    })
                }
            }

            
        }
        
   
    }
    
//    
//    func displayAlert(title: String, message: String)
//    {
//        let alertController = UIAlertController(title: title, message: message, preferredStyle: .Alert)
//        alertController.addAction(UIAlertAction(title: "OK", style: .Default, handler: nil))
//        presentViewController(alertController, animated: true, completion: nil)
//    }


    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
