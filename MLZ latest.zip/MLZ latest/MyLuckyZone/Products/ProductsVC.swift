//
//  ProductsVC.swift
//  MyLuckyZone
//
//  Created by Kavya Mishra on 5/18/16.
//  Copyright © 2016 Adodis. All rights reserved.
//

import UIKit
import SDWebImage


class ProductsVC: UIViewController,UITableViewDelegate,UITableViewDataSource
{
    @IBOutlet var ATableView: UITableView!
    
    var hearderarry:[String]! = []
    var storedOffsets = [Int: CGFloat]()
    
    var model = [[String]]()
    var model1 = [[String]]()
     var model2 = [[String]]()
    
    var theProductCategory = NSString()
    
    var Sweep_Takes:[String]! = []
    var Auction:[String]! = []
    var Sales:[String]! = []
    var Platinum:[String]! = []
    var Gold:[String]! = []
    var Silver:[String]! = []
    var Premium_Sweep_Stakes:[String]! = []
    var Risky:[String]! = []
    var Sweep_Takes1:[String]! = []
    var Auction1:[String]! = []
    var Sales1:[String]! = []
    var Platinum1:[String]! = []
    var Gold1:[String]! = []
    var Silver1:[String]! = []
    var Premium_Sweep_Stakes1:[String]! = []
    var Risky1:[String]! = []
    var Sweep_Takes2:[String]! = []
    var Auction2:[String]! = []
    var Sales2:[String]! = []
    var Platinum2:[String]! = []
    var Gold2:[String]! = []
    var Silver2:[String]! = []
    var Premium_Sweep_Stakes2:[String]! = []
    var Risky2:[String]! = []
    
    

    override func viewDidLoad() {
        
        print(UserDefaults.standard.object(forKey: "token") as! String)
        sweepStakeDataList()
        productForAuction()
        productForSales()
        platinumSales()
        goldSales()
        silverSales()
        premiumSweepStakes()
        productForRiskyAuction()
//
//        let dispatchGroup = DispatchGroup()
//
//        dispatchGroup.enter()
//        sweepStakeDataList() { dispatchGroup.leave() }
//
//        dispatchGroup.enter()
//         productForAuction() { dispatchGroup.leave() }
//
//        dispatchGroup.notify(queue: .main) {
//            print("Both functions complete 👍")
//        }
        
        
        
        

        
        super.viewDidLoad()
        
        
        // Do any additional setup after loading the view.
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
   
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return model.count
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 250
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "celltable", for: indexPath ) as! TableViewCellclass
        
        
        switch hearderarry[indexPath.row] {
        case "Sweep Takes":
            cell.headerlable.textColor = .red
        case "Auction":
            cell.headerlable.textColor = .yellow
        case "Sales":
            cell.headerlable.textColor = .blue
        case "Platinum":
            cell.headerlable.textColor = .purple
        case "Gold":
            cell.headerlable.textColor = .green
        case "Silver":
            cell.headerlable.textColor = .red
        case "Premium Sweep Stakes":
            cell.headerlable.textColor = .black
        case "Risky":
            cell.headerlable.textColor = .yellow
        default:
            break
        }
        
        cell.headerlable.text = hearderarry[indexPath.row]
        cell.collectionoutlet.reloadData()
        
        //
        return cell
    }
    
    
    func tableView(_ tableView: UITableView, willDisplay cell: UITableViewCell, forRowAt indexPath: IndexPath) {
        
        guard let tableViewCell = cell as? TableViewCellclass else { return }
        
        tableViewCell.setCollectionViewDataSourceDelegate(self, forRow: indexPath.row)
        tableViewCell.collectionViewOffset = storedOffsets[indexPath.row] ?? 0
        tableViewCell.collectionoutlet.reloadData()
    }
    
    func tableView(_ tableView: UITableView, didEndDisplaying cell: UITableViewCell, forRowAt indexPath: IndexPath) {
        
        guard let tableViewCell = cell as? TableViewCellclass else { return }
        
        storedOffsets[indexPath.row] = tableViewCell.collectionViewOffset
    }
    
    
    
    
}

extension ProductsVC:UICollectionViewDelegate,UICollectionViewDataSource {
    
    func numberOfSections(in collectionView: UICollectionView) -> Int {
        return 1
    }
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return model[collectionView.tag].count
    }

//    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize
//    {
//        return CGSize(width: 1000.0, height: 1000.0)
//    }
    
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "cellcollection", for: indexPath) as! CollectionViewCellclass
        //            cell.backgroundColor = UIColor.blue
        
        cell.lable.text = "\(model[collectionView.tag][indexPath.item]) Points"
        cell.starcard.text = model1[collectionView.tag][indexPath.item]
        let baseurl = "http://dev.myluckyzone.com\(model2[collectionView.tag][indexPath.item])"  // /uploads/productimages/22_cover.jpg";
        print(baseurl)
        cell.image.sd_setImage(with: URL(string:baseurl)
            , placeholderImage: nil
            , options: SDWebImageOptions.retryFailed
            , progress: {(receivedSize: Int, expectedSize: Int) in
        }
            , completed:{(image: UIImage?, error: Error?, cacheType: SDImageCacheType, imageURL: URL?) in
                if (image != nil) {
                    cell.image.image = image
                }
        })
        
        
        
        return cell
    }
    
    func sweepStakeDataList()
    {
//        self.showProgress()
        
       
        let body = String(format: "pagenumer=%@&searchkey=%@&token=%@","1",self.theProductCategory,UserDefaults.standard.object(forKey: "token") as! String)
        
        
        
        let task = "listallsweepstakeproducts"
        WebService().sendAPIRequest(UrlClass.baseUrl, body: body,task: task) { (result, error) -> Void in
            if(result.count>0){
                if result["status"] as! Int == 1
                {
                    print(result["sweepstakeproductlist"] as! NSArray)

                    
                    DispatchQueue.main.async(execute: { () -> Void in
//                        self.hideProgress()
                        self.hearderarry.append("Sweep Takes")
                        let sweepstakeproduct = result["sweepstakeproductlist"] as! NSArray
                        for (i,_) in sweepstakeproduct.enumerated() {
                            let sweepstakeproduct2 = sweepstakeproduct[i] as! NSDictionary
                            print("\(sweepstakeproduct2["requiredpoints"]!)")
                            self.Sweep_Takes.append(sweepstakeproduct2["requiredpoints"] as! String)
                            self.Sweep_Takes1.append(sweepstakeproduct2["title"] as! String)
                             self.Sweep_Takes2.append(sweepstakeproduct2["imagepath"] as! String)
                            
                            
                        }
//                        self.displayAlert("Alert Message", message: result["msg"] as! String)
                        self.model.append(self.Sweep_Takes)
                        self.model1.append(self.Sweep_Takes1)
                        self.model2.append(self.Sweep_Takes2)

                        self.ATableView.reloadData()
                    
                        print (self.Sweep_Takes)
                        
                    })
                    
                    
                    
                    
                    
                    
                }
                else if(result["status"] as! Int == 0 || result["status"] as! Int == -1)
                {
//                    DispatchQueue.main.async(execute: { () -> Void in
//                        self.hideProgress()
//                        self.displayAlert("Alert Message", message: result["msg"] as! String)
////                        self.productTableView.reloadData()
//                    })
                }else{
                     print("no messg")
//                    DispatchQueue.main.async(execute: { () -> Void in
//                        self.hideProgress()
//                        if(result.count>0){
//                            self.displayAlert("Alert Message", message: result["msg"] as! String)}
//                        else{
//                            self.displayAlert("Alert Message", message: "Try again")
//                        }
//                    })
                }
            } else{
                print("no net")
                //self.displayAlert("Alert Message", message: "Please Check Internet connection")
                DispatchQueue.main.async(execute: { () -> Void in
//                    self.hideProgress()
                })
            }
        }
    }
    
    func productForAuction()
    {
//        self.showProgress()
       
        let body = String(format: "pagenumer=%@&searchkey=%@&token=%@","1",self.theProductCategory,UserDefaults.standard.object(forKey: "token") as! String)
        
        
        
        let task = "listallauctionproducts"
        WebService().sendAPIRequest(UrlClass.baseUrl, body: body,task: task) { (result, error) -> Void in
            if(result.count>0){
                if result["status"] as! Int == 1
                {
                    print(result["auctionproductlist"] as! NSArray)
                    
                    
                    DispatchQueue.main.async(execute: { () -> Void in
                        self.hideProgress()
                        self.hearderarry.append("Auction")
                        let sweepstakeproduct = result["auctionproductlist"] as! NSArray
                        for (i,_) in sweepstakeproduct.enumerated() {
                            let sweepstakeproduct2 = sweepstakeproduct[i] as! NSDictionary
                            print("\(sweepstakeproduct2["requiredpoints"]!)")
                            self.Auction.append(sweepstakeproduct2["requiredpoints"] as! String)
                             self.Auction1.append(sweepstakeproduct2["title"] as! String)
                            self.Auction2.append(sweepstakeproduct2["imagepath"] as! String)
                            
                            
                        }
                        //                        self.displayAlert("Alert Message", message: result["msg"] as! String)
                        self.model.append(self.Auction)
                        self.model1.append(self.Auction1)
                        self.model2.append(self.Auction2)

                        self.ATableView.reloadData()

                        print (self.Auction)
                        
                    })
                    
                    
                    
                    
                    
                    
                }
                else if(result["status"] as! Int == 0 || result["status"] as! Int == -1)
                {
                    //                    DispatchQueue.main.async(execute: { () -> Void in
//                    self.hideProgress()
                    //                        self.displayAlert("Alert Message", message: result["msg"] as! String)
                    ////                        self.productTableView.reloadData()
                    //                    })
                }else{
                    print("no messg")
                    //                    DispatchQueue.main.async(execute: { () -> Void in
                    //                        self.hideProgress()
                    //                        if(result.count>0){
                    //                            self.displayAlert("Alert Message", message: result["msg"] as! String)}
                    //                        else{
                    //                            self.displayAlert("Alert Message", message: "Try again")
                    //                        }
                    //                    })
                }
            } else{
                print("no net")
                //self.displayAlert("Alert Message", message: "Please Check Internet connection")
                DispatchQueue.main.async(execute: { () -> Void in
//                    self.hideProgress()
                })
            }
        }
    }
    func productForSales()
    {
//        self.showProgress()

       
        let body = String(format: "pagenumer=%@&searchkey=%@&token=%@","1",self.theProductCategory,UserDefaults.standard.object(forKey: "token") as! String)



        let task = "listallsalesproducts"
        WebService().sendAPIRequest(UrlClass.baseUrl, body: body,task: task) { (result, error) -> Void in
            if(result.count>0){
                if result["status"] as! Int == 1
                {
                    print(result["salesproductlist"] as! NSArray)


                    DispatchQueue.main.async(execute: { () -> Void in
                        self.hideProgress()

                        let sweepstakeproduct = result["salesproductlist"] as! NSArray
                        self.hearderarry.append("Sales")
                        for (i,_) in sweepstakeproduct.enumerated() {
                            let sweepstakeproduct2 = sweepstakeproduct[i] as! NSDictionary
                            print("\(sweepstakeproduct2["requiredpoints"]!)")
                            self.Sales.append(sweepstakeproduct2["requiredpoints"] as! String)
                            self.Sales1.append(sweepstakeproduct2["title"] as! String)
                            self.Sales2.append(sweepstakeproduct2["imagepath"] as! String)
                            
                            
                        }
                        
                       

                        //                        self.displayAlert("Alert Message", message: result["msg"] as! String)
                        self.model.append(self.Sales)
                        self.model1.append(self.Sales1)
                        self.model2.append(self.Sales2)

                        self.ATableView.reloadData()

                        print (self.Sales)

                    })






                }
                else if(result["status"] as! Int == 0 || result["status"] as! Int == -1)
                {
                    //                    DispatchQueue.main.async(execute: { () -> Void in
//                    self.hideProgress()
                    //                        self.displayAlert("Alert Message", message: result["msg"] as! String)
                    ////                        self.productTableView.reloadData()
                    //                    })
                }else{
                    print("no messg")
                    //                    DispatchQueue.main.async(execute: { () -> Void in
                    //                        self.hideProgress()
                    //                        if(result.count>0){
                    //                            self.displayAlert("Alert Message", message: result["msg"] as! String)}
                    //                        else{
                    //                            self.displayAlert("Alert Message", message: "Try again")
                    //                        }
                    //                    })
                }
            } else{
                print("no net")
                //self.displayAlert("Alert Message", message: "Please Check Internet connection")
                DispatchQueue.main.async(execute: { () -> Void in
//                    self.hideProgress()
                })
            }
        }
    }
    func platinumSales()
    {
//        self.showProgress()

       
        let body = String(format:"token=%@&pagenumer=%@&salestype=1&searchkey=%@", UserDefaults.standard.object(forKey: "token") as! String,"1",self.theProductCategory)



        let task = "listallrefsalesproducts"
        WebService().sendAPIRequest(UrlClass.baseUrl, body: body,task: task) { (result, error) -> Void in
            if(result.count>0){
                if result["status"] as! Int == 1
                {
                    print(result["refsalesproductlist"] as! NSArray)


                    DispatchQueue.main.async(execute: { () -> Void in
//                        self.hideProgress()

                        self.hearderarry.append("Platinum")
                        let sweepstakeproduct = result["refsalesproductlist"] as! NSArray
                        for (i,_) in sweepstakeproduct.enumerated() {
                            let sweepstakeproduct2 = sweepstakeproduct[i] as! NSDictionary
                            print("\(sweepstakeproduct2["requiredpoints"]!)")
                            self.Platinum.append(sweepstakeproduct2["requiredpoints"] as! String)
                            self.Platinum1.append(sweepstakeproduct2["title"] as! String)
                             self.Platinum2.append(sweepstakeproduct2["imagepath"] as! String)
                            
                            
                        }
                        //                        self.displayAlert("Alert Message", message: result["msg"] as! String)
                        self.model.append(self.Platinum)
                        self.model1.append(self.Platinum1)
                        self.model2.append(self.Platinum2)

                        self.ATableView.reloadData()

                        print (self.Platinum)

                    })






                }
                else if(result["status"] as! Int == 0 || result["status"] as! Int == -1)
                {
                    //                    DispatchQueue.main.async(execute: { () -> Void in
//                    self.hideProgress()
                    //                        self.displayAlert("Alert Message", message: result["msg"] as! String)
                    ////                        self.productTableView.reloadData()
                    //                    })
                }else{
                    print("no messg")
                    //                    DispatchQueue.main.async(execute: { () -> Void in
                    //                        self.hideProgress()
                    //                        if(result.count>0){
                    //                            self.displayAlert("Alert Message", message: result["msg"] as! String)}
                    //                        else{
                    //                            self.displayAlert("Alert Message", message: "Try again")
                    //                        }
                    //                    })
                }
            } else{
                print("no net")
                //self.displayAlert("Alert Message", message: "Please Check Internet connection")
                DispatchQueue.main.async(execute: { () -> Void in
//                    self.hideProgress()
                })
            }
        }
    }
    func goldSales()
    {
//        self.showProgress()

       
        let body = String(format:"token=%@&pagenumer=%@&salestype=2&searchkey=%@", UserDefaults.standard.object(forKey: "token") as! String,"1",self.theProductCategory)
        



        let task = "listallsweepstakeproducts"
        WebService().sendAPIRequest(UrlClass.baseUrl, body: body,task: task) { (result, error) -> Void in
            if(result.count>0){
                if result["status"] as! Int == 1
                {
                    print(result["sweepstakeproductlist"] as! NSArray)


                    DispatchQueue.main.async(execute: { () -> Void in
//                        self.hideProgress()

                        self.hearderarry.append("Gold")
                        let sweepstakeproduct = result["sweepstakeproductlist"] as! NSArray
                        for (i,_) in sweepstakeproduct.enumerated() {
                            let sweepstakeproduct2 = sweepstakeproduct[i] as! NSDictionary
                            print("\(sweepstakeproduct2["requiredpoints"]!)")
                            self.Gold.append(sweepstakeproduct2["requiredpoints"] as! String)
                            self.Gold1.append(sweepstakeproduct2["title"] as! String)
                            self.Gold2.append(sweepstakeproduct2["imagepath"] as! String)
                            
                            
                        }

                        //                        self.displayAlert("Alert Message", message: result["msg"] as! String)
                        self.model.append(self.Gold)
                        self.model1.append(self.Gold1)
                        self.model2.append(self.Gold2)

                        self.ATableView.reloadData()

                        print (self.Gold)

                    })






                }
                else if(result["status"] as! Int == 0 || result["status"] as! Int == -1)
                {
                    //                    DispatchQueue.main.async(execute: { () -> Void in
//                    self.hideProgress()
                    //                        self.displayAlert("Alert Message", message: result["msg"] as! String)
                    ////                        self.productTableView.reloadData()
                    //                    })
                }else{
                    print("no messg")
                    //                    DispatchQueue.main.async(execute: { () -> Void in
                    //                        self.hideProgress()
                    //                        if(result.count>0){
                    //                            self.displayAlert("Alert Message", message: result["msg"] as! String)}
                    //                        else{
                    //                            self.displayAlert("Alert Message", message: "Try again")
                    //                        }
                    //                    })
                }
            } else{
                print("no net")
                //self.displayAlert("Alert Message", message: "Please Check Internet connection")
                DispatchQueue.main.async(execute: { () -> Void in
//                    self.hideProgress()
                })
            }
        }
    }
    func silverSales()
    {
//        self.showProgress()

       
        let body = String(format:"token=%@&pagenumer=%@&salestype=3&searchkey=%@", UserDefaults.standard.object(forKey: "token") as! String,"1",self.theProductCategory)
        



        let task = "listallsweepstakeproducts"
        WebService().sendAPIRequest(UrlClass.baseUrl, body: body,task: task) { (result, error) -> Void in
            if(result.count>0){
                if result["status"] as! Int == 1
                {
                    print(result["sweepstakeproductlist"] as! NSArray)


                    DispatchQueue.main.async(execute: { () -> Void in
//                        self.hideProgress()

                        self.hearderarry.append("Silver")
                        let sweepstakeproduct = result["sweepstakeproductlist"] as! NSArray
                        for (i,_) in sweepstakeproduct.enumerated() {
                            let sweepstakeproduct2 = sweepstakeproduct[i] as! NSDictionary
                            print("\(sweepstakeproduct2["requiredpoints"]!)")
                            self.Silver.append(sweepstakeproduct2["requiredpoints"] as! String)
                            self.Silver1.append(sweepstakeproduct2["title"] as! String)
                            self.Silver2.append(sweepstakeproduct2["imagepath"] as! String)
                            
                            
                        }
                        //                        self.displayAlert("Alert Message", message: result["msg"] as! String)
                        self.model.append(self.Silver)
                        self.model1.append(self.Silver1)
                        self.model2.append(self.Silver2)

                        self.ATableView.reloadData()

                        print (self.Silver)

                    })






                }
                else if(result["status"] as! Int == 0 || result["status"] as! Int == -1)
                {
                    //                    DispatchQueue.main.async(execute: { () -> Void in
//                    self.hideProgress()
                    //                        self.displayAlert("Alert Message", message: result["msg"] as! String)
                    ////                        self.productTableView.reloadData()
                    //                    })
                }else{
                    print("no messg")
                    //                    DispatchQueue.main.async(execute: { () -> Void in
                    //                        self.hideProgress()
                    //                        if(result.count>0){
                    //                            self.displayAlert("Alert Message", message: result["msg"] as! String)}
                    //                        else{
                    //                            self.displayAlert("Alert Message", message: "Try again")
                    //                        }
                    //                    })
                }
            } else{
                print("no net")
                //self.displayAlert("Alert Message", message: "Please Check Internet connection")
                DispatchQueue.main.async(execute: { () -> Void in
//                    self.hideProgress()
                })
            }
        }
    }
    func premiumSweepStakes()
    {
//        self.showProgress()

        
       
        WebService.sharedInstance.getPremiumSweepStakesList(1, productCategory: self.theProductCategory, callback: {(result, error) -> Void in
            if(result.count>0){
                if result["status"] as! Int == 1
                {
                    print(result["sweepstakeproductlist"] as! NSArray)


                    DispatchQueue.main.async(execute: { () -> Void in
//                        self.hideProgress()

                        self.hearderarry.append("Premium Sweep Stakes")
                        let sweepstakeproduct = result["sweepstakeproductlist"] as! NSArray
                        for (i,_) in sweepstakeproduct.enumerated() {
                            let sweepstakeproduct2 = sweepstakeproduct[i] as! NSDictionary
                            print("\(sweepstakeproduct2["requiredpoints"]!)")
                            self.Premium_Sweep_Stakes.append(sweepstakeproduct2["requiredpoints"] as! String)
                            self.Premium_Sweep_Stakes1.append(sweepstakeproduct2["title"] as! String)
                            self.Premium_Sweep_Stakes2.append(sweepstakeproduct2["imagepath"] as! String)
                            
                            
                        }

                        //                        self.displayAlert("Alert Message", message: result["msg"] as! String)
                        self.model.append(self.Premium_Sweep_Stakes)
                        self.model1.append(self.Premium_Sweep_Stakes1)
                        self.model2.append(self.Premium_Sweep_Stakes2)

                        self.ATableView.reloadData()

                        print (self.Premium_Sweep_Stakes)

                    })






                }
                else if(result["status"] as! Int == 0 || result["status"] as! Int == -1)
                {
                    //                    DispatchQueue.main.async(execute: { () -> Void in
//                    self.hideProgress()
                    //                        self.displayAlert("Alert Message", message: result["msg"] as! String)
                    ////                        self.productTableView.reloadData()
                    //                    })
                }else{
                    print("no messg")
                    //                    DispatchQueue.main.async(execute: { () -> Void in
                    //                        self.hideProgress()
                    //                        if(result.count>0){
                    //                            self.displayAlert("Alert Message", message: result["msg"] as! String)}
                    //                        else{
                    //                            self.displayAlert("Alert Message", message: "Try again")
                    //                        }
                    //                    })
                }
            } else{
                print("no net")
                //self.displayAlert("Alert Message", message: "Please Check Internet connection")
                DispatchQueue.main.async(execute: { () -> Void in
//                    self.hideProgress()
                })
            }
        })
    }
    
    
    
    func productForRiskyAuction()
    {
//        self.showProgress()
       
        let body = String(format: "pagenumer=%@&searchkey=%@&token=%@","1",self.theProductCategory,UserDefaults.standard.object(forKey: "token") as! String)
        
        let task = "listallriskyauctionproducts"
        WebService().sendAPIRequest(UrlClass.baseUrl, body: body,task: task) { (result, error) -> Void in
            if(result.count>0){
                if result["status"] as! Int == 1
                {
                    print(result["auctionproductlist"] as! NSArray)
                    
                    
                    DispatchQueue.main.async(execute: { () -> Void in
//                        self.hideProgress()
                        self.hearderarry.append("Risky")
                        let sweepstakeproduct = result["auctionproductlist"] as! NSArray
                        for (i,_) in sweepstakeproduct.enumerated() {
                            let sweepstakeproduct2 = sweepstakeproduct[i] as! NSDictionary
                            print("\(sweepstakeproduct2["requiredpoints"]!)")
                            self.Risky.append(sweepstakeproduct2["requiredpoints"] as! String)
                            self.Risky1.append(sweepstakeproduct2["title"] as! String)
                            self.Risky2.append(sweepstakeproduct2["imagepath"] as! String)
                            
                            
                        }
                        //                        self.displayAlert("Alert Message", message: result["msg"] as! String)
                        self.model.append(self.Risky)
                         self.model1.append(self.Risky1)
                        self.model2.append(self.Risky2)
                        
                        self.ATableView.reloadData()
                        
                        print (self.Risky)
                        
                    })
                    
                    
                    
                    
                    
                    
                }
                else if(result["status"] as! Int == 0 || result["status"] as! Int == -1)
                {
                    //                    DispatchQueue.main.async(execute: { () -> Void in
//                    self.hideProgress()
                    //                        self.displayAlert("Alert Message", message: result["msg"] as! String)
                    ////                        self.productTableView.reloadData()
                    //                    })
                }else{
                    print("no messg")
                    //                    DispatchQueue.main.async(execute: { () -> Void in
                    //                        self.hideProgress()
                    //                        if(result.count>0){
                    //                            self.displayAlert("Alert Message", message: result["msg"] as! String)}
                    //                        else{
                    //                            self.displayAlert("Alert Message", message: "Try again")
                    //                        }
                    //                    })
                }
            } else{
                print("no net")
                //self.displayAlert("Alert Message", message: "Please Check Internet connection")
                DispatchQueue.main.async(execute: { () -> Void in
//                    self.hideProgress()
                })
            }
        }
    }
    
   
    
}
