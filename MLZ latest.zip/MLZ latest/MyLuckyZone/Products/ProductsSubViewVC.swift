//
//  ProductsSubViewVC.swift
//  MyLuckyZone
//
//  Created by Kavya Mishra on 5/18/16.
//  Copyright © 2016 Adodis. All rights reserved.
//

import UIKit
import SDWebImage
fileprivate func < <T : Comparable>(lhs: T?, rhs: T?) -> Bool {
  switch (lhs, rhs) {
  case let (l?, r?):
    return l < r
  case (nil, _?):
    return true
  default:
    return false
  }
}

fileprivate func <= <T : Comparable>(lhs: T?, rhs: T?) -> Bool {
  switch (lhs, rhs) {
  case let (l?, r?):
    return l <= r
  default:
    return !(rhs < lhs)
  }
}


class ProductsSubViewVC: UIViewController,UITableViewDataSource,UITableViewDelegate , UIAlertViewDelegate
{
    @IBOutlet weak var productTableView: UITableView!
    
    var theProductCategory = NSString()
    
    var productDetailView = ProductsDetailVC()
    
    var isProductDetailView = Bool()
    
    var senderTag:String?
    
    var theSweepStakeDataArray = NSArray()
    
    var theAuctionDataArray = NSArray()
    
    var theSalesDataArray = NSArray()
    
    var thePlatinumDataArray = NSMutableArray()
    
    var theGoldDataArray = NSMutableArray()
    
    var theSilverDataArray = NSMutableArray()
    
    var thePremiumDataArray = NSArray()
    
    var riskyActionDataArray = NSArray()
    
    var alertTextField = UITextField()
    
    var currentPage = NSInteger()
    
    var totalPage = NSInteger()
    
    var refreshControl: UIRefreshControl!

    
    func refresh(_ sender:AnyObject) {
        self.productTableView.reloadData()
        refreshControl.endRefreshing()
    }

    
    override func didReceiveMemoryWarning()
    {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    
    override func viewWillAppear(_ animated: Bool) {
        
        super.viewWillAppear(animated)
        self.productTableView.tableFooterView = UIView()
        print("willappear")
        refreshControl = UIRefreshControl()
        refreshControl.addTarget(self, action: #selector(ProductsSubViewVC.refresh(_:)), for: UIControlEvents.valueChanged)
        self.productTableView.addSubview(refreshControl)
        if Reachability.isConnectedToNetwork() == true {
            
            self.currentPage = 1
            
            if senderTag == "sweepTakesVC"
            {
                //self.refresh("" as AnyObject)
                self.sweepStakeDataList(self.currentPage)
            }
            else if senderTag == "AuctionVC"
            {
                self.refresh("" as AnyObject)
                self.productForAuction(self.currentPage)
            }
            else if senderTag == "salesVC"
            {
                self.refresh("" as AnyObject)
                self.productForSales(self.currentPage)
            }
            else if senderTag == "platinumVC"
            {
                self.platinumSales(self.currentPage)
            }
            else if senderTag == "goldVC"
            {
                self.refresh("" as AnyObject)
                self.goldSales(self.currentPage)
            }
            else if senderTag == "silverVC"
            {
                self.refresh("" as AnyObject)
                self.silverSales(self.currentPage)
            }
            else if senderTag == "premiumSweepStakesVC"
            {
                self.refresh("" as AnyObject)
                self.premiumSweepStakes(self.currentPage)
            }
            else if senderTag == "riskyVC"
            {
                self.refresh("" as AnyObject)
                self.productForRiskyAuction(self.currentPage)
            }
            
            
            
        } else {
            //self.displayAlert("Alert Message", message: "Please Check Internet connection")
            
        }
        
        

    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        print("didload")
        
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int
    {
        
        switch (senderTag! as String)
        {
        case "sweepTakesVC":
            
            return self.theSweepStakeDataArray.count
            
        case "AuctionVC":
            
            return self.theAuctionDataArray.count
            
        case "salesVC":
            
            return self.theSalesDataArray.count
            
        case "platinumVC":
            
            return self.thePlatinumDataArray.count
            
        case "goldVC":
            
            return self.theGoldDataArray.count
            
        case "silverVC":
            
            return self.theSilverDataArray.count
            
        case "premiumSweepStakesVC":
            
            return self.thePremiumDataArray.count

        case "riskyVC":
            
            return self.riskyActionDataArray.count

        default:
            return 0
            
        }
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        switch(senderTag!) {
            
            case "AuctionVC":
                
                return 90;
            
            case "premiumSweepStakesVC":
            
                return 110
        default:
            return 80
            
        }
    }
    
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell
    {
        
        let cell = productTableView.dequeueReusableCell(withIdentifier: "ProductCell", for: indexPath) as! ProductsSubViewCell
        
        cell.bidNowButton.addTarget(self, action: #selector(ProductsSubViewVC.bidNow(_:)), for: UIControlEvents.touchUpInside)
        
        cell.bidNowButton.tag = (indexPath as NSIndexPath).row

        cell.theReferralLabel?.isHidden = true
        cell.heightConstraint.constant = 0
        
        cell.theEndDate.textColor = UIColor(red: 244/256, green: 80/256, blue: 66/256, alpha: 1.0)
        
        switch (senderTag! as String)
        {
        case "sweepTakesVC":
            cell.theTitleLabel.lineBreakMode = .byWordWrapping // or NSLineBreakMode.ByWordWrapping
            cell.theTitleLabel.numberOfLines = 2//ram if line goes more then bid end point hide
            cell.theTitleLabel?.text = (self.theSweepStakeDataArray[(indexPath as NSIndexPath).row] as AnyObject).value(forKey: "title") as? String
            
            let points = String(format: "%@ Points Per Bid",((self.theSweepStakeDataArray[(indexPath as NSIndexPath).row] as AnyObject).value(forKey: "requiredpoints") as? String)!)

            cell.thePointsLabel?.text = points
            
            cell.theTitleLabel?.text = (self.theSweepStakeDataArray[(indexPath as NSIndexPath).row] as AnyObject).value(forKey: "title") as? String
            
            
            let imagePath = String(format: "%@%@",WebService.sharedInstance.getBaseURL, ((self.theSweepStakeDataArray[(indexPath as NSIndexPath).row] as AnyObject).value(forKey: "imagepath") as? String)!)
            
            cell.bottomConstraint.constant = 15
            
            //cell.theEndDate.isHidden = true
            
            let dateString = (self.theSweepStakeDataArray[(indexPath as NSIndexPath).row] as AnyObject).value(forKey: "bidenddate") as! String!
            
            let formatter = DateFormatter()
            formatter.dateFormat = "YYYY-MM-DD"
            
            let value = "Bid EndDate : " + String(describing: dateString)
            
            //let val = value.replacingOccurrences(of: "Optional", with: "")
            var val = value.replacingOccurrences(of: "Optional", with: "")
            val = val.replacingOccurrences(of: "(", with: "")
            val = val.replacingOccurrences(of: ")", with: "")
            val = val.replacingOccurrences(of: "\"", with: "")
            cell.theEndDate.text = val
            
            cell.theImageView.sd_setImage(with: URL(string:imagePath)
                , placeholderImage: nil
                
                
                , options: SDWebImageOptions.retryFailed
                , progress: {(receivedSize: Int, expectedSize: Int) in
                    
                }
                , completed:{(image: UIImage?, error: Error?, cacheType: SDImageCacheType, imageURL: URL?) in
                    if (image != nil) {
                        cell.theImageView.image = image
                        
                    }
            })
            break;
            
            case "premiumSweepStakesVC":
                
                // Swift
                cell.theTitleLabel.lineBreakMode = .byWordWrapping // or NSLineBreakMode.ByWordWrapping
                cell.theTitleLabel.numberOfLines = 2//ram if line goes more then bid end point hide
                
                cell.theTitleLabel?.text = (self.thePremiumDataArray[(indexPath as NSIndexPath).row] as AnyObject).value(forKey: "title") as? String
                
                let points = String(format: "%@ Points Per Bid",((self.thePremiumDataArray[(indexPath as NSIndexPath).row] as AnyObject).value(forKey: "requiredpoints") as? String)!)

                let referrals = String(format: "%@ referrals required to participate",((self.thePremiumDataArray[(indexPath as NSIndexPath).row] as AnyObject).value(forKey: "requiredreferrals") as? String)!)
                
                
                cell.thePointsLabel?.text = points
                
                cell.heightConstraint.constant = 21
                cell.theReferralLabel?.text = referrals
                cell.theReferralLabel?.isHidden = false
                
                cell.theTitleLabel?.text = (self.thePremiumDataArray[(indexPath as NSIndexPath).row] as AnyObject).value(forKey: "title") as? String
                
                
                let imagePath = String(format: "%@%@",WebService.sharedInstance.getBaseURL, ((self.thePremiumDataArray[(indexPath as NSIndexPath).row] as AnyObject).value(forKey: "imagepath") as? String)!)
                
                cell.bottomConstraint.constant = 15
                
                let dateString = (self.thePremiumDataArray[(indexPath as NSIndexPath).row] as AnyObject).value(forKey: "bidenddate") as! String!
                
                let formatter = DateFormatter()
                formatter.dateFormat = "YYYY-MM-DD"
                
                let value = "Bid EndDate : " + String(describing: dateString)
                
                //let val = value.replacingOccurrences(of: "Optional", with: "")
                var val = value.replacingOccurrences(of: "Optional", with: "")
                val = val.replacingOccurrences(of: "(", with: "")
                val = val.replacingOccurrences(of: ")", with: "")
                val = val.replacingOccurrences(of: "\"", with: "")
                cell.theEndDate.text = val
                
                cell.theImageView.sd_setImage(with: URL(string:imagePath)
                    , placeholderImage: nil
                    , options: SDWebImageOptions.retryFailed
                    , progress: {(receivedSize: Int, expectedSize: Int) in
                        
                    }
                    , completed:{(image: UIImage?, error: Error?, cacheType: SDImageCacheType, imageURL: URL?) in
                        if (image != nil) {
                            cell.theImageView.image = image
                            
                        }
                })
                break;
            
        case "AuctionVC":
            cell.theTitleLabel.lineBreakMode = .byWordWrapping // or NSLineBreakMode.ByWordWrapping
            cell.theTitleLabel.numberOfLines = 2//ram if line goes more then bid end point hide

            cell.theTitleLabel?.text = (self.theAuctionDataArray[(indexPath as NSIndexPath).row] as AnyObject).value(forKey: "title") as? String
            let points = Int(((self.theAuctionDataArray[(indexPath as NSIndexPath).row] as AnyObject).value(forKey: "requiredpoints") as? String)!)
            
            let highestBid =  (self.theAuctionDataArray[(indexPath as NSIndexPath).row] as AnyObject).value(forKey: "highestbidpointsofar")
            let highestBidInString:AnyObject?
            
            if highestBid is NSString
            {
                highestBidInString=Int((highestBid as? String)!) as AnyObject?
            }
            else if highestBid is NSNumber
            {
                highestBidInString=highestBid as? Int as AnyObject?
            }
            else
            {
                highestBidInString = "" as AnyObject?
            }
            
            if(points <= (highestBidInString as! Int))
            {
                cell.thePointsLabel?.text = String(format: "%@ Highest Bid",String(describing: highestBidInString!))
            }
            else {
                cell.thePointsLabel?.text = String(format:"%@ Points Per Bid",((self.theAuctionDataArray[(indexPath as NSIndexPath).row] as AnyObject).value(forKey: "requiredpoints") as? String)!)
            }
            
            let dateString = (self.theAuctionDataArray[(indexPath as NSIndexPath).row] as AnyObject).value(forKey: "bidenddate") as! String!
            
            print(dateString)
            
            let formatter = DateFormatter()
            
            formatter.dateFormat = "YYYY-MM-DD"
            
            //let endDate = formatter.dateFromString(dateString!)
            
            // print(dateString)
            let value = "Bid EndDate : " + String(describing: dateString)
            
            var val = value.replacingOccurrences(of: "Optional", with: "")
            val = val.replacingOccurrences(of: "(", with: "")
            val = val.replacingOccurrences(of: ")", with: "")
            val = val.replacingOccurrences(of: "\"", with: "")
            cell.theEndDate?.text = val

            
            //cell.theEndDate?.text = "Bid EndDate " + String(describing: dateString)
            
            let imagePath = String(format: "%@%@", WebService.sharedInstance.getBaseURL, ((self.theAuctionDataArray[(indexPath as NSIndexPath).row] as AnyObject).value(forKey: "imagepath") as? String)!)
            
            cell.theImageView.sd_setImage(with: URL(string:imagePath)
                , placeholderImage: nil
                , options: SDWebImageOptions.retryFailed
                , progress: {(receivedSize: Int, expectedSize: Int) in
                    
                }
                , completed:{(image: UIImage?, error: Error?, cacheType: SDImageCacheType, imageURL: URL?) in
                    if (image != nil) {
                        cell.theImageView.image = image
                    }
            })
            
        case "salesVC":
            
            cell.bidNowButton .setTitle("BUY NOW", for: UIControlState())
            cell.bidNowButton.tag = (indexPath as NSIndexPath).row
            
            cell.theTitleLabel.lineBreakMode = .byWordWrapping // or NSLineBreakMode.ByWordWrapping
            cell.theTitleLabel.numberOfLines = 2//ram if line goes more then bid end point hide

            cell.theTitleLabel?.text = ((self.theSalesDataArray[indexPath.row]) as AnyObject).value(forKey: "title") as? String
            
            let temp = (self.theSalesDataArray[(indexPath as NSIndexPath).row] as AnyObject).value(forKey: "availableqty") as? NSNumber
            
            cell.thePointsLabel?.text = "Available Quantity: " + String(describing: temp!)
            
            cell.bottomConstraint.constant = 15
            cell.theEndDate.isHidden = true
            
            let imagePath = String(format: "%@%@",  WebService.sharedInstance.getBaseURL, ((self.theSalesDataArray[(indexPath as NSIndexPath).row] as AnyObject).value(forKey: "imagepath") as? String)!)
            
            
            cell.theImageView.sd_setImage(with: URL(string:imagePath)
                , placeholderImage: nil
                , options: SDWebImageOptions.retryFailed
                , progress: {(receivedSize: Int, expectedSize: Int) in
                    
                }
                , completed:{(image: UIImage?, error: Error?, cacheType: SDImageCacheType, imageURL: URL?) in
                    if (image != nil) {
                        cell.theImageView.image = image
                        
                    }
            })
            
        case "platinumVC":
            
            cell.bidNowButton .setTitle("BUY NOW", for: UIControlState())
            
            cell.theTitleLabel.lineBreakMode = .byWordWrapping // or NSLineBreakMode.ByWordWrapping
            cell.theTitleLabel.numberOfLines = 2//ram if line goes more then bid end point hide

            
            cell.theTitleLabel?.text = (self.thePlatinumDataArray[(indexPath as NSIndexPath).row] as AnyObject).value(forKey: "title") as? String
            
            cell.thePointsLabel?.text = String(format:"Available Quantity :%@",((self.thePlatinumDataArray[(indexPath as NSIndexPath).row] as AnyObject).value(forKey: "availableqty") as? NSNumber)!)
            
            cell.bottomConstraint.constant = 15
            cell.theEndDate.isHidden = true
            
            let imagePath = String(format: "%@%@",  WebService.sharedInstance.getBaseURL, ((self.thePlatinumDataArray[(indexPath as NSIndexPath).row] as AnyObject).value(forKey: "imagepath") as? String)!)
            
            
            cell.theImageView.sd_setImage(with: URL(string:imagePath)
                , placeholderImage: nil
                , options: SDWebImageOptions.retryFailed
                , progress: {(receivedSize: Int, expectedSize: Int) in
                    
                }
                , completed:{(image: UIImage?, error: Error?, cacheType: SDImageCacheType, imageURL: URL?) in
                    if (image != nil) {
                        cell.theImageView.image = image
                        
                    }
            })
            
        case "goldVC":
            
            cell.bidNowButton .setTitle("BUY NOW", for: UIControlState())
            
            cell.theTitleLabel.lineBreakMode = .byWordWrapping // or NSLineBreakMode.ByWordWrapping
            cell.theTitleLabel.numberOfLines = 2

            
            cell.theTitleLabel?.text = (self.theGoldDataArray[(indexPath as NSIndexPath).row] as AnyObject).value(forKey: "title") as? String
            
            cell.thePointsLabel?.text = String(format:"Available Quantity :%@",((self.theGoldDataArray[(indexPath as NSIndexPath).row] as AnyObject).value(forKey: "availableqty") as? NSNumber)!)
            
            cell.bottomConstraint.constant = 15
            cell.theEndDate.isHidden = true
            
            
            let imagePath = String(format: "%@%@",  WebService.sharedInstance.getBaseURL, ((self.theGoldDataArray[(indexPath as NSIndexPath).row] as AnyObject).value(forKey: "imagepath") as? String)!)
            
            
            cell.theImageView.sd_setImage(with: URL(string:imagePath)
                , placeholderImage: nil
                , options: SDWebImageOptions.retryFailed
                , progress: {(receivedSize: Int, expectedSize: Int) in
                    
                }
                , completed:{(image: UIImage?, error: Error?, cacheType: SDImageCacheType, imageURL: URL?) in
                    if (image != nil) {
                        cell.theImageView.image = image
                        
                    }
            })
            
        case "silverVC":
            
            cell.bidNowButton .setTitle("BUY NOW", for: UIControlState())
            
            cell.theTitleLabel.lineBreakMode = .byWordWrapping // or NSLineBreakMode.ByWordWrapping
            cell.theTitleLabel.numberOfLines = 2//ram if line goes more then bid end point hide

            
            cell.theTitleLabel?.text = (self.theSilverDataArray[(indexPath as NSIndexPath).row] as AnyObject).value(forKey: "title") as? String
            
            cell.thePointsLabel?.text = String(format:"Available Quantity :%@",((self.theSilverDataArray[(indexPath as NSIndexPath).row] as AnyObject).value(forKey: "availableqty") as? NSNumber)!)
            
            cell.bottomConstraint.constant = 15
            cell.theEndDate.isHidden = true
            
            
            let imagePath = String(format: "%@%@",  WebService.sharedInstance.getBaseURL, ((self.theSilverDataArray[(indexPath as NSIndexPath).row] as AnyObject).value(forKey: "imagepath") as? String)!)
            
            
            cell.theImageView.sd_setImage(with: URL(string:imagePath)
                , placeholderImage: nil
                , options: SDWebImageOptions.retryFailed
                , progress: {(receivedSize: Int, expectedSize: Int) in
                    
                }
                , completed:{(image: UIImage?, error: Error?, cacheType: SDImageCacheType, imageURL: URL?) in
                    if (image != nil) {
                        cell.theImageView.image = image
                    }
            })
        case "riskyVC":
            
            cell.theTitleLabel?.text = (self.riskyActionDataArray[(indexPath as NSIndexPath).row] as AnyObject).value(forKey: "title") as? String
            let points = Int(((self.riskyActionDataArray[(indexPath as NSIndexPath).row] as AnyObject).value(forKey: "requiredpoints") as? String)!)
            
            let highestBid =  (self.riskyActionDataArray[(indexPath as NSIndexPath).row] as AnyObject).value(forKey: "highestbidpointsofar")
            let highestBidInString:AnyObject?
            
            if highestBid is NSString
            {
                highestBidInString=Int((highestBid as? String)!) as AnyObject?
            }
            else if highestBid is NSNumber
            {
                highestBidInString=highestBid as? Int as AnyObject?
            }
            else
            {
                highestBidInString = "" as AnyObject?
            }
            
            if(points <= (highestBidInString as! Int))
            {
                cell.thePointsLabel?.text = String(format: "%@ Highest Bid",String(describing: highestBidInString!))
            }
            else {
                cell.thePointsLabel?.text = String(format:"%@ Points Per Bid",((self.riskyActionDataArray[(indexPath as NSIndexPath).row] as AnyObject).value(forKey: "requiredpoints") as? String)!)
            }
            
            let dateString = (self.riskyActionDataArray[(indexPath as NSIndexPath).row] as AnyObject).value(forKey: "bidenddate") as! String!
            
            print(dateString)
            
            let formatter = DateFormatter()
            
            formatter.dateFormat = "YYYY-MM-DD"
            
            //let endDate = formatter.dateFromString(dateString!)
            
            // print(dateString)
            let value = "Bid EndDate : " + String(describing: dateString)
            var val = value.replacingOccurrences(of: "Optional", with: "")
            val = val.replacingOccurrences(of: "(", with: "")
            val = val.replacingOccurrences(of: ")", with: "")
            val = val.replacingOccurrences(of: "\"", with: "")
            
            cell.theEndDate?.text = val
            
            let imagePath = String(format: "%@%@", WebService.sharedInstance.getBaseURL, ((self.riskyActionDataArray[(indexPath as NSIndexPath).row] as AnyObject).value(forKey: "imagepath") as? String)!)
            
            cell.theImageView.sd_setImage(with: URL(string:imagePath)
                , placeholderImage: nil
                , options: SDWebImageOptions.retryFailed
                , progress: {(receivedSize: Int, expectedSize: Int) in
                    
                }
                , completed:{(image: UIImage?, error: Error?, cacheType: SDImageCacheType, imageURL: URL?) in
                    if (image != nil) {
                        cell.theImageView.image = image
                    }
            })
            
        default:
            print("Type is abc")
        }
        
        
        return cell
    }
    
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        if senderTag == "sweepTakesVC"
        {
            self.performSegue(withIdentifier: "productDetail", sender: ((self.theSweepStakeDataArray[(indexPath as NSIndexPath).row] as AnyObject).value(forKey: "productid") as? String))
            
        } else if senderTag == "AuctionVC"
        {
            self.performSegue(withIdentifier: "productDetail", sender: ((self.theAuctionDataArray[(indexPath as NSIndexPath).row] as AnyObject).value(forKey: "productid") as? String))
        }
        else if senderTag == "salesVC"
        {
            self.performSegue(withIdentifier: "productDetail", sender: ((self.theSalesDataArray[(indexPath as NSIndexPath).row] as AnyObject).value(forKey: "productid") as? String))
        } else if senderTag == "platinumVC"
        {
            self.performSegue(withIdentifier: "productDetail", sender: ((self.thePlatinumDataArray[(indexPath as NSIndexPath).row] as AnyObject).value(forKey: "productid") as? String))
            
        } else if senderTag == "goldVC"
        {
            self.performSegue(withIdentifier: "productDetail", sender: ((self.theGoldDataArray[(indexPath as NSIndexPath).row] as AnyObject).value(forKey: "productid") as? String))
            
        } else if senderTag == "silverVC"
        {
            self.performSegue(withIdentifier: "productDetail", sender: ((self.theSilverDataArray[(indexPath as NSIndexPath).row] as AnyObject).value(forKey: "productid") as? String))
            
        } else if senderTag == "premiumSweepStakesVC"
        {
            self.performSegue(withIdentifier: "productDetail", sender: ((self.thePremiumDataArray[(indexPath as NSIndexPath).row] as AnyObject).value(forKey: "productid") as? String))
            
        } else if senderTag == "riskyVC"
        {
            self.performSegue(withIdentifier: "productDetail", sender: ((self.riskyActionDataArray[(indexPath as NSIndexPath).row] as AnyObject).value(forKey: "productid") as? String))
            
        }
    }
    
    
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        
        if segue.identifier == "productDetail"
        {
            let destinationView = segue.destination as! ProductsDetailVC
            
            if let rootView = self.navigationController?.viewControllers[0] as? mainTabBarController {
                destinationView.title = rootView.titleLabel.text
            }
            
            if (senderTag == "platinumVC" || senderTag == "goldVC" || senderTag == "silverVC")
            {
                destinationView.tag = senderTag! as String as NSString
                destinationView.productID = sender as! String as NSString
                
            }else {
                destinationView.productID = sender as! String as NSString
                
                destinationView.tag = senderTag! as String as NSString
            }
        }
    }
    
    
    func sweepStakeDataList(_ pageNumber:NSInteger)
    {
        self.showProgress()
        
        let body = String(format: "pagenumer=%@&searchkey=%@&token=%@",String(pageNumber),self.theProductCategory,UserDefaults.standard.object(forKey: "token") as! String)
        
        
        
        let task = "listallsweepstakeproducts"
        WebService().sendAPIRequest(UrlClass.baseUrl, body: body,task: task) { (result, error) -> Void in
            if(result.count>0){
            if result["status"] as! Int == 1
            {
                self.totalPage = result["totalpages"] as! NSInteger
                
                if(self.currentPage == 1)
                {
                    self.theSweepStakeDataArray = (result["sweepstakeproductlist"] as! NSArray).mutableCopy() as! NSMutableArray
                } else {
                    
                    let newPageArr = result["sweepstakeproductlist"] as! NSArray
                    
                    let newArr = self.theSweepStakeDataArray.mutableCopy() as? NSMutableArray
                    
                    for i in self.theSweepStakeDataArray.count ..< self.theSweepStakeDataArray.count+newPageArr.count
                    {
                        newArr!.insert(newPageArr[i-self.theSweepStakeDataArray.count], at: i)
                    }
                    self.theSweepStakeDataArray = newArr!
                }
                DispatchQueue.main.async(execute: { () -> Void in
                    self.hideProgress()
                    self.productTableView.reloadData()
                })
            } else if(result["status"] as! Int == 0 || result["status"] as! Int == -1)
            {
                DispatchQueue.main.async(execute: { () -> Void in
                    self.hideProgress()
                    self.displayAlert("Alert Message", message: result["msg"] as! String)
                    self.productTableView.reloadData()
                })
            }else{
                DispatchQueue.main.async(execute: { () -> Void in
                    self.hideProgress()
                    if(result.count>0){
                        self.displayAlert("Alert Message", message: result["msg"] as! String)}
                    else{
                        self.displayAlert("Alert Message", message: "Try again")
                    }
                    self.productTableView.reloadData()
                })
            }
            } else{
                //self.displayAlert("Alert Message", message: "Please Check Internet connection")
                DispatchQueue.main.async(execute: { () -> Void in
                    self.hideProgress()
                    self.productTableView.reloadData()
                })
            }
        }
    }
    
    
    func productForAuction(_ pageNumber:NSInteger)
    {
        self.showProgress()
        
        let body = String(format: "pagenumer=%@&searchkey=%@&token=%@",String(pageNumber),self.theProductCategory,UserDefaults.standard.object(forKey: "token") as! String)
        
        let task = "listallauctionproducts"
        WebService().sendAPIRequest(UrlClass.baseUrl, body: body,task: task) { (result, error) -> Void in
            if(result.count>0){
            if result["status"] as! Int == 1
            {
                self.totalPage = result["totalpages"] as! NSInteger
                
                if(self.currentPage == 1)
                {
                    self.theAuctionDataArray = result["auctionproductlist"] as! NSArray
                } else {
                    
                    let newPageArr = result["auctionproductlist"] as! NSArray
                    
                    let newArr = self.theAuctionDataArray.mutableCopy() as? NSMutableArray
                    
                    for i in self.theAuctionDataArray.count ..< self.theAuctionDataArray.count+newPageArr.count
                    {
                        newArr!.insert(newPageArr[i-self.theAuctionDataArray.count], at: i)
                    }
                    self.theAuctionDataArray = newArr!
                }
                DispatchQueue.main.async(execute: { () -> Void in
                    self.productTableView.reloadData()
                    self.hideProgress()
                    
                })
            } else if(result["status"] as! Int == 0)
            {
                DispatchQueue.main.async(execute: { () -> Void in
                    self.hideProgress()
                    self.productTableView.reloadData()
                })
            }
            
            }else{
              //  self.displayAlert("Alert Message", message: "Please Check Internet connection")
                DispatchQueue.main.async(execute: { () -> Void in
                    self.hideProgress()
                    self.productTableView.reloadData()
                })
            }
        }
    }
    
    func productForSales(_ pageNumber:NSInteger)
    {
        self.showProgress()
        
        let body = String(format: "pagenumer=%@&searchkey=%@&token=%@",String(pageNumber),self.theProductCategory,UserDefaults.standard.object(forKey: "token") as! String)
        
        let task = "listallsalesproducts"
        WebService().sendAPIRequest(UrlClass.baseUrl, body: body,task: task) { (result, error) -> Void in
            
            if(result.count>0){
            if result["status"] as? Int == 1
            {
                self.totalPage = result["totalpages"] as! NSInteger
                
                if(self.currentPage == 1)
                {
                    self.theSalesDataArray = (result["salesproductlist"] as! NSArray).mutableCopy() as! NSMutableArray
                } else {
                    
                    let newPageArr = result["salesproductlist"] as! NSArray
                    
                    let newArr = self.theSalesDataArray.mutableCopy() as? NSMutableArray
                    
                    for i in self.theSalesDataArray.count ..< self.theSalesDataArray.count+newPageArr.count
                    {
                        newArr!.insert(newPageArr[i-self.theSalesDataArray.count], at: i)
                    }
                    self.theSalesDataArray = newArr!
                }
                DispatchQueue.main.async(execute: { () -> Void in
                    self.productTableView.reloadData()
                    self.hideProgress()
                })
            } else if(result["status"] as! Int == 0)
            {
                DispatchQueue.main.async(execute: { () -> Void in
                    self.hideProgress()
                    self.productTableView.reloadData()
                })
            }
            
        }else{
              //  self.displayAlert("Alert Message", message: "Please Check Internet connection")
                DispatchQueue.main.async(execute: { () -> Void in
                    self.hideProgress()
                    self.productTableView.reloadData()
                })
            }
        }
    }
    
    func platinumSales(_ pageNumber:NSInteger)
    {
        self.showProgress()
        
        let body = String(format:"token=%@&pagenumer=%@&salestype=1&searchkey=%@", UserDefaults.standard.object(forKey: "token") as! String,String(pageNumber),self.theProductCategory)
        
        let task = "listallrefsalesproducts"
        
        WebService().sendAPIRequest(UrlClass.baseUrl, body: body,task: task) { (result, error) -> Void in
            
            
            if(result.count>0){
            
            if result["status"] as? Int == 1
            {
                self.totalPage = result["totalpages"] as! NSInteger
                
                if(self.currentPage == 1)
                {
//                    self.thePlatinumDataArray = result.objectForKey("refsalesproductlist")!.mutableCopy() as! NSMutableArray
                    self.thePlatinumDataArray = NSMutableArray()
                    let array = result["refsalesproductlist"] as! Array<Dictionary<String, AnyObject>>
                    for item in array {
                        if item["salestype"] as? String == "1" {
                            self.thePlatinumDataArray.add(item)
                        }
                    }
                    
                } else {
                    
//                    let newArr = self.thePlatinumDataArray.mutableCopy() as? NSMutableArray
//
//                    for item in result["refsalesproductlist"] as! Array<Dictionary<String, String>> {
//                        if item["salestype"]  == "1" {
//                            newArr?.add(item)
//                        }
//                    }
//                    self.thePlatinumDataArray = newArr!
                    
                    let newPageArr = result["refsalesproductlist"] as! NSArray
                    
                    let newArr = self.thePlatinumDataArray.mutableCopy() as? NSMutableArray
                    
                    for i in self.thePlatinumDataArray.count ..< self.thePlatinumDataArray.count+newPageArr.count
                    {
                        newArr!.insert(newPageArr[i-self.thePlatinumDataArray.count], at: i)
                    }
                    self.thePlatinumDataArray = newArr!

                    
                    
                }
                DispatchQueue.main.async(execute: { () -> Void in
                    self.productTableView.reloadData()
                    self.hideProgress()
                })
            } else if(result["status"] as! Int == 0)
            {
                DispatchQueue.main.async(execute: { () -> Void in
                    self.hideProgress()
                    self.productTableView.reloadData()
                })
            }
            }else{
              //  self.displayAlert("Alert Message", message: "Please Check Internet connection")
                DispatchQueue.main.async(execute: { () -> Void in
                    self.hideProgress()
                    self.productTableView.reloadData()
                })
            }
        }
    }
    
    
    func goldSales(_ pageNumber:NSInteger)
    {
        self.showProgress()
        
        let body = String(format:"token=%@&pagenumer=%@&salestype=2&searchkey=%@", UserDefaults.standard.object(forKey: "token") as! String,String(pageNumber),self.theProductCategory)
        
        let task = "listallrefsalesproducts"
        
        WebService().sendAPIRequest(UrlClass.baseUrl, body: body,task: task) { (result, error) -> Void in
            
            if(result.count>0){
            
            if result["status"] as! Int == 1
            {
                self.totalPage = result["totalpages"] as! NSInteger
                
                if(self.currentPage == 1)
                {
//                    self.theGoldDataArray = result.objectForKey("refsalesproductlist") as! NSMutableArray
                    self.theGoldDataArray = NSMutableArray()
                    for item in result["refsalesproductlist"] as! Array<Dictionary<String, AnyObject>> {
                        if item["salestype"] as? String == "2" {
                            self.theGoldDataArray.add(item)
                        }
                    }
                    
                } else {
//                    let newPageArr = result.objectForKey("refsalesproductlist") as! NSArray
//                    let newArr = self.theGoldDataArray.mutableCopy() as? NSMutableArray
//                    for i in self.theGoldDataArray.count ..< self.theGoldDataArray.count+newPageArr.count
//                    {
//                        newArr!.insertObject(newPageArr[i-self.theGoldDataArray.count], atIndex: i)
//                    }
                    let newArr = self.theGoldDataArray.mutableCopy() as? NSMutableArray
                    for item  in self.theGoldDataArray {
                        if (item as! Dictionary<String, AnyObject>)["salestype"] as? String  == "2" {
                            newArr?.add(item)
                        }
                    }
                    self.theGoldDataArray = newArr!
                }
                
                DispatchQueue.main.async(execute: { () -> Void in
                    self.productTableView.reloadData()
                    self.hideProgress()
                })
                
            } else if(result["status"] as! Int == 0)
            {
                DispatchQueue.main.async(execute: { () -> Void in
                    self.hideProgress()
                    self.productTableView.reloadData()
                })
            }
            }
            else{
               // self.displayAlert("Alert Message", message: "Please Check Internet connection")
                DispatchQueue.main.async(execute: { () -> Void in
                    self.hideProgress()
                    self.productTableView.reloadData()
                })
            }
        }
    }
    
    
    func silverSales(_ pageNumber:NSInteger)
    {
        
        self.showProgress()
        
        let body = String(format:"token=%@&pagenumer=%@&salestype=3&searchkey=%@", UserDefaults.standard.object(forKey: "token") as! String,String(pageNumber),self.theProductCategory)
        
        let task = "listallrefsalesproducts"
        
        WebService().sendAPIRequest(UrlClass.baseUrl, body: body,task: task) { (result, error) -> Void in
            
            if(result.count>0){
            
            if result["status"] as! Int == 1
            {
                self.totalPage = result["totalpages"] as! NSInteger
                
                if(self.currentPage == 1)
                {
//                    self.theSilverDataArray = result.objectForKey("refsalesproductlist") as! NSMutableArray
                    self.theSilverDataArray = NSMutableArray()
                    for item in result["refsalesproductlist"] as! NSArray {
                        if (item as! Dictionary<String, AnyObject>)["salestype"] as? String == "3" {
                            self.theSilverDataArray.add(item)
                        }
                    }
                    
                } else {
                    let newArr = self.theSilverDataArray.mutableCopy() as? NSMutableArray
                    for item in self.theSilverDataArray {
                        if (item as! Dictionary<String, AnyObject>)["salestype"] as? String  == "3" {
                            newArr?.add(item)
                        }
                    }
                    self.theSilverDataArray = newArr!
                }
                DispatchQueue.main.async(execute: { () -> Void in
                    self.hideProgress()
                    self.productTableView.reloadData()
                })
            } else if(result["status"] as! Int == 0)
            {
                DispatchQueue.main.async(execute: { () -> Void in
                    self.hideProgress()
                    self.productTableView.reloadData()
                })
            }
            }else{
                //self.displayAlert("Alert Message", message: "Please Check Internet connection")
                DispatchQueue.main.async(execute: { () -> Void in
                    self.hideProgress()
                    self.productTableView.reloadData()
                })
            }
        }
    }
    
    
    
    func premiumSweepStakes(_ pageNumber:NSInteger)
    {
        
        self.showProgress()
        
        WebService.sharedInstance.getPremiumSweepStakesList(pageNumber, productCategory: self.theProductCategory, callback: {(result, error) -> Void in
            
            if(result.count>0){
            
            if result["status"] as? Int == 1
            {
                self.totalPage = result["totalpages"] as! NSInteger
                
                if(self.currentPage == 1)
                {
                    self.thePremiumDataArray = (result["sweepstakeproductlist"] as! NSArray).mutableCopy() as! NSMutableArray
                } else {
                    
                    let newPageArr = result["sweepstakeproductlist"] as! NSArray
                    
                    let newArr = self.thePremiumDataArray.mutableCopy() as? NSMutableArray
                    
                    for i in self.thePremiumDataArray.count ..< self.thePremiumDataArray.count+newPageArr.count
                    {
                        newArr!.insert(newPageArr[i-self.thePremiumDataArray.count], at: i)
                    }
                    self.thePremiumDataArray = newArr!
                }
                DispatchQueue.main.async(execute: { () -> Void in
                    self.hideProgress()
                    self.productTableView.reloadData()
                })
            } else if(result["status"] as? Int == 0)
            {
                DispatchQueue.main.async(execute: { () -> Void in
                    self.hideProgress()
                    self.productTableView.reloadData()
                })
            }
            }else{
                //self.displayAlert("Alert Message", message: "Please Check Internet connection")
                DispatchQueue.main.async(execute: { () -> Void in
                    self.hideProgress()
                    self.productTableView.reloadData()
                })
            }
        })
    }
    
    
    
    func productForRiskyAuction(_ pageNumber:NSInteger)
    {
        self.showProgress()
        
        let body = String(format: "pagenumer=%@&searchkey=%@&token=%@",String(pageNumber),self.theProductCategory,UserDefaults.standard.object(forKey: "token") as! String)
        
        let task = "listallriskyauctionproducts"
        WebService().sendAPIRequest(UrlClass.baseUrl, body: body,task: task) { (result, error) -> Void in
            
            if(result.count>0){
            
            if result["status"] as! Int == 1
            {
                self.totalPage = result["totalpages"] as! NSInteger
                
                if(self.currentPage == 1)
                {
                    self.riskyActionDataArray = result["auctionproductlist"] as! NSArray
                } else {
                    
                    let newPageArr = result["auctionproductlist"] as! NSArray
                    
                    let newArr = self.riskyActionDataArray.mutableCopy() as? NSMutableArray
                    
                    for i in self.riskyActionDataArray.count ..< self.riskyActionDataArray.count + newPageArr.count
                    {
                        newArr!.insert(newPageArr[i - self.riskyActionDataArray.count], at: i)
                    }
                    self.riskyActionDataArray = newArr!
                }
                DispatchQueue.main.async(execute: { () -> Void in
                    self.hideProgress()
                    self.productTableView.reloadData()
                   
                    
                })
            } else if(result["status"] as! Int == 0)
            {
                DispatchQueue.main.async(execute: { () -> Void in
                    self.hideProgress()
                    self.productTableView.reloadData()
                })
            }
            }else{
               // self.displayAlert("Alert Message", message: "Please Check Internet connection")
                DispatchQueue.main.async(execute: { () -> Void in
                    self.hideProgress()
                    self.productTableView.reloadData()
                })
            }
        }
    }

    
    
    func bidNow(_ sender : UIButton)
    {
        if senderTag == "sweepTakesVC"
        {
            self.performSegue(withIdentifier: "productDetail", sender: ((self.theSweepStakeDataArray[sender.tag] as AnyObject).value(forKey: "productid") as? String))
            
        } else if senderTag == "AuctionVC"
        {
            self.performSegue(withIdentifier: "productDetail", sender: ((self.theAuctionDataArray[sender.tag] as AnyObject).value(forKey: "productid") as? String))
        }
        else if senderTag == "salesVC"
        {
            self.performSegue(withIdentifier: "productDetail", sender: ((self.theSalesDataArray[sender.tag] as AnyObject).value(forKey: "productid") as? String))
        } else if senderTag == "platinumVC"
        {
            self.performSegue(withIdentifier: "productDetail", sender: ((self.thePlatinumDataArray[sender.tag] as AnyObject).value(forKey: "productid") as? String))
            
        } else if senderTag == "goldVC"
        {
            self.performSegue(withIdentifier: "productDetail", sender: ((self.theGoldDataArray[sender.tag] as AnyObject).value(forKey: "productid") as? String))
            
        } else if senderTag == "silverVC"
        {
            self.performSegue(withIdentifier: "productDetail", sender: ((self.theSilverDataArray[sender.tag] as AnyObject).value(forKey: "productid") as? String))
        } else if senderTag == "premiumSweepStakesVC"
        {
            self.performSegue(withIdentifier: "productDetail", sender: ((self.thePremiumDataArray[sender.tag] as AnyObject).value(forKey: "productid") as? String))
        }
        else if senderTag == "riskyVC"
        {
            self.performSegue(withIdentifier: "productDetail", sender: ((self.riskyActionDataArray[sender.tag] as AnyObject).value(forKey: "productid") as? String))
        }
        
        
        //        if (sender.titleLabel!.text == "BID NOW")
        //        {
        //            let createAccountErrorAlert = UIAlertView()
        //
        //            createAccountErrorAlert.tag = sender.tag
        //
        //            createAccountErrorAlert.delegate = self
        //
        //            createAccountErrorAlert.addButtonWithTitle("CANCEL")
        //
        //
        //
        //            if (senderTag == "sweepTakesVC")
        //            {
        //              createAccountErrorAlert.title = "Confirmation to Bid"
        //              createAccountErrorAlert.message = "Are you sure you want to bid this product?"
        //              createAccountErrorAlert.addButtonWithTitle("OK")
        //              createAccountErrorAlert.show()
        //
        //            } else if (senderTag == "AuctionVC")
        //            {
        //                createAccountErrorAlert.title = "Enter Details"
        //                createAccountErrorAlert.addButtonWithTitle("SUBMIT")
        //                createAccountErrorAlert.alertViewStyle = UIAlertViewStyle.PlainTextInput
        //                createAccountErrorAlert.alertViewStyle = UIAlertViewStyle.PlainTextInput
        //                alertTextField = createAccountErrorAlert.textFieldAtIndex(0)!
        //                alertTextField.placeholder = "Enter Points to Bid"
        //                alertTextField.keyboardType = .NumberPad
        //
        //                createAccountErrorAlert.show()
        //            }
        //
        //        } else if (sender.titleLabel!.text == "BUY NOW")
        //          {
        //            switch (senderTag! as String)
        //            {
        //            case "salesVC":
        //
        //            self.performSegueWithIdentifier("productDetail", sender: self.theSalesDataArray.objectAtIndex(sender.tag).valueForKey("productid"))
        //
        //            case "platinumVC":
        //
        //            self.performSegueWithIdentifier("productDetail", sender: self.thePlatinumDataArray.objectAtIndex(sender.tag).valueForKey("productid"))
        //
        //            case "goldVC":
        //
        //            self.performSegueWithIdentifier("productDetail", sender: self.theGoldDataArray.objectAtIndex(sender.tag).valueForKey("productid"))
        //
        //            case "silverVC":
        //
        //            self.performSegueWithIdentifier("productDetail", sender: self.theSilverDataArray.objectAtIndex(sender.tag).valueForKey("productid"))
        //
        //            default:
        //            break
        //            }
        //        }
        //
        //    }
        
        
        //      func alertView(alertView: UIAlertView, clickedButtonAtIndex buttonIndex: Int)
        //      {
        //        if (buttonIndex == 1)
        //        {
        //            if senderTag == "sweepTakesVC"
        //            {
        //            self.bidSweepStakeProduct(alertView.tag)
        //            }
        //            if senderTag == "AuctionVC"
        //            {
        //            self.bidAuctionProduct(alertView.tag)
        //
        //            }
        //        }
        //
    }
    
    
    //    func bidSweepStakeProduct(index:NSInteger)
    //    {
    //        self.showProgress()
    //
    //         let body = String(format:"token=%@&productid=%@", NSUserDefaults.standardUserDefaults().objectForKey("token") as! String , self.theSweepStakeDataArray.objectAtIndex(index).valueForKey("productid")as! String)
    //
    //                let task = "bidforsweepstakeproduct"
    //                WebService().sendAPIRequest(UrlClass.baseUrl, body: body,task: task) { (result, error) -> Void in
    //
    //                    print(result)
    //
    //                    if result.objectForKey("status") as! Int == 1
    //                    {
    //                    self.hideProgress()
    //
    //                    self.displayAlert("Alert Message", message: (result.objectForKey("msg") as? String)!)
    //
    //                    } else  if result.objectForKey("status") as! Int == 0
    //                    {
    //                    self.hideProgress()
    //
    //                    self.displayAlert("Alert Message", message: (result.objectForKey("msg") as? String)!)
    //                    }
    //                }
    //    }
    
    
    //    func bidAuctionProduct(index:NSInteger)
    //    {
    //     self.showProgress()
    //
    //        let body = String(format:"token=%@&productid=%@&points=%@", NSUserDefaults.standardUserDefaults().objectForKey("token") as! String , self.theAuctionDataArray.objectAtIndex(index).valueForKey("productid")as! String,self.alertTextField.text! as String)
    //
    //        let task = "bidforauctionproduct"
    //        WebService().sendAPIRequest(UrlClass.baseUrl, body: body,task: task) { (result, error) -> Void in
    //
    //            if result.objectForKey("status") as! Int == 1
    //            {
    //                self.hideProgress()
    //
    //                self.displayAlert("Alert Message", message: (result.objectForKey("msg") as? String)!)
    //
    //            } else  if result.objectForKey("status") as! Int == 0
    //            {
    //                self.hideProgress()
    //
    //                self.displayAlert("Alert Message", message: (result.objectForKey("msg") as? String)!)
    //
    //            } }
    //    }
    
    func scrollViewDidEndDragging(_ scrollView: UIScrollView, willDecelerate decelerate: Bool) {
        
        let currentOffset = scrollView.contentOffset.y
        
        let maximumOffset = scrollView.contentSize.height - scrollView.frame.size.height
        
        
        if (maximumOffset - currentOffset <= 10)
        {
            if (self.currentPage == totalPage)
            {
                
            } else {
                self.currentPage = self.currentPage + 1
                
                //self.showProgress()
                switch (senderTag! as String)
                {
                case "sweepTakesVC":
                    self.sweepStakeDataList(self.currentPage)
                    
                case "AuctionVC":
                    self.productForAuction(self.currentPage)
                    
                case "salesVC":
                    self.productForSales(self.currentPage)
                    
                case "platinumVC":
                    self.platinumSales(self.currentPage)
                    
                case "goldVC":
                    self.goldSales(self.currentPage)
                    
                case "silverVC":
                    self.silverSales(self.currentPage)
                    
                case "riskyVC":
                    self.productForRiskyAuction(self.currentPage)
                    
                case "premiumSweepStakesVC":
                    self.premiumSweepStakes(self.currentPage)
                    
                default: break
                }
            }
        }
    }
    
    
    
    
    
    // func displayAlert(title: String, message: String) {
    //    let alertController = UIAlertController(title: title, message: message, preferredStyle: .Alert)
    //    alertController.addAction(UIAlertAction(title: "OK", style: .Default, handler: nil))
    //    presentViewController(alertController, animated: true, completion: nil)
    //    return
    //    }
    
    
    
    
    
    
    
    
    
    
    
    /*
    // MARK: - Navigation
    
    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
    // Get the new view controller using segue.destinationViewController.
    // Pass the selected object to the new view controller.
    }
    */
    
}
