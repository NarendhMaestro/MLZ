//
//  ProductDetailCell.swift
//  MyLuckyZone
//
//  Created by Kavya Mishra on 5/28/16.
//  Copyright © 2016 Adodis. All rights reserved.
//

import UIKit

class ProductDetailCell: UICollectionViewCell
{
    
    @IBOutlet weak var theImageView: UIImageView!
}
