//
//  ProductsSubViewCell.swift
//  MyLuckyZone
//
//  Created by Kavya Mishra on 5/18/16.
//  Copyright © 2016 Adodis. All rights reserved.
//

import UIKit

class ProductsSubViewCell: UITableViewCell {

    @IBOutlet var bottomConstraint: NSLayoutConstraint!
    @IBOutlet weak var theEndDate: UILabel!
    @IBOutlet weak var bidNowButton: UIButton!
    @IBOutlet var thePointsLabel: UILabel!
    @IBOutlet var theImageView: UIImageView!
    @IBOutlet weak var theTitleLabel: UILabel!
    
    @IBOutlet var heightConstraint: NSLayoutConstraint!
    @IBOutlet var theReferralLabel: UILabel!
    
    @IBOutlet var bottomHeoghtConstraint: NSLayoutConstraint!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
