//
//  ProductsDetailVC.swift
//  MyLuckyZone
//
//  Created by Kavya Mishra on 5/20/16.
//  Copyright © 2016 Adodis. All rights reserved.
//

import UIKit
import SDWebImage
fileprivate func < <T : Comparable>(lhs: T?, rhs: T?) -> Bool {
  switch (lhs, rhs) {
  case let (l?, r?):
    return l < r
  case (nil, _?):
    return true
  default:
    return false
  }
}

fileprivate func <= <T : Comparable>(lhs: T?, rhs: T?) -> Bool {
  switch (lhs, rhs) {
  case let (l?, r?):
    return l <= r
  default:
    return !(rhs < lhs)
  }
}



class ProductsDetailVC: UIViewController , UICollectionViewDataSource , UICollectionViewDelegate {
    
    @IBOutlet weak var bidNowButton: UIButton!
    
    @IBOutlet var bidNow: UIButton!
    
    @IBOutlet weak var theCollectionView: UICollectionView!
    
    @IBOutlet var theDescriptionLabel: UILabel!
    
    @IBOutlet var thePrizeLabel: UILabel!
    
    @IBOutlet var theRequiredPointLabel: UILabel!
    
    @IBOutlet var theProductTitleLabel: UILabel!
    
    @IBOutlet weak var bidEndDateLabel: UILabel!
    
    @IBOutlet var referralMessageLabel: UILabel!
    
   var imageDataArray = NSArray()
    
    @IBOutlet weak var maxQuantityConstraint: NSLayoutConstraint!
    @IBOutlet weak var maxQuantitybottomConstraint: NSLayoutConstraint!
    @IBOutlet weak var maxQuantityTopConstraint: NSLayoutConstraint!
    @IBOutlet weak var theMaxQuantityLabel: UILabel!
    
    @IBOutlet weak var theReferalLabel: UILabel!
    
    @IBOutlet weak var referalTopConstraint: NSLayoutConstraint!
    @IBOutlet weak var referalConstraint: NSLayoutConstraint!
   // var productDataArray = NSMutableArray()
    
    @IBOutlet weak var thePrizeLabelConstraint: NSLayoutConstraint!
    @IBOutlet weak var thePrizeLabelTopConstraion: NSLayoutConstraint!
    var productID = NSString()
    
    var tag = NSString()
    
    var alertTextField = UITextField()
    var result : NSDictionary?
    var maxAllowedQuantity : Int?


    @IBOutlet var heightConstraint: NSLayoutConstraint!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
        self.theDescriptionLabel.text = "";
        self.thePrizeLabel.text = "";
        self.theRequiredPointLabel.text = "";
        self.theProductTitleLabel.text = "";
        self.bidEndDateLabel.text = "";
        
        self.theMaxQuantityLabel.text = "";

        self.theReferalLabel.text = "";
        self.referralMessageLabel.textColor = UIColor(red: 136/256, green: 11/256, blue: 36/256, alpha: 1.0)
    
        self.bidNowButton.backgroundColor = UIColor(red: 233/256, green: 97/256, blue: 45/256, alpha: 1.0)
        self.bidNowButton.titleLabel?.textColor = UIColor.white
    
    }
    
     func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int
    {
        return  imageDataArray.count

        
    }
    
    // The cell that is returned must be retrieved from a call to -dequeueReusableCellWithReuseIdentifier:forIndexPath:
     func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell
     {
        let cell = self.theCollectionView.dequeueReusableCell(withReuseIdentifier: "productDetailCell",for:indexPath) as! ProductDetailCell
        
        let imagePath = String(format: "%@%@",WebService.sharedInstance.getBaseURL, ((self.imageDataArray.object(at: (indexPath as NSIndexPath).row)) as? String)!)
        
        
        //  let imageUrl = NSURL(string: imagePath)
        
        cell.theImageView.sd_setImage(with: URL(string:imagePath)
            , placeholderImage: nil
            , options: SDWebImageOptions.retryFailed
            , progress: {(receivedSize: Int, expectedSize: Int) in
                
            }
            , completed:{(image: UIImage?, error: Error?, cacheType: SDImageCacheType, imageURL: URL?) in
                if (image != nil) {
                cell.theImageView.image = image
                    
                }
        })

        
        return cell
    }
    
   
    
    

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(true)
        
        if Reachability.isConnectedToNetwork() == true {
            if tag == "sweepTakesVC" || tag == "premiumSweepStakesVC"
            {
                self.bidNowButton.setTitle("BID NOW", for: UIControlState())
                
                self.theMaxQuantityLabel.isHidden = true
                self.maxQuantityTopConstraint.constant = 0
                self.maxQuantityConstraint.constant = 0
                
                self.referalTopConstraint.constant=0
//                self.referalConstraint.constant=0
                if tag == "sweepTakesVC" {
                    self.theReferalLabel.isHidden = true
                    self.sweepStakeProductDetail()
                } else {
                    self.theReferalLabel.isHidden = false
                    self.premiumSweepStakeProductDetails()
                }
                
            }
            else if tag == "AuctionVC" || tag == "riskyVC"
            {
                self.bidNowButton.setTitle("BID NOW", for: UIControlState())
                
                self.theMaxQuantityLabel.isHidden = true
                self.maxQuantityTopConstraint.constant = 0
                self.maxQuantityConstraint.constant = 0
                self.theReferalLabel.isHidden = true
                self.referalTopConstraint.constant = 0
                self.referalConstraint.constant=0
                self.thePrizeLabelConstraint.constant = 0
                self.thePrizeLabelTopConstraion.constant = 0
                if tag == "riskyVC" {
                    self.riskyAuctionProductDetail()
                } else {
                    self.auctionProductDetail()
                }
            }
            else if tag == "salesVC"
            {
                self.referalTopConstraint.constant = 0
                self.referalConstraint.constant=0
                self.bidNowButton.setTitle("BUY NOW", for: UIControlState())
                self.salesProductDetail()
                
            }
            else if tag == "platinumVC"
            {
                self.bidNowButton.setTitle("", for: UIControlState())
                
                self.platinumSalesProductDetail()
                
            }
            else if tag == "goldVC"
            {
                self.bidNowButton.setTitle("", for: UIControlState())
                self.goldSalesProductDetail()
                
            }
            else if tag == "silverVC"
            {
                self.bidNowButton.setTitle("", for: UIControlState())
                self.silverSalesProductDetail()
                
            }
        } else {
        self.displayAlert("Alert Message", message: "Please Check Internet connection")
   
        }
    }
    
    func updateBidNowButton(_ result : NSDictionary!) {
        if result == nil {
            return
        }
        self.result = result
        let usercanbid = result["usercanbid"] as? Int
        if usercanbid == 1 {
            //show bid now button
            self.bidNowButton.setTitle("BID NOW", for: UIControlState())
            self.referralMessageLabel.isHidden = false
        } else {
            self.referralMessageLabel.text = result["displaymessage"] as? String
            var useravailablepoint : Int? = 0
            if let useravailablepointString = result["useravailablepoint"] as? String {
                useravailablepoint = Int(useravailablepointString)
            }
            var requiredpoints : Int? = 0
            if let requiredpointsString = result["requiredpoints"] as? String {
                requiredpoints = Int(requiredpointsString)
            }
            
            var useravailabletotalreferrals : Int? = 0
            if let useravailabletotalreferralsString = result["useravailabletotalreferrals"] as? String {
                useravailabletotalreferrals = Int(useravailabletotalreferralsString)
            }
            var requiredreferrals : Int? = 0
            if let requiredreferralsString = result["requiredreferrals"] as? String {
                requiredreferrals = Int(requiredreferralsString)
            }
            let userremainingbid = result["userremainingbid"] as? Int
            
            let isthisuserhighestbid = result["isthisuserhighestbid"] as? Int
            
            if isthisuserhighestbid == 1 {
                self.bidNowButton.setTitle("You are the higgest bidder", for: UIControlState())
                self.bidNowButton.isEnabled = false
            } else if useravailablepoint < requiredpoints {
                self.bidNowButton.setTitle("EARN MORE POINTS", for: UIControlState())
                //show earn more points button
            } else if useravailabletotalreferrals < requiredreferrals {
                //show refer now button
                self.bidNowButton.setTitle("REFER NOW", for: UIControlState())
            } else if userremainingbid <= 0 {
                self.bidNowButton.isHidden = true
            }
        }
        self.bidNowButton.backgroundColor = UIColor(red: 233/256, green: 97/256, blue: 45/256, alpha: 1.0)
        bidNowButton.setTitleColor(UIColor.white, for: UIControlState())

    }
    
    func updateBidNowButtonForSales(_ result : NSDictionary?) {
        self.result = result
        let allowedToBuy = result?["allowedtobuy"] as? Int
        let haveEnoughPoints = result?["haveenoughpoints"] as? Int
        let haveEnoughReferrals = result?["haveenoughreferrals"] as? Int
        self.referralMessageLabel.text = result?["displaymessage"] as? String
        if allowedToBuy == 1 {
            if haveEnoughPoints == 1 {
                if haveEnoughReferrals == 1{
                    //buy now
                    self.bidNowButton.setTitle("BUY NOW", for: UIControlState())
                    referralMessageLabel.isHidden = true
                } else {
                    //refer now
                    self.bidNowButton.setTitle("REFER NOW", for: UIControlState())
                }
            } else {
                //earn more
                self.bidNowButton.setTitle("EARN MORE POINTS", for: UIControlState())
            }
        } else {
            //earn more
            self.bidNowButton.setTitle("EARN MORE POINTS", for: UIControlState())
        }
        self.bidNowButton.backgroundColor = UIColor(red: 233/256, green: 97/256, blue: 45/256, alpha: 1.0)
        bidNowButton.setTitleColor(UIColor.white, for: UIControlState())
    }
    
    func updateBidNowButtonForOpenSales(_ result : NSDictionary?) {
        self.result = result
        let haveEnoughPoints = result?.object(forKey: "haveenoughpoints") as? Int
            if haveEnoughPoints == 1 {
                //buy now
                self.bidNowButton.setTitle("BUY NOW", for: UIControlState())
                referralMessageLabel.isHidden = true
            } else {
                //earn more
                self.referralMessageLabel.text = (result?["product"] as? NSDictionary)?["displaymessage"] as? String
                self.bidNowButton.setTitle("EARN MORE POINTS", for: UIControlState())
            }
        self.bidNowButton.backgroundColor = UIColor(red: 233/256, green: 97/256, blue: 45/256, alpha: 1.0)
        bidNowButton.setTitleColor(UIColor.white, for: UIControlState())
    }
    
    func premiumSweepStakeProductDetails() {//(result["product"] as! NSDictionary).object(forKey: "requiredreferrals") as? String
        self.showProgress()
        
        WebService.sharedInstance.getPremiumSweepStakesProductDetail(productID, callback: { ( result, error) -> Void in
            
            if result["status"] as! Int == 1
            {
                DispatchQueue.main.async(execute: { () -> Void in
                    self.hideProgress()
                    self.imageDataArray = result["product"]?["imagepath"] as! NSArray
                    self.theProductTitleLabel.text = (result["product"] as! NSDictionary).object(forKey: "title") as? String
                    let reqiredPouint = String(format:"Min Required Points Per Bid:  %@", (result["product"] as! NSDictionary).object(forKey: "requiredpoints") as! String)
                    self.theRequiredPointLabel.text = reqiredPouint
                    self.theDescriptionLabel.text = (result["product"] as! NSDictionary).object(forKey: "description") as? String
                    
                    
                    self.theReferalLabel.text = "Required Referrals:  "+String((result["product"] as! NSDictionary).object(forKey: "requiredreferrals") as! String)

                    
                    self.referralMessageLabel.text = (result["product"] as! NSDictionary).object(forKey: "displaymessage") as? String
                    let prizeSize = String(format:"No. of Prizes:  %@", (result["product"] as! NSDictionary).object(forKey: "quantity") as! String)
                    
                    self.thePrizeLabel.text = prizeSize
                    
                    
                    self.updateBidNowButton(result["product"] as? NSDictionary)
                    
            
                    self.bidEndDateLabel.text = String(format:"Bid EndDate :  %@",  (result["product"] as! NSDictionary).object(forKey: "bidenddate") as! String)
                    
                    self.theCollectionView.reloadData()
                    
                })
            } else if(result["status"] as! Int == 0) {
                DispatchQueue.main.async(execute: { () -> Void in
                    self.hideProgress()
                    self.displayAlert("Alert Message", message: result["msg"] as! String)
                })
            }
        })
    }
    
    func sweepStakeProductDetail()
    {
        self.showProgress()

        let body = String(format:"token=%@&productid=%@", UserDefaults.standard.object(forKey: "token") as! String , productID)
        
        let task = "getsweepstakeproductdetail"
        WebService().sendAPIRequest(UrlClass.baseUrl, body: body,task: task) { ( result, error) -> Void in
            
            if result["status"] as! Int == 1
            {
            DispatchQueue.main.async(execute: { () -> Void in
                self.hideProgress()
                
                
                self.imageDataArray = result["product"]?["imagepath"] as! NSArray
                
            self.theProductTitleLabel.text = (result["product"] as! NSDictionary).object(forKey: "title") as? String
                
                let reqiredPouint = String(format:"Min Required Points Per Bid:  %@", (result["product"] as! NSDictionary).object(forKey: "requiredpoints") as! String)

             self.theRequiredPointLabel.text = reqiredPouint
                
                self.theDescriptionLabel.text = (result["product"] as! NSDictionary).object(forKey: "description") as? String
                
            
                self.bidEndDateLabel.text = String(format:"Bid EndDate :  %@",  (result["product"] as! NSDictionary).object(forKey: "bidenddate") as! String)

            let prizeSize = String(format:"No. of Prizes:  %@", (result["product"] as! NSDictionary).object(forKey: "quantity") as! String)

            self.thePrizeLabel.text = prizeSize
                self.updateBidNowButton(result["product"] as? NSDictionary)
                self.theCollectionView.reloadData()
                
            })
            } else if(result["status"] as! Int == 0) {
                DispatchQueue.main.async(execute: { () -> Void in
                    self.hideProgress()
                    self.displayAlert("Alert Message", message: result["msg"] as! String)
                })
            }
        }
    }
    
    
    func auctionProductDetail()
    {
        self.showProgress()

        let body = String(format:"token=%@&productid=%@", UserDefaults.standard.object(forKey: "token") as! String , productID)
        
        let task = "getauctionproductdetail"
        WebService().sendAPIRequest(UrlClass.baseUrl, body: body,task: task) { ( result, error) -> Void in
            
            if result["status"] as! Int == 1
            {
                
                DispatchQueue.main.async(execute: { () -> Void in
                    
                    self.hideProgress()
                    
                    if((result["product"] as! NSDictionary).object(forKey: "isthisuserhighestbid") as? NSInteger == 1)
                    {
                    self.bidNowButton .setTitle("You are the Highest bidder", for: UIControlState())
                        
                        self.bidNow.setTitleColor(UIColor.orange, for: UIControlState())
                        
                    self.bidNow.backgroundColor = UIColor.clear

                    }
                    
                    self.imageDataArray = result["product"]?["imagepath"] as! NSArray
                    
                    self.theCollectionView.reloadData()

                    self.theProductTitleLabel.text = (result["product"] as! NSDictionary).object(forKey: "title") as? String
                    
                    
                    self.bidEndDateLabel.text = String(format:"Bid EndDate :  %@",  (result["product"] as! NSDictionary).object(forKey: "bidenddate") as! String)
                    
                    let requiredPoint = (result["product"] as! NSDictionary).object(forKey: "minimumrequiredpoints") as? String
                    
                    let highestBid = (result["product"] as! NSDictionary).object(forKey: "highestbidpointsofar") as? String
                    
                    if(requiredPoint  <= highestBid )
                    {
                        self.theRequiredPointLabel.text = String(format:"Highest Bid:  %@", highestBid!)
                    } else {
                        self.theRequiredPointLabel.text = String(format:"Min Required Points Per Bid:  %@", requiredPoint!)
                    }
                    self.updateBidNowButton(result["product"] as? NSDictionary)
                    self.theDescriptionLabel.text = (result["product"] as! NSDictionary).object(forKey: "description") as? String
                })
                
            } else if(result["status"] as! Int == 0) {
                DispatchQueue.main.async(execute: { () -> Void in
                    self.hideProgress()
                    self.displayAlert("Alert Message", message: result["msg"] as! String)
                })
            }
        }
    }
    
    
    func riskyAuctionProductDetail()
    {
        self.showProgress()
        
        let body = String(format:"token=%@&productid=%@", UserDefaults.standard.object(forKey: "token") as! String , productID)
        
        let task = "getriskyauctionproductdetail"
        WebService().sendAPIRequest(UrlClass.baseUrl, body: body,task: task) { ( result, error) -> Void in
            
            if result["status"] as! Int == 1
            {
                
                DispatchQueue.main.async(execute: { () -> Void in
                    
                    self.hideProgress()
                    
                    if((result["product"] as! NSDictionary).object(forKey: "isthisuserhighestbid") as? NSInteger == 1)
                    {
                        self.bidNowButton .setTitle("You are the Highest bidder", for: UIControlState())
                        
                        self.bidNow.setTitleColor(UIColor.orange, for: UIControlState())
                        
                        self.bidNow.backgroundColor = UIColor.clear
                        
                    }
                    
                    self.imageDataArray = result["product"]?["imagepath"] as! NSArray
                    
                    self.theCollectionView.reloadData()
                    
                    self.bidEndDateLabel.text = String(format:"Bid EndDate :  %@",  (result["product"] as! NSDictionary).object(forKey: "bidenddate") as! String)
                    
                    self.theProductTitleLabel.text = (result["product"] as! NSDictionary).object(forKey: "title") as? String
                    
                    let reqiredPouint = String(format:"%@", (result["product"] as! NSDictionary).object(forKey: "minimumrequiredpoints") as! String)
                    
                    var highestBid : String? = ""
                    if let highestBidString = (result["product"] as! NSDictionary).object(forKey: "highestbidpointsofar") as? String {
                        highestBid = highestBidString
                    } else if let highestBidInt = (result["product"] as! NSDictionary).object(forKey: "highestbidpointsofar") as? Int {
                        highestBid = String(highestBidInt)
                    }
                    
                    if(reqiredPouint  <= highestBid )
                    {
                        self.theRequiredPointLabel.text = String(format:"Highest Bid:  %@", highestBid!)
                        
                    }else {
                        self.theRequiredPointLabel.text = String(format:"Min Required Points Per Bid:  %@",reqiredPouint)
                    }
                    self.updateBidNowButton(result["product"] as? NSDictionary)
                    self.theDescriptionLabel.text = (result["product"] as! NSDictionary).object(forKey: "description") as? String
                })
                
            } else if(result["status"] as! Int == 0) {
                DispatchQueue.main.async(execute: { () -> Void in
                    self.hideProgress()
                    self.displayAlert("Alert Message", message: result["msg"] as! String)
                })
            }
        }
    }
    

    
    func salesProductDetail()
    {
        self.showProgress()

        let body = String(format:"token=%@&productid=%@", UserDefaults.standard.object(forKey: "token") as! String , productID)
        
        let task = "getsalesproductdetail"
        WebService().sendAPIRequest(UrlClass.baseUrl, body: body,task: task) { ( result, error) -> Void in
            
            if result["status"] as! Int == 1
            {
                DispatchQueue.main.async(execute: { () -> Void in
                    
                self.hideProgress()
                    
                self.imageDataArray = result["product"]?["imagepath"] as! NSArray
                    
                self.theCollectionView.reloadData()
                
                self.theProductTitleLabel.text = (result["product"] as! NSDictionary).object(forKey: "title") as? String
                
                self.theRequiredPointLabel.text = "Required Points: "+String((result["product"] as! NSDictionary).object(forKey: "requiredpoints") as! String)
                    
                    let temp = String(describing: (result["product"] as! NSDictionary).object(forKey: "availableqty") as! NSNumber)
                    
                    self.thePrizeLabel.text = "Available Quantity: " + temp;
                    
                self.theDescriptionLabel.text = (result["product"] as! NSDictionary).object(forKey: "description") as? String
                    
                self.maxAllowedQuantity = (result["product"] as! NSDictionary).object(forKey: "allowedqty") as? Int
                self.theMaxQuantityLabel.text = "Max Allowed Quantity: "+String(self.maxAllowedQuantity!)
                self.updateBidNowButtonForOpenSales(result["product"] as? NSDictionary)
                })
            } else if(result["status"] as! Int == 0) {
                DispatchQueue.main.async(execute: { () -> Void in
                    self.hideProgress()
                    self.displayAlert("Alert Message", message: result["msg"] as! String)
                })
            }
        }
    }

    func platinumSalesProductDetail()
    {
        self.showProgress()

        let body = String(format:"token=%@&productid=%@&salestype=1", UserDefaults.standard.object(forKey: "token") as! String , productID)
        
        let task = "getrefsalesproductdetail"
        WebService().sendAPIRequest(UrlClass.baseUrl, body: body,task: task) { ( result, error) -> Void in
            
            if result["status"] as! Int == 1
            {
                DispatchQueue.main.async(execute: { () -> Void in
                    
                    self.hideProgress()
                    
                    self.imageDataArray = result["product"]?["imagepath"] as! NSArray
                    
                    self.theCollectionView.reloadData()
                    
                    self.theProductTitleLabel.text = (result["product"] as! NSDictionary).object(forKey: "title") as? String
                    
                    self.theRequiredPointLabel.text = "Required Points:  "+String((result["product"] as! NSDictionary).object(forKey: "requiredpoints") as! String)
                    
                    
                    let temp = String(describing:((result["product"] as! NSDictionary).object(forKey: "availableqty") as! NSNumber))
                    self.thePrizeLabel.text = "Available Quantity:  " + temp
                    
                    self.maxAllowedQuantity = (result["product"] as! NSDictionary).object(forKey: "allowedqty") as? Int
                    self.theMaxQuantityLabel.text = "Max Allowed Quantity:  "+String(self.maxAllowedQuantity!)
                    
                    self.theReferalLabel.text = "Required Referrals:  "+String((result["product"] as! NSDictionary).object(forKey: "requiredreferrals") as! String)
                    
                    self.theDescriptionLabel.text = (result["product"] as! NSDictionary).object(forKey: "description") as? String
                    
                    self.updateBidNowButtonForSales(result["product"] as? NSDictionary)
//                    if(result.objectForKey("product")!.objectForKey("haveenoughreferrals") as? NSNumber == 0)
//                    {
//                        self.bidNowButton.setTitle("REFER NOW", forState: UIControlState.Normal)
//                    } else {
//                        self.bidNowButton.setTitle("BUY NOW", forState: UIControlState.Normal)
//                    }
                    
                })
            }else if(result["status"] as! Int == 0) {
                DispatchQueue.main.async(execute: { () -> Void in
                    self.hideProgress()
                    self.displayAlert("Alert Message", message: result["msg"] as! String)
                })
            }
        }
    }
    
    
    
    func goldSalesProductDetail()
    {
        self.showProgress()

        let body = String(format:"token=%@&productid=%@&salestype=2", UserDefaults.standard.object(forKey: "token") as! String , productID)
        
        let task = "getrefsalesproductdetail"
        WebService().sendAPIRequest(UrlClass.baseUrl, body: body,task: task) { ( result, error) -> Void in
            
            if result["status"] as! Int == 1
            {
                print(result)

                DispatchQueue.main.async(execute: { () -> Void in
                    
                    self.hideProgress()
                    
                    self.imageDataArray = result["product"]?["imagepath"] as! NSArray
                    
                    self.theCollectionView.reloadData()
                    
                    self.theProductTitleLabel.text = (result["product"] as! NSDictionary).object(forKey: "title") as? String
                    
                    self.theRequiredPointLabel.text = "Required Points:  "+String((result["product"] as! NSDictionary).object(forKey: "requiredpoints") as! String)
                    
                    self.thePrizeLabel.text = "Available Quantity:  "+String(describing: (result["product"] as! NSDictionary).object(forKey: "availableqty") as! NSNumber)
                    
                    self.maxAllowedQuantity = (result["product"] as! NSDictionary).object(forKey: "allowedqty") as? Int
                    self.theMaxQuantityLabel.text = "Max Allowed Quantity:  "+String(self.maxAllowedQuantity!)
                    
                    self.theReferalLabel.text = "Required Referrals:  "+String((result["product"] as! NSDictionary).object(forKey: "requiredreferrals") as! String)
                    
                    self.theDescriptionLabel.text = (result["product"] as! NSDictionary).object(forKey: "description") as? String
                    self.updateBidNowButtonForSales(result["product"] as? NSDictionary)
//                    if(result.objectForKey("product")!.objectForKey("haveenoughreferrals") as? NSNumber == 0)
//                    {
//                    self.bidNowButton.setTitle("REFER NOW", forState: UIControlState.Normal)
//                    } else {
//                    self.bidNowButton.setTitle("BUY NOW", forState: UIControlState.Normal)
//                    }
                })
            }else if(result["status"] as! Int == 0) {
                DispatchQueue.main.async(execute: { () -> Void in
                    self.hideProgress()
                    self.displayAlert("Alert Message", message: result["msg"] as! String)
                })
            }
        }
    }
    

    func silverSalesProductDetail()
    {
        self.showProgress()

        let body = String(format:"token=%@&productid=%@&salestype=3", UserDefaults.standard.object(forKey: "token") as! String , productID)
        
        let task = "getrefsalesproductdetail"
        WebService().sendAPIRequest(UrlClass.baseUrl, body: body,task: task) { ( result, error) -> Void in
            
            if result["status"] as! Int == 1
            {
                DispatchQueue.main.async(execute: { () -> Void in
                    self.hideProgress()

                    self.imageDataArray = result["product"]?["imagepath"] as! NSArray
                    
                    self.theCollectionView.reloadData()
                    
                    self.theProductTitleLabel.text = (result["product"] as! NSDictionary).object(forKey: "title") as? String
                    
                    self.theRequiredPointLabel.text = "Required Points:  "+String((result["product"] as! NSDictionary).object(forKey: "requiredpoints") as! String)
                    
                    self.thePrizeLabel.text = "Available Quantity:  "+String(describing: (result["product"] as! NSDictionary).object(forKey: "availableqty") as! NSNumber)
                    
                    self.maxAllowedQuantity = (result["product"] as! NSDictionary).object(forKey: "allowedqty") as? Int
                    self.theMaxQuantityLabel.text = "Max Allowed Quantity:  "+String(self.maxAllowedQuantity!)
                    
                    self.theReferalLabel.text = "Required Referrals:  "+String((result["product"] as! NSDictionary).object(forKey: "requiredreferrals") as! String)
                    
                    self.theDescriptionLabel.text = (result["product"] as! NSDictionary).object(forKey: "description") as? String
                    self.updateBidNowButtonForSales(result["product"] as? NSDictionary)
//                    if(result.objectForKey("product")!.objectForKey("haveenoughreferrals") as? NSNumber == 0)
//                    {
//                        self.bidNowButton.setTitle("REFER NOW", forState: UIControlState.Normal)
//                    } else {
//                        self.bidNowButton.setTitle("BUY NOW", forState: UIControlState.Normal)
//                    }
                })
            } else if(result["status"] as! Int == 0) {
                DispatchQueue.main.async(execute: { () -> Void in
                self.hideProgress()
                self.displayAlert("Alert Message", message: result["msg"] as! String)
                })
            }
        }
    }
    
    

    
    
    
    
    @IBAction func bidNow(_ sender: AnyObject)
    {
        if (sender.titleLabel!!.text == "BID NOW")
        {
            let createAccountErrorAlert = UIAlertView()
            
            createAccountErrorAlert.tag = (sender as! UIButton).tag as Int
            
            createAccountErrorAlert.delegate = self
            
            createAccountErrorAlert.addButton(withTitle: "CANCEL")
            
            if (self.tag == "sweepTakesVC" || self.tag == "premiumSweepStakesVC")
            {
                createAccountErrorAlert.title = "Confirmation to Bid"
                createAccountErrorAlert.message = "Are you sure you want to bid this product?"
                createAccountErrorAlert.addButton(withTitle: "OK")
                createAccountErrorAlert.tag = 2
                createAccountErrorAlert.show()
                
            } else if self.tag == "AuctionVC"
            {
                createAccountErrorAlert.title = "Enter Details"
                createAccountErrorAlert.addButton(withTitle: "SUBMIT")
                createAccountErrorAlert.alertViewStyle = UIAlertViewStyle.plainTextInput
                createAccountErrorAlert.alertViewStyle = UIAlertViewStyle.plainTextInput
                alertTextField = createAccountErrorAlert.textField(at: 0)!
                alertTextField.placeholder = "Enter Points to Bid"
                alertTextField.keyboardType = .numberPad
                createAccountErrorAlert.tag = 1
                createAccountErrorAlert.show()
            } else if self.tag == "riskyVC" {
                createAccountErrorAlert.title = ""
                createAccountErrorAlert.message = "Your bid points will not be returned to you once you bid for this product even when someone else outbids you"
                createAccountErrorAlert.addButton(withTitle: "SUBMIT")
                createAccountErrorAlert.alertViewStyle = UIAlertViewStyle.plainTextInput
                alertTextField = createAccountErrorAlert.textField(at: 0)!
                alertTextField.placeholder = "Enter Points to Bid"
                alertTextField.keyboardType = .numberPad
                createAccountErrorAlert.tag = 1
                createAccountErrorAlert.show()
            }
        }else if(sender.titleLabel!!.text == "BUY NOW")
        {
        self.performSegue(withIdentifier: "buyNow", sender: self)
            
        } else if(sender.titleLabel!!.text == "REFER NOW")
        {
            print("Share")
            self.share()
        } else if(sender.titleLabel!!.text == "EARN MORE POINTS")
        {
            let tabBarController = self.navigationController?.viewControllers[0] as? UITabBarController
            tabBarController?.selectedIndex = 0
            self.navigationController?.popViewController(animated: false)
        }
    }
    
    
    func alertView(_ alertView: UIAlertView, clickedButtonAtIndex buttonIndex: Int)
    {
        if (buttonIndex == 1)
        {
            
            if alertView.tag == 1 {
                let value = Int(self.alertTextField.text!)!
                if let userminrequiredpoint = result!["userminrequiredpoint"] as? Int {
                    if let usermaxusablepoint = result!["usermaxusablepoint"] as? Int {
                        if value < userminrequiredpoint || value > usermaxusablepoint {
                            self.bidNow(bidNowButton)
                            return
                        }
                    }
                }
            }
            if self.tag == "sweepTakesVC"
            {
                self.bidSweepStakeProduct(alertView.tag)
            } else if self.tag == "AuctionVC" {
                self.bidAuctionProduct(alertView.tag)
            } else if self.tag == "riskyVC" {
                self.bidRiskyAuctionProduct(alertView.tag)
            } else if self.tag == "premiumSweepStakesVC" {
                self.bidPremiumSweepStakeProduct(alertView.tag)
            }
        }
    }
    
    
    
    func bidSweepStakeProduct(_ index:NSInteger)
    {
        self.showProgress()
        
        let body = String(format:"token=%@&productid=%@", UserDefaults.standard.object(forKey: "token") as! String , self.productID)
        
        let task = "bidforsweepstakeproduct"
        WebService().sendAPIRequest(UrlClass.baseUrl, body: body,task: task) { (result, error) -> Void in
            
            if result["status"] as! Int == 1
            {
            DispatchQueue.main.async(execute: { () -> Void in
            self.hideProgress()
            self.displayAlert("Alert Message", message: (result["msg"] as? String)!)
            })
                
            } else  if result["status"] as! Int == 0
            {
            DispatchQueue.main.async(execute: { () -> Void in
            self.hideProgress()
            self.displayAlert("Alert Message", message: (result["msg"] as? String)!)
            })
            }
        }
    }

    
    func bidPremiumSweepStakeProduct(_ index:NSInteger)
    {
        self.showProgress()
        
        let body = String(format:"token=%@&productid=%@", UserDefaults.standard.object(forKey: "token") as! String , self.productID)
        
        let task = "bidforpremiumsweepstakeproduct"
        WebService().sendAPIRequest(UrlClass.baseUrl, body: body,task: task) { (result, error) -> Void in
            
            if result["status"] as! Int == 1
            {
                DispatchQueue.main.async(execute: { () -> Void in
                    self.hideProgress()
                    self.displayAlert("Alert Message", message: (result["msg"] as? String)!)
                })
                
            } else  if result["status"] as! Int == 0
            {
                DispatchQueue.main.async(execute: { () -> Void in
                    self.hideProgress()
                    self.displayAlert("Alert Message", message: (result["msg"] as? String)!)
                })
            }
        }
    }

    
    func bidAuctionProduct(_ index:NSInteger)
    {
        self.showProgress()

        let body = String(format:"token=%@&productid=%@&points=%@", UserDefaults.standard.object(forKey: "token") as! String , self.productID, self.alertTextField.text!)
        
        let task = "bidforauctionproduct"
        WebService().sendAPIRequest(UrlClass.baseUrl, body: body,task: task) { (result, error) -> Void in
            
            if result["status"] as! Int == 1
            {
            DispatchQueue.main.async(execute: { () -> Void in
            self.hideProgress()
            self.displayAlert("Alert Message", message: (result["msg"] as? String)!)
            })
            } else  if result["status"] as! Int == 0
            {
            DispatchQueue.main.async(execute: { () -> Void in
            self.hideProgress()
            self.displayAlert("Alert Message", message: (result["msg"] as? String)!)
            })
            }
        }
    }
    
    
    
    func bidRiskyAuctionProduct(_ index:NSInteger)
    {
        self.showProgress()
        
        let body = String(format:"token=%@&productid=%@&points=%@", UserDefaults.standard.object(forKey: "token") as! String , self.productID, self.alertTextField.text!)
        
        let task = "bidforriskyauctionproduct"
        WebService().sendAPIRequest(UrlClass.baseUrl, body: body,task: task) { (result, error) -> Void in
            
            if result["status"] as! Int == 1
            {
                DispatchQueue.main.async(execute: { () -> Void in
                    self.hideProgress()
                    self.displayAlert("Alert Message", message: (result["msg"] as? String)!)
                })
            } else  if result["status"] as! Int == 0
            {
                DispatchQueue.main.async(execute: { () -> Void in
                    self.hideProgress()
                    self.displayAlert("Alert Message", message: (result["msg"] as? String)!)
                })
            }
        }
    }
    
    
    
//    func displayAlert(title: String, message: String)
//    {
//        let alertController = UIAlertController(title: title, message: message, preferredStyle: .Alert)
//        alertController.addAction(UIAlertAction(title: "OK", style: .Default, handler: nil))
//        presentViewController(alertController, animated: true, completion: nil)
//        return
//    }
    
    
    @IBAction func back(_ sender: AnyObject) {
        
        self.navigationController?.popViewController(animated: true)
    }
    
    
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        
        let destinationView = segue.destination as! buyNowVC
        destinationView.productID = self.productID
        
        destinationView.allowedQty = self.maxAllowedQuantity
        if(self.tag == "salesVC")
        {
            destinationView.tagID = "1"
        } else {
            destinationView.tagID = "2"
        }
    }
    
    
    func share()
    {
        self.showProgress()
        let body = String(format:"token=%@", UserDefaults.standard.object(forKey: "token") as! String)
        
        let task = "sharemyreferrallink"
        WebService().sendAPIRequest(UrlClass.baseUrl, body: body,task: task) { (result, error) -> Void in
            
            if result["status"] as! Int == 1
            {
                DispatchQueue.main.async(execute: { () -> Void in
                    self.hideProgress()
                    self.displayShareSheet(result["url"] as! String)
                })
            } else if result["status"] as! Int == 0
            {
                DispatchQueue.main.async(execute: { () -> Void in
                    self.hideProgress()
                    self.displayAlert("Alert Message", message: result["msg"] as! String)
                })
            }
            
        }
    }
    
    
    func displayShareSheet(_ shareContent:String) {
        let activityViewController = UIActivityViewController(activityItems: [shareContent as NSString], applicationActivities: nil)
        present(activityViewController, animated: true, completion: {})
    }



    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
