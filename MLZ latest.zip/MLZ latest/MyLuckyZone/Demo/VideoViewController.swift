//
//  VideoViewController.swift
//  MyLuckyZone
//
//  Created by TechnoTackle on 28/12/16.
//  Copyright © 2016 Adodis. All rights reserved.
//

import UIKit
import MediaPlayer


class VideoViewController: UIViewController {

    var moviePlayer:MPMoviePlayerController!
    
    @IBOutlet weak var playerView: UIView!
    
   
    override func viewDidLoad() {
        super.viewDidLoad()
        self.loadData()
                // Do any additional setup after loading the view.
    }

    @IBAction func playVideoClick(_ sender: Any) {
        self.loadData()
    }
    
    func loadData()
    {
        
        if Reachability.isConnectedToNetwork() == true {
            self.showProgress()
            
            let body = String(format:"token=%@", UserDefaults.standard.object(forKey: "token") as! String)
            
            let task = "demovideo"
            WebService().sendAPIRequest(UrlClass.baseUrl, body: body,task: task) { (result, error) -> Void in
                
                if result["status"] as! Int == 1
                {
                    
                    //DispatchQueue.main.
                    
                    DispatchQueue.main.async {
                        self.hideProgress()
                        let screenSize: CGRect = UIScreen.main.bounds
                        let screenWidth = screenSize.width
                        let screenHeight = screenSize.height
                        var value = UrlClass.videoURL
                        value.append(result["path"] as! String)
                        //value = "http://dev.myluckyzone.com/images/video/MyLuckyZone_FinalCut.mp4"
                        let url:NSURL = NSURL(string: value)!
                        
                        self.moviePlayer = MPMoviePlayerController(contentURL: url as URL!)
                        //self.moviePlayer.view.frame = CGRect(x: 0, y: screenHeight/2, width: screenWidth, height: 150)
                        
                        self.view.addSubview(self.moviePlayer.view)
                        self.moviePlayer.isFullscreen = true
                        
                        self.moviePlayer.controlStyle = MPMovieControlStyle.embedded

                    }
    
                    
                } else if result["status"] as! Int == 0 || result["status"] as! Int == -1
                {
                    DispatchQueue.main.async(execute: { () -> Void in
                        self.hideProgress()
                        self.displayAlert("Alert Message", message: result["msg"] as! String)
                    })
                }
                
            }
        }else{
             self.displayAlert("Alert Message", message: "No Connectivity")
            print("Nothing stored in NSUserDefaults yet. Set a value.")
        }
    }

    
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillAppear(animated)
        moviePlayer.stop()
    }

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
