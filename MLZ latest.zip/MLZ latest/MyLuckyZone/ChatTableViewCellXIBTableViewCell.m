//
//  ChatTableViewCellXIBTableViewCell.m
//  VP Chat
//
//  Created by TechnoTackle on 11/04/17.
//  Copyright © 2017 TechnoTackle. All rights reserved.
//

#import "ChatTableViewCellXIBTableViewCell.h"

@implementation ChatTableViewCellXIBTableViewCell

@synthesize chatUserImage;
@synthesize chatMessageLabel;
@synthesize chatNameLabel;
@synthesize chatTimeLabel;


@end
