//
//  ForumPrimTableViewCell.swift
//  MyLuckyZone
//
//  Created by TechnoTackle on 29/12/16.
//  Copyright © 2016 Adodis. All rights reserved.
//

import UIKit

class ForumPrimTableViewCell: UITableViewCell {
    
    @IBOutlet weak var answersMainCount: UILabel!
    @IBOutlet weak var answerContent: UILabel!
    @IBOutlet weak var titleLbl: UILabel!
    @IBOutlet weak var answerCountLbl: UILabel!
    @IBOutlet weak var userNameLbl: UILabel!
    @IBOutlet weak var dateLbl: UILabel!
    @IBOutlet weak var commentTxt: UITextField!
    @IBOutlet weak var postBtn: UIButton!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }
    

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
