//
//  WebViewController.swift
//  MyLuckyZone
//
//  Created by Prabhu Swaminathan on 11/08/16.
//  Copyright © 2016 Adodis. All rights reserved.
//

import UIKit
import Foundation
fileprivate func < <T : Comparable>(lhs: T?, rhs: T?) -> Bool {
  switch (lhs, rhs) {
  case let (l?, r?):
    return l < r
  case (nil, _?):
    return true
  default:
    return false
  }
}

fileprivate func > <T : Comparable>(lhs: T?, rhs: T?) -> Bool {
  switch (lhs, rhs) {
  case let (l?, r?):
    return l > r
  default:
    return rhs < lhs
  }
}


class WebViewController : UIViewController {
    @IBOutlet var webView: UIWebView!
    var htmlString : String?
    var url : String?
    
    @IBOutlet var titleLabel: UILabel!
    @IBAction func backNavigation(_ sender: AnyObject) {
        self.dismiss(animated: true, completion: nil)
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        if url?.characters.count > 0 {
            webView.loadRequest(URLRequest(url: URL(string: url!)!))
        } else if htmlString?.characters.count > 0 {
            webView.loadHTMLString(htmlString!, baseURL: nil);
        }
        titleLabel.text = self.title
    }
}
