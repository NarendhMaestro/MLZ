//
//  AttachemenTask.h
//  MyLuckyZone
//
//  Created by Maestro_MAC1 on 17/06/17.
//  Copyright © 2017 Adodis. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "AFNetworking.h"
#import "ChatTableViewCellXIBTableViewCell.h"

@interface AttachemenTask : NSObject

@end
