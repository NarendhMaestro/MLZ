//
//  rawCasterLoginVC.swift
//  MyLuckyZone
//
//  Created by Maestro_MAC1 on 11/05/17.
//  Copyright © 2017 Adodis. All rights reserved.
//

import UIKit

class rawCasterLoginVC: UIViewController {

    @IBOutlet weak var theScrollView: UIScrollView!
    
    @IBOutlet var thePasswordTextField: UITextField!
    
    @IBOutlet var privacyLabel: UILabel!
    var activeTextField = UITextField()
    var versionverified = 1
    
    var handler : ((UIAlertAction) -> Void)?
    var message : String!
    
    @IBOutlet var theUserNameTextField: UITextField!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
        
        
       // self.theScrollView.contentSize = CGSize(width:self.view.frame.size.width, height:1000)
        
        
        NotificationCenter.default.addObserver(self, selector: #selector(LoginVC.keyboardWasShown(_:)), name: NSNotification.Name.UIKeyboardWillShow, object: nil)
        
        NotificationCenter.default.addObserver(self, selector: #selector(LoginVC.keyboardWillBeHidden(_:)), name: NSNotification.Name.UIKeyboardWillHide, object: nil)
        
        let tapGesture = UITapGestureRecognizer()
        tapGesture.addTarget(self, action: #selector(LoginVC.Register))
       // self.theBottomView.addGestureRecognizer(tapGesture)
        
        let version = Bundle.main.infoDictionary?["CFBundleShortVersionString"] as! String
        
        
       // self.privacyLabel.text = "By downloading and using this app (v\(version)), you agree to the policy, privacy terms and conditions of use specified by www.myluckyzone.com"
        let text = "By downloading and using this app (v\(version)), you agree to the policy, privacy terms and conditions of use specified by www.myluckyzone.com"
        let nsText = text as NSString
        let attributedString = NSMutableAttributedString(string: text)
         attributedString.addAttribute(NSForegroundColorAttributeName, value: UIColor.init(colorLiteralRed: 252.0/255.0, green: 85.0/255.0, blue: 11.0/255.0, alpha: 1.0), range: NSMakeRange(nsText.length - 19, 19))//252 85 11
        self.privacyLabel.attributedText = attributedString
        print(attributedString)
        
        
        showProgress();
        self.handler =  {(UIAlertAction) -> Void in
            let bundleID = Bundle.main.bundleIdentifier?.lowercased()
            let url : String?
            let range = bundleID?.range(of: "usa")
            if range != nil {
                url = "https://itunes.apple.com/us/app/myluckyzone-usa/id1124300983?ls=1&mt=8"
            } else {
                url = "https://itunes.apple.com/us/app/myluckyzone-nigeria/id1133993562?ls=1&mt=8"
            }
            //UIApplication.shared.openURL(URL(string: url!)!)
            if self.message != nil {
                self.displayAlert("Alert Message", message: self.message, handler:self.handler)
            }
        }
        
        self.hideProgress()
//        WebService.sharedInstance.checkDevice( { (result: [String : AnyObject], error: AnyObject?)-> Void in
//            DispatchQueue.main.async {
//                self.hideProgress()
//                if error == nil {
//                    self.message = nil
//                    let status : Int? = result["status"] as? Int
//                    if status == 1 {
//                        let username = result["username"] as? String
//                        if username != nil {
//                            self.theUserNameTextField.text = username
//                            self.theUserNameTextField.isEnabled = false
//                           // self.signInDifferentUser.isHidden = false
//                            self.hideProgress()
//                            return
//                        }
//                    } else if status == 3 || status == 0 {
//                        self.versionverified = 0
//                        if status == 3 {
//                            self.message = result["msg"] as! String
//                        }
//                        self.displayAlert("Alert Message", message: result["msg"] as! String, handler:self.handler)
//                    } else if status == 2 {
////                        self.forgotPasswordBottomConstraint.constant = 44
////                        self.theBottomView.isHidden = false
//                    }
//                    self.theUserNameTextField.isEnabled = true
//                   // self.signInDifferentUser.isHidden = true
//                } else {
//                    self.displayAlert("Alert", message: error as! String)
//                }
//            }
//        });
    }
    
    @IBAction func back(_ sender: AnyObject) {
        self.dismiss(animated: true, completion: nil)
    }
    
       @IBAction func loginWithRawcaster(_ sender: AnyObject) {
        
        if Reachability.isConnectedToNetwork() == true {
            if (self.theUserNameTextField.text == "" || self.thePasswordTextField.text == "" )
            {
                
            }else
            {
//                let bundleID = Bundle.main.bundleIdentifier?.lowercased()
//                let url : String?
//                let range = bundleID?.range(of: "usa")
//                var n = 11
//                if range != nil//usa
//                {
//                  n = 10
//                }
//                //Check is valid mobile number
//                if (self.theUserNameTextField.text?.characters.count) != n
//                {
//                    displayAlert("Alert Message", message: "Please Enter EmailId and Password")
//                    return
//                }
                self.showProgress()
              //  let Raw_Code:String = String(format:"%@%@%@",WebService().getSALT,WebService.sharedInstance.getDeviceUUID()!,self.theUserNameTextField.text!)
                //let body = String(format:"username=%@&password=%@&devicetype=%d&deviceid=%@&authcode=%@&versionverified=\(self.versionverified)",self.theUserNameTextField.text!,self.thePasswordTextField.text!, WebService.sharedInstance.DEVICE_TYPE_IOS, WebService.sharedInstance.getDeviceUUID()!,AUTH_CODE)
                
                
                print(self.versionverified)
                
                var body = String(format:"username=%@&password=%@&devicetype=%d&deviceid=%@&versionverified=1",self.theUserNameTextField.text!,self.thePasswordTextField.text!, WebService.sharedInstance.DEVICE_TYPE_IOS, WebService.sharedInstance.getDeviceUUID()!)
                body = body.appending(String(format:"&apnsid=%@", UserDefaults.standard.string(forKey: "APNSID")!))
                
                
                let task = "rawcasterlogin"
                WebService().sendAPIRequest(UrlClass.baseUrl, body: body,task: task) { (result, error) -> Void in
                    
                    if(result.count>0){
                        
                        if result["status"] as! Int == 1
                        {
                            UserDefaults.standard.set(result["token"], forKey: "token")
                            
                            //saving user name for chat
                            UserDefaults.standard.set(self.theUserNameTextField.text!, forKey: "userName")
                            
                            WebService.sharedInstance.getProfile(nil);
                            DispatchQueue.main.async(execute: { () -> Void in
                                self.hideProgress()
                                self.performSegue(withIdentifier: "login", sender: self)
                            })
                            
                        }else if result["status"] as! Int == 2
                        {
                            DispatchQueue.main.async(execute: { () -> Void in
                                UserDefaults.standard.set(result["reftmpid"], forKey: "reftmpid")
                                self.performSegue(withIdentifier: "RCRegister", sender: self)
                                
                                
                                
                                
//                                //Creating new account
//                                let body2 = String(format:"reftmpid=%@&mbleNumbr=%@&devicetype=%d&deviceid=%@&apnsid=%@&versionverified=\(self.versionverified)", result["reftmpid"] as! NSString, self.theUserNameTextField.text! ,WebService.sharedInstance.DEVICE_TYPE_IOS,  WebService.sharedInstance.getDeviceUUID()! )
//                                let task2 = "createuserfromrawcaster"
//                                
//                                WebService().sendAPIRequest(UrlClass.baseUrl, body: body2,task: task2) { (result, error) -> Void in
//                                    UserDefaults.standard.set(result["token"], forKey: "token")
//                                    //saving user name for chat
//                                    UserDefaults.standard.set(self.theUserNameTextField.text!, forKey: "userName")
//                                    WebService.sharedInstance.getProfile(nil);
//                                    DispatchQueue.main.async(execute: { () -> Void in
//                                        self.hideProgress()
//                                        self.performSegue(withIdentifier: "login", sender: self)
//                                    })
//                                }
                                
                            })
                        }
                        else if result["status"] as! Int == 0
                        {
                            DispatchQueue.main.async(execute: { () -> Void in
                                self.hideProgress()
                                self.displayAlert("Alert Message", message: result["msg"] as! String, handler: self.handler)
                            })
                        }
                        
                    }
                    else{
                        self.displayAlert("Alert Message", message: "Please Check Internet connection")
                        self.hideProgress()
                        
                    }
                }
            }
            
            
            
        } else {
            self.displayAlert("Alert Message", message: "Please Check Internet connection")
            
        }
        
    }
    
    
    
    //        func displayAlert(title: String, message: String) {
    //            let alertController = UIAlertController(title: title, message: message, preferredStyle: .Alert)
    //            alertController.addAction(UIAlertAction(title: "OK", style: .Default, handler: nil))
    //            presentViewController(alertController, animated: true, completion: nil)
    //        }
    
    
    
    func keyboardWasShown(_ notification: Notification) {
        // Step 1: Get the size of the keyboard.
        let info : NSDictionary = (notification as NSNotification).userInfo! as NSDictionary
        let keyboardSize = (info[UIKeyboardFrameBeginUserInfoKey] as? NSValue)?.cgRectValue
        if(keyboardSize != nil) {
            // Step 2: Adjust the bottom content inset of your scroll view by the keyboard height.
            let contentInsets: UIEdgeInsets = UIEdgeInsetsMake(0.0, 0.0, keyboardSize!.height, 0.0)
           // self.theScrollView.contentInset = contentInsets
           // self.theScrollView.scrollIndicatorInsets = contentInsets
            // Step 3: Scroll the target text field into view.
            var aRect: CGRect = self.view.frame
            aRect.size.height -= keyboardSize!.height
            if !aRect.contains(activeTextField.frame.origin)
            {
                let scrollPoint: CGPoint = CGPoint(x: 0.0, y: activeTextField.frame.origin.y - (keyboardSize!.height - 15))
               // self.theScrollView.setContentOffset(scrollPoint, animated: true)
            }
        }
    }
    
    func keyboardWillBeHidden(_ notification: Notification) {
        let contentInsets: UIEdgeInsets = UIEdgeInsets.zero
       // self.theScrollView.contentInset = contentInsets
        //self.theScrollView.scrollIndicatorInsets = contentInsets
    }
    
    
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool
    {
        return textField.resignFirstResponder()
    }
    
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    override func viewWillDisappear(_ animated: Bool)
    {
        NotificationCenter.default.removeObserver(self, name: NSNotification.Name.UIKeyboardDidHide, object: nil)
        NotificationCenter.default.removeObserver(self, name: NSNotification.Name.UIKeyboardWillHide, object: nil)
    }
    
    
    
    func Register()
    {
        self.performSegue(withIdentifier: "register", sender: self)
    }
    
    
    
    
    @IBAction func registerButton(_ sender: AnyObject) {
        Register()
    }
    
 
}
