//
//  AddorEditViewController.swift
//  MyLuckyZone
//
//  Created by TechnoTackle on 28/12/16.
//  Copyright © 2016 Adodis. All rights reserved.
//

import UIKit

class AddorEditViewController: UIViewController {
    
    var TYPE:String?
    var Field1:String?
    var Field2:String?
    var selectedId:String?
    
   // @IBOutlet weak var descTxt: UITextField!
    @IBOutlet weak var descText: UITextView!
    @IBOutlet weak var titleTxt: UITextField!
    @IBOutlet weak var titleLbl: UILabel!
    override func viewDidLoad() {
        super.viewDidLoad()
        
        
        descText.layer.borderColor = UIColor.black.cgColor.copy(alpha: 0.5);
        descText.layer.borderWidth = 1.0;
        descText.layer.cornerRadius = 5.0;
        
        self.titleLbl.text = TYPE!
        self.titleTxt.text = Field1!
        self.descText.text = Field2!
        
        //self.titleTxt.delegate = self
        //self.descTxt.delegate = self
        // Do any additional setup after loading the view.
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    func textFieldShouldReturn(textField: UITextField!) -> Bool {   //delegate method
        view.endEditing(true)
        return true
    }
    @IBAction func submitBtnClick(_ sender: Any) {
        view.endEditing(true)
        
        var msg = ""
        
        if(self.titleTxt.text!.characters.count==0)
        {
            msg.append("Required Title")
        }
        if(self.titleTxt.text!.characters.count==0)
        {
            msg.append("\nRequired Description")
        }
        
        if(msg.characters.count==0){
            
            if(titleLbl.text == "Edit Your Answer"){//edit thread
                
                if Reachability.isConnectedToNetwork() == true {
                    self.showProgress()
                    
                    let body = String(format:"token=%@&threadid=%@&title=%@&description=%@", UserDefaults.standard.object(forKey: "token") as! String,selectedId!,self.titleTxt.text!,self.descText.text!)
                    
                    let task = "updatethread"
                    WebService().sendAPIRequest(UrlClass.baseUrl, body: body,task: task) { (result, error) -> Void in
                        
                        if result["status"] as! Int == 1
                        {
                            
                            
                            DispatchQueue.main.async(execute: { () -> Void in
                                
                                self.hideProgress()
                                //                        self.tableView .reloadData()
                                //self.displayAlert("Alert Message", message: result["msg"] as! String)
                                let alertController = UIAlertController(title: "Alert Message", message: result["msg"] as! String, preferredStyle: .alert)
                                
                                // Create the actions
                                let okAction = UIAlertAction(title: "OK", style: UIAlertActionStyle.default) {
                                    UIAlertAction in
                                    DispatchQueue.main.async(execute: { () -> Void in
                                       // self.navigationController?.popToRootViewController(animated: true)
                                        self.navigationController?.popViewController(animated: true)
                                    })
                                }
                                
                                alertController.addAction(okAction)
                                //alertController.addAction(cancelAction)
                                
                                // Present the controller
                                self.present(alertController, animated: true, completion: nil)

                            })
                            
                        } else if result["status"] as! Int == 0 || result["status"] as! Int == -1
                        {
                            DispatchQueue.main.async(execute: { () -> Void in
                                self.hideProgress()
                                self.displayAlert("Alert Message", message: result["msg"] as! String)
                                
                            
                        })
                        }
                        
                    }
                }else{
                    
                    print("Nothing stored in NSUserDefaults yet. Set a value.")
                }
            }else{//posting new thread
                if Reachability.isConnectedToNetwork() == true {
                    self.showProgress()
                    
                    let body = String(format:"token=%@&title=%@&description=%@", UserDefaults.standard.object(forKey: "token") as! String,self.titleTxt.text!,self.descText.text!)
                    
                    let task = "postthread"
                    WebService().sendAPIRequest(UrlClass.baseUrl, body: body,task: task) { (result, error) -> Void in
                        
                        if result["status"] as! Int == 1
                        {
                            
                            
                            DispatchQueue.main.async(execute: { () -> Void in
                                self.titleTxt.text = ""
                                self.descText.text = ""
                                self.hideProgress()
                                //                        self.tableView .reloadData()
                                //self.displayAlert("Alert Message", message: result["msg"] as! String)
                                let alertController = UIAlertController(title: "Alert Message", message: result["msg"] as! String, preferredStyle: .alert)
                                
                                // Create the actions
                                let okAction = UIAlertAction(title: "OK", style: UIAlertActionStyle.default) {
                                    UIAlertAction in
                                    DispatchQueue.main.async(execute: { () -> Void in
                                        // self.navigationController?.popToRootViewController(animated: true)
                                        self.navigationController?.popViewController(animated: true)
                                    })
                                }
                                
                                alertController.addAction(okAction)
                                //alertController.addAction(cancelAction)
                                
                                // Present the controller
                                self.present(alertController, animated: true, completion: nil)
                            })
                            
                        } else if result["status"] as! Int == 0 || result["status"] as! Int == -1
                        {
                            DispatchQueue.main.async(execute: { () -> Void in
                                self.hideProgress()
                                self.displayAlert("Alert Message", message: result["msg"] as! String)
                            })
                        }
                        
                    }
                }else{
                    
                    print("Nothing stored in NSUserDefaults yet. Set a value.")
                }
            }
        }else{
            self.displayAlert("Alert Message", message: msg)
        }
    }
    
    /*
     // MARK: - Navigation
     
     // In a storyboard-based application, you will often want to do a little preparation before navigation
     override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
     // Get the new view controller using segue.destinationViewController.
     // Pass the selected object to the new view controller.
     }
     */
    
}
