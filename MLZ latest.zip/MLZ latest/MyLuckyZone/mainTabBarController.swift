//
//  mainTabBarController.swift
//  MyLuckyZone
//
//  Created by G.Abhisek on 18/05/16.
//  Copyright © 2016 Adodis. All rights reserved.
//

import UIKit
import SWRevealViewController

class mainTabBarController: UITabBarController,SWRevealViewControllerDelegate,UITabBarControllerDelegate
{
    @IBOutlet weak var leftMenuButton: UIBarButtonItem!
    
    @IBOutlet weak var rightMenuButton: UIBarButtonItem!
    
    @IBOutlet weak var mainTabBar: UITabBar!

    @IBOutlet var titleLabel: UILabel!
    
    override func viewDidLoad()
    {
        super.viewDidLoad()
        self.delegate = self
        leftMenuButton.target = self.revealViewController()
        leftMenuButton.action = #selector(SWRevealViewController.revealToggle(_:))
        self.revealViewController().delegate = self
        
        mainTabBar.tintColor = UIColor.black
        self.view.addGestureRecognizer(self.revealViewController().panGestureRecognizer())
        
        if self.revealViewController() != nil
        {
            self.view.addGestureRecognizer(self.revealViewController().panGestureRecognizer())
            self.view.addGestureRecognizer(self.revealViewController().tapGestureRecognizer())
            self.navigationController?.view.addGestureRecognizer(self.revealViewController().panGestureRecognizer())
        }
        // Do any additional setup after loading the view.
        if let selectedIndexRtrvd = UserDefaults.standard.object(forKey: "tabBarSelectedIndex")
        {
            self.selectedIndex = selectedIndexRtrvd as! Int

        }
        else
        {
            self.selectedIndex = 1
        }
        
        let version = Bundle.main.infoDictionary?["CFBundleShortVersionString"] as! String
        let bundleID = Bundle.main.bundleIdentifier?.lowercased()
        var appName : String?
        var range = bundleID?.range(of: "usa")
        if range != nil {
            appName = "USA"
        } else {
            range = bundleID?.range(of: "ngr")
            if range != nil {
                appName = "Nigeria"
            } else {
                appName = ""
            }
        }
        
        titleLabel.text = "MyLuckyZone \(appName!)(v\(version))"
        
    }
   

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
    //used to create a mask view when the rear view appears.
    func revealController(_ revealController: SWRevealViewController!, willMoveTo position: FrontViewPosition)
    {
        let tagId = 4207868
        
        if revealController.frontViewPosition == FrontViewPosition.right
        {
            let lock = self.view.viewWithTag(tagId)
            UIView.animate(withDuration: 0.25, animations:
                {
                    lock?.alpha = 0
                }, completion: {(finished: Bool) in
                    lock?.removeFromSuperview()
                }
            )
            lock?.removeFromSuperview()
        }
        else if revealController.frontViewPosition == FrontViewPosition.left
        {
            let lock = UIView(frame: self.view.bounds)
            lock.autoresizingMask = [.flexibleWidth, .flexibleHeight]
            lock.tag = tagId
            lock.alpha = 0
            lock.backgroundColor = UIColor.black
            lock.addGestureRecognizer(UITapGestureRecognizer(target: self.revealViewController(), action: #selector(SWRevealViewController.revealToggle(_:))))
            lock.addGestureRecognizer(self.revealViewController().panGestureRecognizer())
            self.view.addSubview(lock)
            UIView.animate(withDuration: 0.75, animations: {
                lock.alpha = 0.333
                }
            )
        }
    }

    
    // UITabBarControllerDelegate
    func tabBarController(_ tabBarController: UITabBarController, didSelect viewController: UIViewController)
    {
        UserDefaults.standard.set(tabBarController.selectedIndex, forKey: "tabBarSelectedIndex")
        //add notification to post tab item select
        NotificationCenter.default.post(name: Notification.Name(rawValue: "RemoveSideMenuView"), object: nil)
    }
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
