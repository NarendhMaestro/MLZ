//
//  WebService.swift
//  JSONwebService
//
//  Created by G.Abhisek on 21/03/16.
//  Copyright © 2016 Adodis. All rights reserved.
//

import UIKit
import MBProgressHUD
import Security
//import CommonCrypto
//import CommonCrypto/CommonDigest.h
//#import <CommonCrypto/CommonCrypto.h>
class WebService: NSObject
{
    let DEVICE_TYPE_IOS  = 2
    static let sharedInstance : WebService = WebService();
    var _baseURL : String! = nil
    var _SALT : String! = nil
    
    func getDeviceUUID() -> String? {
        let keychain = Keychain()
        var deviceId = keychain["deviceId"] // Get string
        if deviceId == nil {
            deviceId = UUID().uuidString
            keychain["deviceId"] = deviceId
        }
        return deviceId
    }
    
    func deviceUserChangeRequest(_ message : String, callback : @escaping ([String:AnyObject], AnyObject?) -> ()) {
        let uuid = self.getDeviceUUID()
        let body = "deviceid=\(uuid!)&devicetype=\(DEVICE_TYPE_IOS)&message=\(message)"
        let task = "deviceuserchangerequest"
        sendAPIRequest(UrlClass.baseUrl, body: body, task: task, completion: callback)
    }
    
    func getReferralCount(_ callback : @escaping ([String:AnyObject], AnyObject?) -> ()) {
        let token = (UIApplication.shared.delegate as! AppDelegate).getLoginToken()
        let body = "token=\(token!)"
        let task = "getuserreferralcount"
        sendAPIRequest(UrlClass.baseUrl, body: body, task: task, completion: callback)
    }
    
    func checkDevice(_ callback : @escaping ([String:AnyObject], AnyObject?) -> ()) {
        let uuid = self.getDeviceUUID()
        let version = Bundle.main.infoDictionary?["CFBundleShortVersionString"] as! String
        let Raw_Code:String = String(format:"%@%@",WebService().getSALT,uuid!)
        let AUTH_CODE:String = WebService().SHA1(Raw_Code)
        //let AUTH_CODE = String(format:"%@",)
        let body = "deviceid=\(uuid!)&versionnumber=\(version)&devicetype=2&authcode=\(AUTH_CODE)"
        let task = "checkdevice"
        sendAPIRequest(UrlClass.baseUrl, body: body, task: task, completion: callback)
    }
    
    func getUserPoints(_ callback : @escaping ([String:AnyObject], AnyObject?) -> ())
    {
        let body = String(format:"token=%@", UserDefaults.standard.object(forKey: "token") as! String)
        let task = "getuserpoints"
        sendAPIRequest(UrlClass.baseUrl, body: body,task: task, completion: callback)
    }
    
    func getPremiumSweepStakes(_ callback : @escaping ([String:AnyObject], AnyObject?) -> ()) {
        let body = String(format:"token=%@", UserDefaults.standard.object(forKey: "token") as! String)
        let task = "userpremiumsweepstakestatus"
        sendAPIRequest(UrlClass.baseUrl, body: body,task: task, completion: callback)
    }

    func getPremiumSweepStakesList(_ pageNumber: Int, productCategory : NSString, callback : @escaping ([String:AnyObject], AnyObject?) -> ()) {
        let body = String(format:"token=%@&pagenumer=%@&salestype=1&searchkey=%@", UserDefaults.standard.object(forKey: "token") as! String,String(pageNumber), productCategory)
        let task = "listallpremiumsweepstakeproducts"
        sendAPIRequest(UrlClass.baseUrl, body: body,task: task, completion: callback)
    }
    
    func getPremiumSweepStakesProductDetail(_ productID : NSString, callback : @escaping ([String:AnyObject], AnyObject?) -> ()) {
        let body = String(format:"token=%@&productid=%@", UserDefaults.standard.object(forKey: "token") as! String , productID)
        let task = "getpremiumsweepstakeproductdetail"
        sendAPIRequest(UrlClass.baseUrl, body: body,task: task, completion: callback)
    }

    func getReferralMessage(_ callback : @escaping ([String:AnyObject], AnyObject?) -> ()) {
        let body = ""
        let task = "referraltextmsg"
        sendAPIRequest(UrlClass.baseUrl, body: body, task: task, completion: callback)
    }
    
    func trackBrowsingTime(_ body : String) {
        let task = "trackbrowsingtime"
        WebService().sendAPIRequest(UrlClass.baseUrl, body: body, task: task) { (result, error) -> Void in
            if result["status"] as! Int == 1
            {
                print("Updated Browsing Time")
            }
        }
    }
    
    
    
    func getRiskyAuctionProductList(_ pageNumber: Int, productCategory : NSString, callback : @escaping ([String: AnyObject], AnyObject?) -> ()) {
        let body = String(format:"token=%@&pagenumer=%@&salestype=1&searchkey=%@", UserDefaults.standard.object(forKey: "token") as! String,String(pageNumber), productCategory)
        let task = "listallriskyauctionproducts"
        sendAPIRequest(UrlClass.baseUrl, body: body,task: task, completion: callback)
    }
    
    func getRiskyAuctionProductDetail(_ productID : NSString, callback : @escaping ([String : AnyObject], AnyObject?) -> ()) {
        let body = String(format:"token=%@&productid=%@", UserDefaults.standard.object(forKey: "token") as! String , productID)
        let task = "getriskyauctionproductdetail"
        sendAPIRequest(UrlClass.baseUrl, body: body,task: task, completion: callback)
    }
    
//    func getPremiumSweepStakes(callback : (NSMutableDictionary, AnyObject?) -> ()) {
//        let body = String(format:"token=%@", NSUserDefaults.standardUserDefaults().objectForKey("token") as! String)
//        let task = "userpremiumsweepstakestatus"
//        sendAPIRequest(UrlClass.baseUrl, body: body,task: task, completion: callback)
//    }

    
    
    
    
    func getProfile(_ callback : (([String:AnyObject], AnyObject?) -> ())?) {
        let body = String(format:"token=%@", UserDefaults.standard.object(forKey: "token") as! String)
        let task = "getmyprofile"
        if(callback == nil) {
            WebService().sendAPIRequest(UrlClass.baseUrl, body: body,task: task, completion: {(result, error) -> () in
                do {
                    let data = try JSONSerialization.data(withJSONObject: result, options: JSONSerialization.WritingOptions.prettyPrinted)
                        if let json = NSString(data: data, encoding: String.Encoding.utf8.rawValue) {
                            UserDefaults.standard.setValue(json, forKey: "profile")
                        }
                } catch _ {
                    
                }
            })
        } else {
            WebService().sendAPIRequest(UrlClass.baseUrl, body: body,task: task, completion: callback!)
        }
    }
    
    func getProfile() -> [String:AnyObject]? {
        let profileString = UserDefaults.standard.object(forKey: "profile") as? String
        if(profileString != nil) {
            return convertStringToDictionary(profileString!)
        }
        return nil
    }

    func convertStringToDictionary(_ text: String) -> [String:AnyObject]? {
        if let data = text.data(using: String.Encoding.utf8) {
            do {
                return try JSONSerialization.jsonObject(with: data, options: []) as? [String:AnyObject]
            } catch let error as NSError {
                print(error)
            }
        }
        return nil
    }
    
    var getBaseURL : String {
        get {
            if self._baseURL == nil {
                let bundleID = Bundle.main.bundleIdentifier?.lowercased()
                let range = bundleID?.range(of: "usa")
                if range == nil {
                    self._baseURL = "https://myluckyzone.com/ngr"
                    self._SALT = "eB0oz38yq$au809@8BUd"
                } else {
                    self._baseURL = "https://myluckyzone.com/usa"
                    self._SALT = "4OEvsC#wd!IEFc@1pWd7"
                }
                self._baseURL = "http://dev.myluckyzone.com"
                self._SALT = "87lP^UA9Gh95Q3yQd01h"
            }
            return self._baseURL
        }
    }
 
    var getSALT : String {
        get {
            if self._baseURL == nil {
                let bundleID = Bundle.main.bundleIdentifier?.lowercased()
                let range = bundleID?.range(of: "usa")
                if range == nil {
                   
                    self._SALT = "eB0oz38yq$au809@8BUd" // USA
                } else {
                   
                    self._SALT = "4OEvsC#wd!IEFc@1pWd7" // NGR
                }
                
                self._SALT = "87lP^UA9Gh95Q3yQd01h" // DEV
            }
            return self._SALT
        }
    }
    
    func SHA1(_ key:String) -> String
    {
        //let coreData:Data = key.data(using: .utf8)!
        var digest = [UInt8](repeating: 0, count:Int(CC_SHA1_DIGEST_LENGTH))
        let data = key.data(using: String.Encoding.utf8)//coreData(using: String.Encoding.utf8)!
        data?.withUnsafeBytes {
            _ = CC_SHA1($0, CC_LONG((data?.count)!), &digest)
        }
        let hexBytes = digest.map { String(format: "%02hhx", $0) }
        return hexBytes.joined()
    }
    
    func getDeviceID()->String
    {
        
        let deviceId: String = UIDevice.current.identifierForVendor!.uuidString
        
        return deviceId as String
    }
    
    func upload_request_not_used()
    {
        let baseURL =   WebService.sharedInstance.getBaseURL
        let url:URL = URL(string: "\(baseURL)/webservice/login")!
        let request = NSMutableURLRequest(url: url)
        request.httpMethod = "POST"
        let paramString = "username=abhisek@redwebdesign.in&password=12345"
        
        request.httpBody = paramString.data(using: String.Encoding.utf8)
        
        
        let task = URLSession.shared.dataTask(with: request as URLRequest, completionHandler: { data, response, error in
            if error != nil{
                print("Error -> \(error)")
                return
            }
            
            do {
                let result = try JSONSerialization.jsonObject(with: data!, options: []) as? [String:AnyObject]
                
                print("Result -> \(result)")
                
            } catch {
                print("Error -> \(error)")
            }
        })
        
        task.resume()
        
    }

    
    
    func sendAPIRequest(_ urlpath:String, body: String ,task: String, completion: @escaping (_ result: [String: AnyObject], _ error: AnyObject?)-> Void ) -> Void
    {
        
       // if Reachability.isConnectedToNetwork() == true {
            
            let stringURl = (urlpath as String) + (task as String)
        
        
            let url:URL = URL(string: stringURl as String)!
            
            let request = NSMutableURLRequest(url: url)
            request.httpMethod = "POST"
            
            let bodydata = body.data(using: String.Encoding(rawValue: String.Encoding.utf8.rawValue))
        
            print("Making Request : \(stringURl)\nPost Data : \(body)")
        
            request.httpBody = bodydata
            
            let config = URLSessionConfiguration.default
        
            config.timeoutIntervalForRequest = 10
            
            let session = URLSession(configuration: config)
            
            let task = session.dataTask(with: request as URLRequest, completionHandler: { (data, response, error) -> Void in
                do
                {
                    if error == nil {
                        var datastring = NSString(data: data!, encoding: String.Encoding.utf8.rawValue)
                        print("\(datastring)")
                        let resultdic = try JSONSerialization.jsonObject(with: data!, options: JSONSerialization.ReadingOptions.allowFragments) as? [String:AnyObject]
                        print("Received Response \(resultdic!)")
                        if resultdic != nil {
                            completion(resultdic!,nil)
                        }
                    } else {
                        completion([String : AnyObject](), "Unable to connect to server" as AnyObject)
                    }
                }
                catch
                {
                    print("error")
                    print(error)
                }
                
            }) 
            task.resume()
            
      //  }
        
//        else {
//            
//            dispatch_async(dispatch_get_main_queue(), { () -> Void in
//                
//                MBProgressHUD.hideHUDForView(delegate.view, animated: true)
//                
//                let alertController = UIAlertController(title: "Alert View", message: "NO Internet Connection", preferredStyle: .Alert)
//                alertController.addAction(UIAlertAction(title: "OK", style: .Default, handler: nil))
//                
//            UIApplication.sharedApplication().keyWindow?.rootViewController?.presentViewController(alertController, animated: true, completion: nil)
//                return
//            })
//        }

        
            }
    
    
    
//    func getImageBySDWebImage(imageUrl:String,callCount:Int,completion: (fetchedImage: UIImage,callCountReturn:Int)-> Void)->Void
//    {
//        let queue = dispatch_queue_create("loader", nil)
//       // var imageToReturn = UIImage()
//        
//        dispatch_async(queue) { () -> Void in
//            
//        let imageurl :String = imageUrl.stringByAddingPercentEncodingWithAllowedCharacters(NSCharacterSet.URLQueryAllowedCharacterSet())!
//        if let url  = NSURL(string: imageurl),
//                data = NSData(contentsOfURL: url)
//            {
//                let imageToReturn:UIImage? =  UIImage(data: data)
//                if imageToReturn != nil
//                {
//                    completion(fetchedImage: imageToReturn!,callCountReturn: callCount)
//                }
//                else
//                {
//                    completion(fetchedImage: UIImage(named: "logo.png")!,callCountReturn: callCount)
//                }
//                
//            }
//            else
//            {
//                completion(fetchedImage: UIImage(named: "logo.png")!,callCountReturn: callCount)
//            }
//           
//        }
//        
//    }
//    
//    func getImageFromUrl(imageUrl:String,completion: (fetchedImage: UIImage)-> Void)->Void
//    {
////        let queue = dispatch_queue_create("loader", nil)
//        // var imageToReturn = UIImage()
//        
//        dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_BACKGROUND, 0)) { () -> Void in
//            
//            let imageurl :String = imageUrl.stringByAddingPercentEncodingWithAllowedCharacters(NSCharacterSet.URLQueryAllowedCharacterSet())!
//            
//            
//            if let url  = NSURL(string: imageurl),
//                data = NSData(contentsOfURL: url)
//            {
//                if data.length>0
//                {
//                        let imageToReturn:UIImage? =  UIImage(data: data)
//                        if imageToReturn != nil
//                        {
//                            completion(fetchedImage: imageToReturn!)
//                        }
//                        else
//                        {
//                            completion(fetchedImage: UIImage(named: "logo.png")!)
//                        }
//                }
//                else
//                {
//                    completion(fetchedImage: UIImage(named: "logo.png")!)
//                }
//            }
//            else
//            {
//                completion(fetchedImage: UIImage(named: "logo.png")!)
//            }
//            
//        }
//        
//    }
//    
//    
//    
//    
//    func imageUpload(urlpath:NSString,body: NSString , completion: (result: NSMutableDictionary, error: AnyObject?)-> Void ) -> Void
//    {
//        // let resultdic:NSDictionary!
//        //let urlpath:String = "http://106.51.252.229/jextn02/anilkumar/supermartdeals/api.php"
//        let url:NSURL = NSURL(string: urlpath as String)!
//        
//        let request = NSMutableURLRequest(URL: url)
//        request.HTTPMethod = "POST"
//        
//       // let bodydata = body.dataUsingEncoding(NSUTF8StringEncoding)
//        var err: NSError? = nil
//     
//        do
//        {
//            let data = body.dataUsingEncoding(NSUTF8StringEncoding)
//            request.HTTPBody = try NSJSONSerialization.dataWithJSONObject(data!, options: NSJSONWritingOptions(rawValue: 0))
//            
//        }
//        catch
//        {
//            print("error")
//             print(error)
//        }
//        
//        
//        // let operationqueue:NSOperationQueue = NSOperationQueue()
//        
//        
//        let config = NSURLSessionConfiguration.defaultSessionConfiguration()
//        let session = NSURLSession(configuration: config)
//        
//        let task = session.dataTaskWithRequest(request) { (data, response, error) -> Void in
//            
//            do
//            {
//                let resultdic = try NSJSONSerialization.JSONObjectWithData(data!, options: NSJSONReadingOptions.MutableContainers) as? NSMutableDictionary
//                //print(resultdic!)
//                completion(result: resultdic!,error: nil)
//                
//                
//            }
//            catch
//            {
//                print("error")
//                print(error)
//
//            }
//            
//        }
//        task.resume()
//    }
//
//    
//        
//   func imageUpload(prescriptionImageData:NSData, completion: (result: NSDictionary, error: AnyObject?)-> Void)
//    
//    {
//    
//    let params = NSMutableDictionary()
//    
//    let boundaryConstant  = "----------V2y2HFg03eptjbaKO0j1"
//    
//    
//    
//    //    let file1ParamConstant = "addattachment"
//    
//    //    let file2ParamConstant = "image"
//    
//    params.setObject("addattachment", forKey: "action")
//    
//    params.setObject("image", forKey: "filetype")
//    
//    params.setObject("img.jpg", forKey: "fileName")
//    
//    
//    
//    let requestUrl = NSURL(string: "http://test.drowl.in/api/")
//    
//    
//    
//    let request = NSMutableURLRequest()
//    
//    
//    
//    request.cachePolicy = NSURLRequestCachePolicy.ReloadIgnoringLocalCacheData
//    
//    request.HTTPShouldHandleCookies=false
//    
//    //    request.timeoutInterval = 30
//    
//    request.HTTPMethod = "POST"
//    
//    let authenticationString = NSUserDefaults.standardUserDefaults().valueForKey("authenticationtoken") as! String
//    
//    
//    
//    
//    
//    request.setValue("\(authenticationString)", forHTTPHeaderField: "Authorization")
//    
//    
//    
//    let contentType = "multipart/form-data; boundary=\(boundaryConstant)"
//    
//    
//    
//    request.setValue(contentType, forHTTPHeaderField: "Content-Type")
//    
//    
//    
//    let body = NSMutableData()
//    
//    
//    
//    // parameters
//    
//    
//    
//    for param in params {
//    
//    NSLog("Parameter \(param.key) Value \(param.value)")
//    
//    body.appendData("--\(boundaryConstant)\r\n" .dataUsingEncoding(NSUTF8StringEncoding)! )
//    
//    body.appendData("Content-Disposition: form-data; name=\"\(param.key)\"\r\n\r\n" .dataUsingEncoding(NSUTF8StringEncoding)!)
//    
//    body.appendData("\(param.value)\r\n" .dataUsingEncoding(NSUTF8StringEncoding)!)
//    
//   
//    }
//    
//    
//    
//    body.appendData("--\(boundaryConstant)\r\n".dataUsingEncoding(NSUTF8StringEncoding)!)
//    
//    
//    
//    
//    
//    body.appendData("Content-Disposition: form-data;   name=\"\("file")\" ;  filename=\"image.jpg\"\r\n".dataUsingEncoding(NSUTF8StringEncoding)!)
//    
//    
//    
//    body.appendData("Content-Type: image/jpeg\r\n\r\n".dataUsingEncoding(NSUTF8StringEncoding)!)
//    
//    
//    
//    body.appendData(prescriptionImageData)
//    
//    body.appendData("\r\n".dataUsingEncoding(NSUTF8StringEncoding)!)
//    
//    
//    
//    // image end
//    
//    
//    
//    
//    
//    
//    
//    body.appendData("--\(boundaryConstant)--\r\n".dataUsingEncoding(NSUTF8StringEncoding)!)
//    
//    
//    
//    request.HTTPBody  = body
//    
//    let postLength = "\(body.length)"
//    
//    //request.setValue
//    request.URL = requestUrl
//    
//    NSLog("\(request)")
//    
//    
//    
//    
//    
//    let task = NSURLSession.sharedSession().dataTaskWithRequest(request) {
//    
//    data, response, error in
//    
//    
//    
//    if error != nil
//    
//    {
//    
//    NSLog("error=\(error)")
//    
//    return
//    
//    }
//    
//    
//    
//    
//    
//    print("response = \(response)")
//    
//    do
//    
//    {
//    
//    let resultDic = try NSJSONSerialization.JSONObjectWithData(data!, options: NSJSONReadingOptions.MutableContainers) as? NSDictionary
//    
//    completion(result: resultDic!,error: nil)
//    
//    
//    
//    //        let responseString = NSString(data: data!, encoding: NSUTF8StringEncoding)
//    
//    //        NSLog("responseString = \(responseString!)")
//    
//    //        serverResponse = responseString!
//    
//    
//    
//    }
//    
//    catch let error
//    
//    {
//    
//    NSLog("json error \(error)")
//    
//    }
//    
//    }
//    
//    task.resume()
//    
//    }
   
}
