//
//  UrlClass.swift
//  Aura
//
//  Created by G.Abhisek on 22/03/16.
//  Copyright © 2016 Adodis. All rights reserved.
//

import UIKit

class UrlClass: NSObject
{
    static var _baseUrl : String?
    static var _baseVideoUrl : String?
    class var baseUrl: String {
        get {
            if _baseUrl == nil {
                let url = WebService.sharedInstance.getBaseURL
                _baseUrl = "\(url)/webservice/"
            }
            return _baseUrl!
        }
    }
    
    
    class var imageUrl: String
    {
        return baseUrl
       
    }
    
    class var videoURL: String
    {
//        get {
//            if _baseVideoUrl == nil {
//                let url = "http://dev.myluckyzone.com" //WebService.sharedInstance.getBaseURL
//                _baseVideoUrl = "\(url)/webservice/"
//            }
//            return _baseVideoUrl!
//        }
//        
        return "http://dev.myluckyzone.com/";
        
    }
    //http://dev.myluckyzone.com

}

