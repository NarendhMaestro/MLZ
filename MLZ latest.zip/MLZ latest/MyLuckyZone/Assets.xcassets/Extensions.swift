//
//  Extensions.swift
//  MyLuckyZone
//
//  Created by Adodis on 06/06/16.
//  Copyright © 2016 Adodis. All rights reserved.
//

import UIKit
import MBProgressHUD

class Extensions: NSObject {

}

extension UIViewController
{
    func showProgress()
    {
        let loadingNotification = MBProgressHUD.showAdded(to: self.view, animated: true)
        loadingNotification.mode = MBProgressHUDMode.indeterminate
        loadingNotification.labelText = "Loading"
        view.addSubview(loadingNotification)
    }
    
    func hideProgress()
    {
        MBProgressHUD.hide(for: self.view!, animated: true)
    }
}


extension UIViewController
{
    func displayAlert(_ title: String, message: String) -> UIAlertController {
        return displayAlert(title, message: message, handler: nil)
    }
    
    func displayAlert(_ title: String, message: String, handler: ((UIAlertAction) -> Void)?) -> UIAlertController {
        let alertController = UIAlertController(title: title, message: message, preferredStyle: .alert)
        DispatchQueue.main.async(execute: { () -> Void in
            alertController.addAction(UIAlertAction(title: "Ok", style: .default, handler: handler))
            self.present(alertController, animated: true, completion: nil)
        })
        return alertController
    }
    
    func logout() {
        if Reachability.isConnectedToNetwork() == true {
            self.showProgress()
            
            let token = UserDefaults.standard.object(forKey: "token") as? String
            if token == nil {
                DispatchQueue.main.async(execute: { () -> Void in
                    self.hideProgress()
                    self.dismiss(animated: true, completion: nil)
                })
                return
            }
            let body = String(format:"token=%@", token!)
            let task = "logout"
            WebService().sendAPIRequest(UrlClass.baseUrl, body: body,task: task) { (result, error) -> Void in
                DispatchQueue.main.async(execute: { () -> Void in
                    self.hideProgress()
                    UserDefaults.standard.removeObject(forKey: "token")
                    self.dismiss(animated: true, completion: nil)
                    let storyboard = UIStoryboard(name: "Main", bundle: nil)
                    let initialViewController = storyboard.instantiateViewController(withIdentifier: "LoginVC")
                    let appDelegate = UIApplication.shared.delegate as! AppDelegate
                    appDelegate.window?.rootViewController = initialViewController
                })
            }
        } else {
            self.displayAlert("Alert Message", message: "Please Check Internet connection")
        }
    }

}
