//
//  FonumInnnerViewController.swift
//  MyLuckyZone
//
//  Created by TechnoTackle on 28/12/16.
//  Copyright © 2016 Adodis. All rights reserved.
//

import UIKit
import SDWebImage
class FonumInnnerViewController: UIViewController ,UITableViewDelegate,UITableViewDataSource
{
    
    var selectedId:String?
    var selectedTitle:String?
    var selectedAnswerCount:String?
    var selectedDate:String?
    var selectedUser:String?
    var selectedDesc:String?
    var selectedAnswerId:String?
    
    var currentPage = NSInteger()
    var totalPage = NSInteger()
    var refreshControl: UIRefreshControl!
    var tableDataArray =  NSArray()
    var comment = UITextField()
    
    @IBOutlet weak var answerEditTextField: UITextField!
    @IBOutlet weak var answerEditView: UIView!
    @IBOutlet weak var tableView: UITableView!
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.tableView.tableFooterView = UIView()
        refreshControl = UIRefreshControl()
        //refreshControl.attributedTitle = NSAttributedString(string: "Pull to refresh")
        refreshControl.addTarget(self, action: #selector(FonumInnnerViewController.refresh(_:)), for: UIControlEvents.valueChanged)
        self.tableView.addSubview(refreshControl)
        //self.comment.delegate = self
        //self.navigationController?.navigationBar.barTintColor = UIColor.white
        // Do any additional setup after loading the view.
    }
    
    func editTapped(){
        print("Editing")
        //AddorEditVC
        let addorEditViewController = storyboard?.instantiateViewController(withIdentifier: "AddorEditVC") as! AddorEditViewController
        addorEditViewController.TYPE = "Edit Your Answer"
        addorEditViewController.Field1 = selectedTitle
        addorEditViewController.Field2 = selectedDesc
        addorEditViewController.selectedId = selectedId
        
        self.navigationController?.pushViewController(addorEditViewController, animated: true)
        
    }
    
    
    func refresh(_ sender:AnyObject) {
        
        //self.tableView.reloadData()
        self.loadPrimData()
        refreshControl.endRefreshing()
    }
    
    func textFieldShouldReturn(textField: UITextField!) -> Bool {   //delegate method
        view.endEditing(true)
        return true
    }
    
    
    func loadPrimData(){
        if Reachability.isConnectedToNetwork() == true {
            self.showProgress()
            
            let body = String(format:"token=%@&threadid=%@", UserDefaults.standard.object(forKey: "token") as! String,selectedId!)
            
            let task = "getthreaddetail"
            WebService().sendAPIRequest(UrlClass.baseUrl, body: body,task: task) { (result, error) -> Void in
                
                if result["status"] as! Int == 1
                {
                    
                    //let values = result ["thread"] as? NSArray//(self.tableDataArray.value(forKey: "answeredby") as! NSArray)[indexPath.row] as? String
                    self.selectedAnswerCount = (result ["thread"] as AnyObject).value(forKey: "noofanswers") as! String! //value ["noofanswers"] as? String
                    //self.selectedId = result ["threadid"] as? String
                    self.selectedTitle = (result ["thread"] as AnyObject).value(forKey: "title") as! String!// value ["title"] as? String
                    self.selectedDate = (result ["thread"] as AnyObject).value(forKey: "createddate") as! String!//value ["createddate"] as? String
                    self.selectedUser = (result ["thread"] as AnyObject).value(forKey: "createdby") as! String! // value [""]["createdby"] as? String
                    self.selectedDesc = (result ["thread"] as AnyObject).value(forKey: "description") as! String!//value ["description"] as? String
                    
                    DispatchQueue.main.async(execute: { () -> Void in
                        
                        if  (result ["thread"] as AnyObject).value(forKey: "canmodify") as! Int == 1
                        {
                            self.navigationItem.rightBarButtonItem = UIBarButtonItem(title: "Edit", style: .plain, target: self, action: #selector(self.editTapped))
                            
                        }
                        self.tableView.isHidden = false
                        self.hideProgress()
                        self.tableView.reloadData()
                        if self.selectedAnswerCount != "0"{
                            self.loadData()}
                    })
                    
                } else if result["status"] as! Int == 0 || result["status"] as! Int == -1
                {
                    DispatchQueue.main.async(execute: { () -> Void in
                        self.hideProgress()
                        self.displayAlert("Alert Message", message: result["msg"] as! String)
                    })
                }
                
            }
        }else{
            self.tableView.isHidden = true
            print("Nothing stored in NSUserDefaults yet. Set a value.")
        }
        
    }
    
    
    func loadData(){
        if Reachability.isConnectedToNetwork() == true {
            self.showProgress()
            
            let body = String(format:"token=%@&threadid=%@&pagenumer=%@", UserDefaults.standard.object(forKey: "token") as! String,selectedId!,String(currentPage))
            
            let task = "listallthreadanswers"
            WebService().sendAPIRequest(UrlClass.baseUrl, body: body,task: task) { (result, error) -> Void in
                
                if result["status"] as! Int == 1
                {
                    self.totalPage = result ["totalpages"] as! NSInteger
                    
                    if(self.currentPage == 1)
                    {
                        self.tableDataArray = result["answerslist"] as! NSArray
                    }
                    else
                    {
                        let newPageArr = result["answerslist"] as! NSArray
                        
                        let newArr = self.tableDataArray.mutableCopy() as? NSMutableArray
                        
                        for i in self.tableDataArray.count ..< self.tableDataArray.count+newPageArr.count
                        {
                            newArr!.insert(newPageArr[i-self.tableDataArray.count], at: i)
                        }
                        self.tableDataArray = newArr!
                    }
                    print("Array.",self.tableDataArray)
                    
                    
                    DispatchQueue.main.async(execute: { () -> Void in
                        self.tableView.isHidden = false
                        self.hideProgress()
                        self.tableView.reloadData()
                    })
                    
                } else if result["status"] as! Int == 0 || result["status"] as! Int == -1
                {
                    DispatchQueue.main.async(execute: { () -> Void in
                        self.hideProgress()
                        self.tableView.reloadData()
                        if(self.tableDataArray.count>0){
                            self.displayAlert("Alert Message", message: result["msg"] as! String)}
                    })
                }
                
            }
        }else{
            self.tableView.isHidden = true
            print("Nothing stored in NSUserDefaults yet. Set a value.")
        }
        
    }
    
    override func viewWillAppear(_ animated: Bool) {
        self.answerEditView.isHidden = true
        super.viewWillAppear(animated)
        self.tableView.isHidden = true
        self.currentPage = 1
        self.loadPrimData()
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
    func numberOfSections(in tableView: UITableView) -> Int
    {
        return 2;
        
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        if indexPath.section == 0 {//header
            return 260
        }
        return 160
    }
    
    
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int
    {
        
        if (section == 0){
            return 1
        }
        return self.tableDataArray.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell
    {
        
        if(indexPath.section == 1){
            print("answerCell")//
            //let cell = self.tableView.dequeueReusableCell(withIdentifier: "answerForumCell", for: indexPath)
            let cell = self.tableView.dequeueReusableCell(withIdentifier: "answerForumCell", for: indexPath) as!
            ForumAnswerTableViewCell
            
            cell.selectionStyle = UITableViewCellSelectionStyle.none
            
            do{
                (cell.contentView.viewWithTag(10) as! UILabel).text =  (self.tableDataArray.value(forKey: "answeredby") as! NSArray)[indexPath.row] as? String
            }catch{
                (cell.contentView.viewWithTag(10) as! UILabel).text =  ""
            }
            do{
                (cell.contentView.viewWithTag(20) as! UILabel).text = (self.tableDataArray.value(forKey: "createddate") as! NSArray)[indexPath.row] as? String
            }catch{
                (cell.contentView.viewWithTag(20) as! UILabel).text = ""
            }
            
            do{
                (cell.contentView.viewWithTag(30) as! UILabel).text = String(format:"(%@)",((self.tableDataArray.value(forKey: "nooflikes") as! NSArray)[indexPath.row] as? String)!)
            }catch{
                (cell.contentView.viewWithTag(30) as! UILabel).text = ""
            }
            do{
                (cell.contentView.viewWithTag(40) as! UILabel).text = (self.tableDataArray.value(forKey: "answer") as! NSArray)[indexPath.row] as? String
            }catch{
                (cell.contentView.viewWithTag(40) as! UILabel).text = ""
            }
            
            do{
                let likeValue = (self.tableDataArray.value(forKey: "canlike") as! NSArray)[indexPath.row] as? Int
                cell.likeBtn.isEnabled = true
               
                if (likeValue == 1){
                    cell.likeBtn.isEnabled = true
                    cell.likeImage?.image = UIImage(named:"facebook_like")

                }else if (likeValue == 2){
                    cell.likeBtn.isEnabled = true
                    cell.likeImage?.image = UIImage(named:"liked")

                }else{
                    cell.likeBtn.isEnabled = false
                    cell.likeImage?.image = UIImage(named:"unliked")
                }
                
            }catch{
                
            }
            
            cell.likeBtn.addTarget(self, action: #selector(FonumInnnerViewController.likePost(_:)), for: .touchUpInside)
            cell.likeBtn.tag = indexPath.row
            
            do{
                //                if(self.isNotNSNull((self.tableDataArray.value(forKey: "profileimg") as! NSArray)[indexPath.row] as? String as AnyObject))
                //                {
                let imageURl = String(format: "%@%@", WebService.sharedInstance.getBaseURL, ((self.tableDataArray.value(forKey: "profileimg") as! NSArray)[indexPath.row] as? String)!)
                
                let url = URL(string: imageURl.trim())
                DispatchQueue.global(priority: DispatchQueue.GlobalQueuePriority.background).async {
                    let data = try? Data(contentsOf: url!)
                    DispatchQueue.main.async(execute: {
                        cell.userImage.image = UIImage(data: data!)
                    });
                }
                // }
                
            }catch{
                
            }
            do{
                let value1 = (self.tableDataArray.value(forKey: "canmodify") as! NSArray)[indexPath.row] as? Int
                
                if(value1 == 1){
                    cell.editBtn.isHidden = false
                }else
                {
                    cell.editBtn.isHidden = true
                }
                
                cell.editBtn.addTarget(self, action: #selector(FonumInnnerViewController.editClick(_:)), for: .touchUpInside)
                cell.editBtn.tag = indexPath.row
                
            }catch{
                
            }
            
            do{
                let value2 = (self.tableDataArray.value(forKey: "canselectbestanswer") as! NSArray)[indexPath.row] as? Int
                let value11 = (self.tableDataArray.value(forKey: "isbestanswer") as! NSArray)[indexPath.row] as? String
                
                if(value2 == 0){
                    cell.bestAnswerImage.image = UIImage(named:"liked")
                    cell.bestAnswerBtn.isHidden = true
                    cell.bestAnswerView.isHidden = true
                }else//1 button show
                {
                    cell.bestAnswerImage.image = UIImage(named:"facebook_like")
                    cell.bestAnswerBtn.isHidden = false
                    cell.bestAnswerView.isHidden = false
                }
                
                if(value11 == "0"){
                    
                    //cell.BestAnswerLabel.text = "set as best answer"
                    cell.BestAnswerLabel.textColor = UIColor(red: 14/255, green: 121/255, blue: 238/255, alpha: 1.0)//UIColor.darkGray
                    let underlineAttribute = [NSUnderlineStyleAttributeName: NSUnderlineStyle.styleSingle.rawValue]
                    let underlineAttributedString = NSAttributedString(string: "set as best answer", attributes: underlineAttribute)
                    cell.BestAnswerLabel.attributedText = underlineAttributedString
                }else//show green text
                {
                    cell.bestAnswerBtn.isHidden = true
                    cell.bestAnswerView.isHidden = false
                    cell.bestAnswerImage.image = UIImage(named:"checked")
                    cell.BestAnswerLabel.text = "Best Answer"
                    cell.BestAnswerLabel.textColor = UIColor.green
                }
                
                cell.bestAnswerBtn.addTarget(self, action: #selector(FonumInnnerViewController.bestAnswerClick(_:)), for: .touchUpInside)
                cell.bestAnswerBtn.tag = indexPath.row
                
            }catch{
                
            }

            
            return cell
        }else{ //header cell
            
            print("PrimCell")
            
            let cell = self.tableView.dequeueReusableCell(withIdentifier: "primInnerForumCell", for: indexPath) as! ForumPrimTableViewCell
            //let cell = self.tableView.dequeueReusableCell(withReuseIdentifier: "primInnerForumCell",for:indexPath) as! ForumPrimTableViewCell
            //self.tableView.dequeueReusableCell(withIdentifier: "primInnerForumCell", for: indexPath)
            cell.selectionStyle = UITableViewCellSelectionStyle.none
            let value = String(format:"Answer (%@)",selectedAnswerCount!)
            cell.answerCountLbl.text = value
            cell.dateLbl.text = selectedDate //String(format:"Date : %@ & Answer (%@)", selectedDate!,selectedAnswerCount!)
            cell.answersMainCount.text = value
            cell.answerContent.text = self.selectedDesc
            //cell..text = selectedTitle
            cell.userNameLbl.text = selectedUser
            cell.titleLbl.text = selectedTitle
            cell.postBtn.addTarget(self, action: #selector(FonumInnnerViewController.pressed(_:)), for: .touchUpInside)
            comment = cell.commentTxt
            
            
            return cell
        }
        
    }
    
    func bestAnswerClick(_ sender:UIButton) {
        
        view.endEditing(true)
        var tag : String!
        tag = (self.tableDataArray.value(forKey: "answerid") as! NSArray)[sender.tag] as? String //as! String
        
        if Reachability.isConnectedToNetwork() == true {
            self.showProgress()
            
            let body = String(format:"token=%@&answerid=%@", UserDefaults.standard.object(forKey: "token") as! String,tag!)
            
            let task = "setbestanswer"
            WebService().sendAPIRequest(UrlClass.baseUrl, body: body,task: task) { (result, error) -> Void in
                
                if result["status"] as! Int == 1
                {
                    DispatchQueue.main.async(execute: { () -> Void in
                        self.currentPage = 1
                        self.tableDataArray = NSMutableArray()
                        self.hideProgress()
                        self.loadData()
                    })
                    
                } else if result["status"] as! Int == 0 || result["status"] as! Int == -1
                {
                    DispatchQueue.main.async(execute: { () -> Void in
                        self.hideProgress()
                        self.displayAlert("Alert Message", message: result["msg"] as! String)
                    })
                }
                
            }
        }else{
            //self.tableView.isHidden = true
            print("Nothing stored in NSUserDefaults yet. Set a value.")
        }

        
    }
    
    func editClick(_ sender:UIButton) {
        
        view.endEditing(true)
        var tag : String!
        tag = (self.tableDataArray.value(forKey: "answerid") as! NSArray)[sender.tag] as? String //as! String
        var tag1 : String!
        tag1 = (self.tableDataArray.value(forKey: "answer") as! NSArray)[sender.tag] as? String //as! String
        print(tag)
        
        let alertController = UIAlertController(title: "Alert Message", message: "Do you want to Edit Or Delete Post", preferredStyle: .alert)
        
        // Create the actions
        let okAction = UIAlertAction(title: "Edit", style: UIAlertActionStyle.default) {
            UIAlertAction in
            DispatchQueue.main.async(execute: { () -> Void in
                //self.showEdit(tag,tag1)
                self.answerEditView.isHidden = false
                self.answerEditTextField.text = tag1
                self.selectedAnswerId = tag
            })
        }
        let deleteAction = UIAlertAction(title: "Delete", style: UIAlertActionStyle.destructive) {
            UIAlertAction in
            DispatchQueue.main.async(execute: { () -> Void in
                self.deletePost(tag)
                
            })
        }
        let cancelAction = UIAlertAction(title: "Cancel", style: UIAlertActionStyle.cancel) {
            UIAlertAction in
            DispatchQueue.main.async(execute: { () -> Void in
                
            })
        }
        
        alertController.addAction(okAction)
        alertController.addAction(deleteAction)
        alertController.addAction(cancelAction)
        
        // Present the controller
        self.present(alertController, animated: true, completion: nil)
    }
    
    func deletePost(_ sender:String){
        let alertController = UIAlertController(title: "Alert Message", message: "Do want to delete post", preferredStyle: .alert)
        
        // Create the actions
        let okAction = UIAlertAction(title: "Yes", style: UIAlertActionStyle.destructive) {
            UIAlertAction in
            DispatchQueue.main.async(execute: { () -> Void in
                //
                if Reachability.isConnectedToNetwork() == true {
                    self.showProgress()
                    
                    let body = String(format:"token=%@&answerid=%@", UserDefaults.standard.object(forKey: "token") as! String,sender)
                    
                    let task = "removeanswer"
                    WebService().sendAPIRequest(UrlClass.baseUrl, body: body,task: task) { (result, error) -> Void in
                        
                        if result["status"] as! Int == 1
                        {
                            DispatchQueue.main.async(execute: { () -> Void in
                                
                                self.hideProgress()
                                self.loadPrimData()
                            })
                            
                        } else if result["status"] as! Int == 0 || result["status"] as! Int == -1
                        {
                            DispatchQueue.main.async(execute: { () -> Void in
                                self.hideProgress()
                                self.displayAlert("Alert Message", message: result["msg"] as! String)
                            })
                        }
                        
                    }
                }else{
                    //self.tableView.isHidden = true
                    print("Nothing stored in NSUserDefaults yet. Set a value.")
                }
            })
        }
        let deleteAction = UIAlertAction(title: "No", style: UIAlertActionStyle.cancel) {
            UIAlertAction in
            DispatchQueue.main.async(execute: { () -> Void in
                
            })
        }
        
        alertController.addAction(okAction)
        alertController.addAction(deleteAction)
        
        
        // Present the controller
        self.present(alertController, animated: true, completion: nil)
        
    }
    
    func showEdit(_ sender:String ,_ sender1:String){
        
        let alert = UIAlertController(title: "Edit Answer", message: "", preferredStyle: .alert)
       
        alert.addTextField { (textField) in
            textField.text = sender1
        }
       
        alert.addAction(UIAlertAction(title: "OK", style: .default, handler: { [weak alert] (_) in
            let textField = alert?.textFields![0] // Force unwrapping because we know it exists.
            print("Text field: \(textField?.text)")
            if Reachability.isConnectedToNetwork() == true {
                self.showProgress()
                
                let body = String(format:"token=%@&answerid=%@&answer=%@", UserDefaults.standard.object(forKey: "token") as! String,sender,(textField?.text)!)
                
                let task = "updateanswer"
                WebService().sendAPIRequest(UrlClass.baseUrl, body: body,task: task) { (result, error) -> Void in
                    
                    if result["status"] as! Int == 1
                    {
                        DispatchQueue.main.async(execute: { () -> Void in
                            
                            self.hideProgress()
                            self.loadPrimData()
                        })
                        
                    } else if result["status"] as! Int == 0 || result["status"] as! Int == -1
                    {
                        DispatchQueue.main.async(execute: { () -> Void in
                            self.hideProgress()
                            self.displayAlert("Alert Message", message: result["msg"] as! String)
                        })
                    }
                    
                }
            }else{
                //self.tableView.isHidden = true
                print("Nothing stored in NSUserDefaults yet. Set a value.")
            }

        }))
        
        alert.addAction(UIAlertAction(title: "Cancel", style: .cancel, handler: { [weak alert] (_) in
            
        }))
        // 4. Present the alert.
        self.present(alert, animated: true, completion: nil)
    }
    
    
    
    func pressed(_ sender:AnyObject) {
        
        view.endEditing(true)
        let comments = self.comment.text
        print("Comment Text :",comments!)
        
        if((comments?.characters.count)!>0){
            
            if Reachability.isConnectedToNetwork() == true {
                self.showProgress()
                
                let body = String(format:"token=%@&threadid=%@&answer=%@", UserDefaults.standard.object(forKey: "token") as! String,selectedId!,comments!)
                
                let task = "postanswer"
                WebService().sendAPIRequest(UrlClass.baseUrl, body: body,task: task) { (result, error) -> Void in
                    
                    if result["status"] as! Int == 1
                    {
                        
                        DispatchQueue.main.async(execute: { () -> Void in
                            //                            self.tableView.isHidden = false
                            self.comment.text = ""
                            self.loadPrimData()
                            self.hideProgress()
                            //                          self.tableView .reloadData()
                        })
                        
                    } else if result["status"] as! Int == 0 || result["status"] as! Int == -1
                    {
                        DispatchQueue.main.async(execute: { () -> Void in
                            self.hideProgress()
                            self.displayAlert("Alert Message", message: result["msg"] as! String)
                        })
                    }
                    
                }
            }else{
                // self.tableView.isHidden = true
                print("Nothing stored in NSUserDefaults yet. Set a value.")
            }
            
            
        }else{
            
        }
    }
    
    func likePost(_ sender:UIButton) {
        
        view.endEditing(true)
        //var tag : String!
        
        var tag : String!
        var status : String!
        tag = (self.tableDataArray.value(forKey: "answerid") as! NSArray)[sender.tag] as? String //postanswerlike
        
        let value1 = (self.tableDataArray.value(forKey: "canlike") as! NSArray)[sender.tag] as? Int
        
        if(value1 == 1){
            status = "1"
        }else{
            status = "2"
        }
        
        if Reachability.isConnectedToNetwork() == true {
            self.showProgress()
            
            let body = String(format:"token=%@&answerid=%@&status=%@", UserDefaults.standard.object(forKey: "token") as! String,tag!,status!)
            
            let task = "postanswerlike"
            WebService().sendAPIRequest(UrlClass.baseUrl, body: body,task: task) { (result, error) -> Void in
                
                if result["status"] as! Int == 1
                {
                    DispatchQueue.main.async(execute: { () -> Void in
                        
                        self.currentPage = 1
                        self.tableDataArray = NSMutableArray()
                        
                        self.hideProgress()
                        self.loadData()
                    })
                    
                } else if result["status"] as! Int == 0 || result["status"] as! Int == -1
                {
                    DispatchQueue.main.async(execute: { () -> Void in
                        self.hideProgress()
                        self.displayAlert("Alert Message", message: result["msg"] as! String)
                    })
                }
                
            }
        }else{
            //self.tableView.isHidden = true
            print("Nothing stored in NSUserDefaults yet. Set a value.")
        }
    }
    
    func isNotNSNull(_ object:AnyObject) -> Bool {
        return object.classForCoder != NSNull.classForCoder()
    }
    
    @IBAction func answerViewHolderClicked(_ sender: Any) {
        self.answerEditView.isHidden = true
    }
    @IBAction func updateAnswerEditClicked(_ sender: Any) {
        
        
        view.endEditing(true)
        if Reachability.isConnectedToNetwork() == true {
            self.showProgress()
            
            let body = String(format:"token=%@&answerid=%@&answer=%@", UserDefaults.standard.object(forKey: "token") as! String,self.selectedAnswerId!,(self.answerEditTextField?.text)!)
            
            let task = "updateanswer"
            WebService().sendAPIRequest(UrlClass.baseUrl, body: body,task: task) { (result, error) -> Void in
                
                if result["status"] as! Int == 1
                {
                    DispatchQueue.main.async(execute: { () -> Void in
                        self.answerEditView.isHidden = true
                        self.hideProgress()
                        self.loadPrimData()
                    })
                    
                } else if result["status"] as! Int == 0 || result["status"] as! Int == -1
                {
                    DispatchQueue.main.async(execute: { () -> Void in
                        self.hideProgress()
                        self.displayAlert("Alert Message", message: result["msg"] as! String)
                    })
                }
                
            }
        }else{
            //self.tableView.isHidden = true
            print("Nothing stored in NSUserDefaults yet. Set a value.")
        }

    }
    
    @IBAction func cancelAnswerEditClicked(_ sender: Any) {
         self.answerEditView.isHidden = true
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        
        //self.performSegue(withIdentifier: "ForumInnner", sender: ["index" : (indexPath as NSIndexPath).row])// as UIViewController
        
    }
    func scrollViewDidEndDragging(_ scrollView: UIScrollView, willDecelerate decelerate: Bool) {
        
        let currentOffset = scrollView.contentOffset.y
        
        let maximumOffset = scrollView.contentSize.height - scrollView.frame.size.height
        
        
        if (maximumOffset - currentOffset <= 10)
        {
            
            if (self.currentPage == totalPage)
            {
                
            } else {
                self.currentPage = self.currentPage + 1
                
                //print(self.currentPage)
                
                self.loadData()
            }
            
        }
        
    }
    
    
}
