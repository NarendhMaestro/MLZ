//
//  ChatListVC.swift
//  MyLuckyZone
//
//  Created by Maestro_MAC1 on 26/05/17.
//  Copyright © 2017 Adodis. All rights reserved.
//

import UIKit
import SDWebImage
import QuartzCore

class ChatListCell: UITableViewCell {
    @IBOutlet var photo: UIImageView!
    @IBOutlet var name : UILabel!
}

class ChatListVC: UIViewController, UITableViewDelegate, UITableViewDataSource {

    @IBOutlet weak var tableView: UITableView!
    
    @IBOutlet weak var viewNoFriends: UIView!
    
    let baseUrlChat = "https://rawcaster.com/mlzwebservice/"
    var country : NSString!
    var totalPages = 0
    var currentPage : NSInteger!
    var unreadCount = 0
     var arrFriendList = NSArray()
    
    
    var shareText = NSString()
    var shareLink = NSString()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        viewNoFriends.isHidden = self.arrFriendList.count > 0 ? true : false
        
        self.currentPage = 1
        
        
        
        let bundleID = Bundle.main.bundleIdentifier?.lowercased()
        self.country = "Nigiria"
        let range = bundleID?.range(of: "usa")
        if range != nil {
            self.country = "USA"
        }
        
        
        DispatchQueue.main.async {
            self.getToken()
        }
    }
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(true)
        self.tableView.reloadData()
    }
    

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    @IBAction func onInviteFriends(_ sender: Any)
    {
        let firstActivityItem = self.shareText
        let secondActivityItem : NSURL = NSURL(string: self.shareLink as String)!
        
        let activityViewController : UIActivityViewController = UIActivityViewController(
            activityItems: [firstActivityItem, secondActivityItem], applicationActivities: nil)
        
        activityViewController.popoverPresentationController?.sourceView = (sender as! UIButton)
        
        activityViewController.popoverPresentationController?.permittedArrowDirections = UIPopoverArrowDirection.unknown
        activityViewController.popoverPresentationController?.sourceRect = CGRect(x: 150, y: 150, width: 0, height: 0)
        
        // Anything you want to exclude
        activityViewController.excludedActivityTypes = [
            UIActivityType.postToWeibo,
            UIActivityType.print,
            UIActivityType.assignToContact,
            UIActivityType.saveToCameraRoll,
            UIActivityType.addToReadingList,
            UIActivityType.postToFlickr,
            UIActivityType.postToVimeo,
            UIActivityType.postToTencentWeibo
        ]
        
        self.present(activityViewController, animated: true, completion: nil)
    }
    @IBAction func openURL(_ sender: Any) {
        let url = URL(string: "http://www.rawcaster.com")!
        if #available(iOS 10.0, *) {
            UIApplication.shared.open(url, options: [:], completionHandler: nil)
        } else {
            UIApplication.shared.openURL(url)
        }
        
    }

    // MARK: - Table view data source

    func numberOfSections(in tableView: UITableView) -> Int {
        // #warning Incomplete implementation, return the number of sections
        return 1
    }

    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of rows
        return arrFriendList.count
    }

    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "ChatListCell", for: indexPath) as! ChatListCell
        cell.selectionStyle = UITableViewCellSelectionStyle.none
        
         print(self.arrFriendList.object(at: indexPath.row))
        
        
        cell.name.text = (self.arrFriendList.value(forKey: "usr_firstname") as! NSArray)[indexPath.row] as? String
        DispatchQueue.main.async {
            if (self.isNotNSNull((self.arrFriendList.object(at: (indexPath as NSIndexPath).row) as! NSDictionary).value(forKey: "profile")! as AnyObject))
            {
                // let imageURl = String(format: "%@%@", WebService.sharedInstance.getBaseURL, ((self.arrFriendList[(indexPath as NSIndexPath).row] as AnyObject).value(forKey: "img") as? NSString)!)
                //test
                let imageURl = String(format: "https://rawcaster.com/%@", ((self.arrFriendList[(indexPath as NSIndexPath).row] as AnyObject).value(forKey: "profile") as? NSString)!)
                
                if (self.isNotNSNull(imageURl as AnyObject))
                {
                    cell.photo.sd_setImage(with: URL(string:imageURl)
                        , placeholderImage: nil
                        , options: SDWebImageOptions.highPriority
                        , progress: {(receivedSize: Int, expectedSize: Int) in
                    }
                        , completed:{(image: UIImage?, error: Error?, cacheType: SDImageCacheType, imageURL: URL?) in
                            if (image != nil) {
                                cell.photo?.image = image
                            }
                    })
                }
            }
        }
        
        
        let status = String(format: "%@", ((self.arrFriendList[(indexPath as NSIndexPath).row] as AnyObject).value(forKey: "profile") as? NSString)!)
        
        if status == "1"
        {
        let views = UIView(frame:CGRect(x:self.view.frame.size.width - 20, y:(cell.frame.size.height/2) - 5, width:10, height:10))
        views.backgroundColor = UIColor.green
        views.layer.cornerRadius = 5.0
        views.clipsToBounds = true
        cell.addSubview(views)
        
        }
        
       
        cell.setNeedsLayout();
        return cell
    }
    func tableView(_ tableView: UITableView, willDisplay cell: UITableViewCell, forRowAt indexPath: IndexPath) {
        
        DispatchQueue.main.async(execute: { () -> Void in
            self.hideProgress()
        })
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        let dict = self.arrFriendList.object(at: indexPath.row) as! NSDictionary
        let Vc = self.storyboard?.instantiateViewController(withIdentifier: "chatPageVC") as! chatPageVC
        Vc.strName = dict["usr_firstname"] as? NSString
        Vc.imageUrl = dict["profile"] as? NSString
        
        print("%@", UserDefaults.standard.string(forKey: "user_id_chat")! as NSString)
        Vc.userid = UserDefaults.standard.string(forKey: "user_id_chat")! as NSString
        Vc.receiverid = dict["usr_userid"] as? NSString
        self.present(Vc, animated: true, completion: nil)
        
    //  performSegue(withIdentifier: "showConversation", sender: nil)
    }
    
    
    
    func isNotNSNull(_ object:AnyObject) -> Bool {
        return object.classForCoder != NSNull.classForCoder()
    }
    
    func getUnreadChatCount()
    {
        self.showProgress()
        if Reachability.isConnectedToNetwork()    == true {
            let body = String(format:"token=%@", UserDefaults.standard.string(forKey: "tokenChat")!)
            let task = "getunreadchatcount"
            WebService().sendAPIRequest(baseUrlChat, body: body,task: task) { (result, error) -> Void in
                if result["status"] as! Int == 1
                {
                    DispatchQueue.main.async(execute: { () -> Void in
                        self.hideProgress()
                        self.unreadCount = result["chatunreadcount"] as! Int
                    })
                }
            }
        } else {
            self.displayAlert("Alert Message", message: "Please Check Internet connection")
        }
    }
    
    func getToken()
    {
        self.showProgress()
        if Reachability.isConnectedToNetwork() == true {
            //let body = String(format:"username=%@,gcmid=\(WebService.sharedInstance.getDeviceUUID()!),country=%@", UserDefaults.standard.string(forKey: "userName")!, self.country)
            var body = String(format:"devicetype=1&username=%@&gcmid=uighhgygjhgygjygjyguy&country=", UserDefaults.standard.string(forKey: "userName")!)
            if self.country == "USA" {
               body = body.appending("2")
            }else{
                 body = body.appending("1")
            }
            
            let task = "checkuserfromrawcaster"
            WebService().sendAPIRequest(baseUrlChat, body: body,task: task) { (result, error) -> Void in
                
                print(result)
                if result["status"] as! Int == 1
                {
                    DispatchQueue.main.async(execute: { () -> Void in
                        UserDefaults.standard.set(result["token"], forKey: "tokenChat")
                        UserDefaults.standard.set(result["user_id"], forKey: "user_id_chat")
                        self.getcChatMembers()
                    })
                } else {
                    self.displayAlert("Alert Message", message: result["msg"] as! String)
                }
            }
        } else {
            self.displayAlert("Alert Message", message: "Please Check Internet connection")
        }
    }
    
    
    
    func getcChatMembers()
    {
        if Reachability.isConnectedToNetwork() == true {
            let body = String(format:"token=%@&pagenumber=1", UserDefaults.standard.string(forKey: "tokenChat")!)
            let task = "getuserfriendlistfromtoken"
            WebService().sendAPIRequest(baseUrlChat, body: body,task: task) { (result, error) -> Void in
                
                print(result)
                if result["status"] as! Int == 1
                {
                    DispatchQueue.main.async(execute: { () -> Void in
                        self.hideProgress()
                        self.totalPages = result["totalpages"] as! Int
                        self.currentPage = result["currentpageno"] as! Int
                        self.arrFriendList = result["friendlist"] as! NSArray
                        self.tableView.reloadData()
                        
                        
                        self.viewNoFriends.isHidden = true
                        
                    })
                }
                else if result["status"] as! Int == 2
                {
                    DispatchQueue.main.async(execute: { () -> Void in
                        self.hideProgress()
                        self.viewNoFriends.isHidden = false
                        
                        self.shareLink = result["referralurl"] as! NSString
                        self.shareText = result["msg"] as! NSString
                    })
                }
            }
        } else {
            self.displayAlert("Alert Message", message: "Please Check Internet connection")
        }
    }
    
    
    
    
    

    /*
    // Override to support conditional editing of the table view.
    override func tableView(_ tableView: UITableView, canEditRowAt indexPath: IndexPath) -> Bool {
        // Return false if you do not want the specified item to be editable.
        return true
    }
    */

    /*
    // Override to support editing the table view.
    override func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCellEditingStyle, forRowAt indexPath: IndexPath) {
        if editingStyle == .delete {
            // Delete the row from the data source
            tableView.deleteRows(at: [indexPath], with: .fade)
        } else if editingStyle == .insert {
            // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
        }    
    }
    */

    /*
    // Override to support rearranging the table view.
    override func tableView(_ tableView: UITableView, moveRowAt fromIndexPath: IndexPath, to: IndexPath) {

    }
    */

    /*
    // Override to support conditional rearranging of the table view.
    override func tableView(_ tableView: UITableView, canMoveRowAt indexPath: IndexPath) -> Bool {
        // Return false if you do not want the item to be re-orderable.
        return true
    }
    */

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
