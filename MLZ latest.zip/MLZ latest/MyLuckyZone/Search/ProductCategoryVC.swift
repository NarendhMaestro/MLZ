//
//  ProductCategoryVC.swift
//  MyLuckyZone
//
//  Created by Adodis on 28/05/16.
//  Copyright © 2016 Adodis. All rights reserved.
//

import UIKit

class ProductCategoryVC: UIViewController , UITableViewDataSource , UITableViewDelegate , UITextFieldDelegate
{

    
    @IBOutlet var theCategoryTextField: UITextField!
    
    @IBOutlet var theTableView: UITableView!
    
    var dataArray = NSArray()
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        self.showProgress()
        
        self.theTableView.register(UITableViewCell.self, forCellReuseIdentifier: "cellCategory")
        self.theTableView.backgroundColor = UIColor.black
 
    }
    
    
    func numberOfSections(in tableView: UITableView) -> Int // Default is
    {
        return 1
    }
    
     func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int
     {
     return dataArray.count
    }
    
    // Row display. Implementers should *always* try to reuse cells by setting each cell's reuseIdentifier and querying for available reusable cells with dequeueReusableCellWithIdentifier:
   
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "cellCategory", for: indexPath) as UITableViewCell
        
        cell.backgroundColor = UIColor.black
        
        cell.textLabel?.font = UIFont.systemFont(ofSize: 14)
        
        cell.textLabel?.textColor = UIColor.white
        
        cell.textLabel?.text = (self.dataArray.object(at: (indexPath as NSIndexPath).row) as AnyObject).value(forKey: "categoryname") as? String
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        let ids = "&categoryid"
        let value1 = (self.dataArray.object(at: (indexPath as NSIndexPath).row) as AnyObject).value(forKey: "categoryid") as? String
        let value = ids + "=" + value1!
        
        //UserDefaults.standard.set("1", forKey: "isCategorySearch")
        
        self.performSegue(withIdentifier: "searchProduct", sender: (value))
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        
        let destinationView = segue.destination as! SearchProductVC
        
        destinationView.theProductCategory = sender as! String as NSString
    }
    
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(true)
        
        
        if Reachability.isConnectedToNetwork() == true {
            
        self.getProductCategory("")
            
        } else {
            hideProgress()
        self.displayAlert("Alert Message", message: "Please Check Internet connection")
            
        }

    }

    
    func getProductCategory(_ searchText:NSString)
    {
        let body = String(format:"pagenumer=1&searchkey",searchText)
        
        let task = "listallproductcategories"
        WebService().sendAPIRequest(UrlClass.baseUrl, body: body,task: task) { (result, error) -> Void in
            
            if(result.count>0){
            
            if result["status"] as! Int == 1
            {
            self.dataArray = result["categorylist"] as! NSArray
                
            DispatchQueue.main.async(execute: { () -> Void in
                
            self.theTableView.reloadData()
                 self.hideProgress()
                
            })
            }
            }else{
                
            }
        }
    }
    
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool // called when 'return' key pressed. 
    {
     return textField.resignFirstResponder()
    }
    
    @IBAction func searchCategories(_ sender: AnyObject) {
        
    //UserDefaults.standard.set("0", forKey: "isCategorySearch")
        
    self.performSegue(withIdentifier: "searchProduct", sender: self.theCategoryTextField.text! as String)

    }


    

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}



