//
//  SearchProductVC.swift
//  MyLuckyZone
//
//  Created by Kavya Mishra on 6/1/16.
//  Copyright © 2016 Adodis. All rights reserved.
//

import UIKit
import HMSegmentedControl


class SearchProductVC: UIViewController ,UIScrollViewDelegate{
    
    
    var theProductCategory = NSString()
    
    @IBOutlet weak var theAvailablePoints: UILabel!
    
    let segmentedcontrol2 = HMSegmentedControl()
    
    let scrollView = UIScrollView()
    
    @IBOutlet weak var contentView: UIView!
    
    @IBOutlet weak var segmentView: UIView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
    }
    
    override func viewWillAppear(_ animated: Bool)
    {
        if Reachability.isConnectedToNetwork() == true {
            self.getUserPoints()
            
        } else {
            self.displayAlert("Alert Message", message: "Please Check Internet connection")
            
        }
        
        
        createSegments()
    }
    
    
    func createSegments()
    {
        
        
        let  sectionTitleArray = ["OPEN SWEEPSTAKES", "PREMIUM SWEEPSTAKES", "PRODUCTS FOR AUCTION","OPEN SALES","PLATINUM ELITE REWARDS","GOLD ELITE REWARDS","SILVER ELITE REWARDS", "RISKY AUCTION"]
        
        
        //        let  sectionTitleArray = ["PRODUCT FOR SWEEP TAKES","PRODUCTS FOR AUCTION","PRODUCTS FOR SALES","PLATINUM SALES","GOLD SALES","SILVER SALES"]
        
        segmentedcontrol2.sectionTitles = sectionTitleArray as [AnyObject]
        segmentedcontrol2.autoresizingMask = [.flexibleWidth,.flexibleHeight]
        segmentedcontrol2.frame = CGRect(x: 0, y: 0, width: self.segmentView.frame.width, height: self.segmentView.frame.height)
        segmentedcontrol2.backgroundColor = UIColor(red: 136/256, green: 11/256, blue: 36/256, alpha: 1.0)
        
        segmentedcontrol2.selectionStyle = HMSegmentedControlSelectionStyleFullWidthStripe
        segmentedcontrol2.segmentWidthStyle = HMSegmentedControlSegmentWidthStyleDynamic
        
        
        segmentedcontrol2.selectionIndicatorLocation = HMSegmentedControlSelectionIndicatorLocationDown
        segmentedcontrol2.selectionIndicatorHeight = 3.0
        segmentedcontrol2.selectionIndicatorColor = UIColor(red: 22/256, green: 134/256, blue: 226/256, alpha: 1.0)
        
        let titleAttribute = [ NSFontAttributeName: UIFont(name:"HelveticaNeue-Medium", size: 12.0)!,NSForegroundColorAttributeName : UIColor.white]
        segmentedcontrol2.titleTextAttributes = titleAttribute
        
        segmentedcontrol2.isVerticalDividerEnabled = false
        segmentedcontrol2.verticalDividerColor = UIColor.white
        segmentedcontrol2.verticalDividerWidth = 10.0
        
        
        segmentedcontrol2.selectedTitleTextAttributes = [NSForegroundColorAttributeName : UIColor.white]
        segmentedcontrol2.addTarget(self, action:#selector(SearchProductVC.segmentedControlChangedValue(_:)) , for: UIControlEvents.valueChanged)
        self.segmentView.addSubview(segmentedcontrol2)
        
        //add a horizontal scrolling for paging effect
        scrollView.frame = CGRect(x: 0, y: 0, width: view.frame.width, height: self.view.frame.height-((self.navigationController?.navigationBar.frame.size.height)!+self.segmentView.frame.height+70))
        
        scrollView.backgroundColor = UIColor.white
        scrollView.isPagingEnabled = true
        scrollView.showsHorizontalScrollIndicator = false
        scrollView.bounces = false
        
        let width : CGFloat = self.view.frame.width * CGFloat(sectionTitleArray.count)
        scrollView.contentSize = CGSize(width: width, height: scrollView.frame.height)
        scrollView.delegate = self
        
        
        let sweepTakesVC = self.storyboard?.instantiateViewController(withIdentifier: "ProductsSubViewVC") as! ProductsSubViewVC
        sweepTakesVC.theProductCategory = self.theProductCategory

        let premiumSweepStakesVC = self.storyboard?.instantiateViewController(withIdentifier: "ProductsSubViewVC") as! ProductsSubViewVC
        premiumSweepStakesVC.theProductCategory = self.theProductCategory
        
        
        let AuctionVC = self.storyboard?.instantiateViewController(withIdentifier: "ProductsSubViewVC") as! ProductsSubViewVC
        AuctionVC.theProductCategory = self.theProductCategory
        
        let salesVC = self.storyboard?.instantiateViewController(withIdentifier: "ProductsSubViewVC") as! ProductsSubViewVC
        salesVC.theProductCategory = self.theProductCategory
        
        
        let platinumVC = self.storyboard?.instantiateViewController(withIdentifier: "ProductsSubViewVC") as! ProductsSubViewVC
        platinumVC.theProductCategory = self.theProductCategory
        
        
        let goldVC = self.storyboard?.instantiateViewController(withIdentifier: "ProductsSubViewVC") as! ProductsSubViewVC
        goldVC.theProductCategory = self.theProductCategory
        
        
        let silverVC = self.storyboard?.instantiateViewController(withIdentifier: "ProductsSubViewVC") as! ProductsSubViewVC
        silverVC.theProductCategory = self.theProductCategory
        
        let riskyVC = self.storyboard?.instantiateViewController(withIdentifier: "ProductsSubViewVC") as! ProductsSubViewVC
        
        riskyVC.theProductCategory = self.theProductCategory
        
        
        addChildViewController(sweepTakesVC)
        sweepTakesVC.senderTag = "sweepTakesVC"
        sweepTakesVC.view.frame = CGRect(x: 0, y: 0,width: self.view.frame.width, height: self.scrollView.frame.height)
        scrollView.addSubview(sweepTakesVC.view)
        sweepTakesVC.didMove(toParentViewController: self)
        
        addChildViewController(premiumSweepStakesVC)
        premiumSweepStakesVC.senderTag = "premiumSweepStakesVC"
        premiumSweepStakesVC.view.frame = CGRect(x: self.view.frame.width*1, y: 0,width: self.view.frame.width, height: self.scrollView.frame.height)
        scrollView.addSubview(premiumSweepStakesVC.view)
        premiumSweepStakesVC.didMove(toParentViewController: self)

        
        addChildViewController(AuctionVC)
        AuctionVC.senderTag = "AuctionVC"
        AuctionVC.view.frame = CGRect(x: self.view.frame.width*2, y: 0,width: self.view.frame.width,height: self.scrollView.frame.height)
        scrollView.addSubview(AuctionVC.view)
        AuctionVC.didMove(toParentViewController: self)
        
        addChildViewController(salesVC)
        salesVC.senderTag = "salesVC"
        salesVC.view.frame = CGRect(x: self.view.frame.width*3, y: 0,width: self.view.frame.width, height: self.scrollView.frame.height)
        scrollView.addSubview(salesVC.view)
        salesVC.didMove(toParentViewController: self)
        
        addChildViewController(platinumVC)
        platinumVC.senderTag = "platinumVC"
        platinumVC.view.frame = CGRect(x: self.view.frame.width*4, y: 0,width: self.view.frame.width, height: self.scrollView.frame.height)
        scrollView.addSubview(platinumVC.view)
        platinumVC.didMove(toParentViewController: self)
        
        addChildViewController(goldVC)
        goldVC.senderTag = "goldVC"
        goldVC.view.frame = CGRect(x: self.view.frame.width*5, y: 0,width: self.view.frame.width, height: self.scrollView.frame.height)
        scrollView.addSubview(goldVC.view)
        goldVC.didMove(toParentViewController: self)
        
        addChildViewController(silverVC)
        silverVC.senderTag = "silverVC"
        silverVC.view.frame = CGRect(x: self.view.frame.width*6, y: 0,width: self.view.frame.width, height:self.scrollView.frame.height)
        scrollView.addSubview(silverVC.view)
        silverVC.didMove(toParentViewController: self)
        
        addChildViewController(riskyVC)
        riskyVC.senderTag = "riskyVC"
        //riskyVC.title = sectionTitleArray[7]
        riskyVC.view.frame = CGRect(x: self.view.frame.width*7, y: 0,width: self.view.frame.width, height: self.scrollView.frame.height)
        scrollView.addSubview(riskyVC.view)
        riskyVC.didMove(toParentViewController: self)
        
        
        self.contentView.addSubview(scrollView)
        
    }
    
    /*
     let  sectionTitleArray = ["OPEN SWEEPSTAKES", "PREMIUM SWEEPSTAKES", "PRODUCTS FOR AUCTION","OPEN SALES","PLATINUM ELITE REWARDS","GOLD ELITE REWARDS","SILVER ELITE REWARDS", "RISKY AUCTION"]
     
     segmentedcontrol2.sectionTitles = sectionTitleArray as [AnyObject]
     segmentedcontrol2.autoresizingMask = [.flexibleWidth,.flexibleHeight]
     segmentedcontrol2.frame = CGRect(x: 0, y: 0, width: self.segmentView.frame.width, height: self.segmentView.frame.height)
     segmentedcontrol2.backgroundColor = UIColor(red: 136/256, green: 11/256, blue: 36/256, alpha: 1.0)
     
     segmentedcontrol2.selectionStyle = HMSegmentedControlSelectionStyleFullWidthStripe
     segmentedcontrol2.segmentWidthStyle = HMSegmentedControlSegmentWidthStyleDynamic
     
     
     segmentedcontrol2.selectionIndicatorLocation = HMSegmentedControlSelectionIndicatorLocationDown
     segmentedcontrol2.selectionIndicatorHeight = 3.0
     segmentedcontrol2.selectionIndicatorColor = UIColor(red: 22/256, green: 134/256, blue: 226/256, alpha: 1.0)
     
     let titleAttribute = [ NSFontAttributeName: UIFont(name:"HelveticaNeue-Medium", size: 12.0)!,NSForegroundColorAttributeName : UIColor.white]
     segmentedcontrol2.titleTextAttributes = titleAttribute
     
     segmentedcontrol2.isVerticalDividerEnabled = false
     segmentedcontrol2.verticalDividerColor = UIColor.white
     segmentedcontrol2.verticalDividerWidth = 10.0
     
     
     segmentedcontrol2.selectedTitleTextAttributes = [NSForegroundColorAttributeName : UIColor.white]
     segmentedcontrol2.addTarget(self, action:#selector(ProductsVC.segmentedControlChangedValue(_:)) , for: UIControlEvents.valueChanged)
     self.segmentView.addSubview(segmentedcontrol2)
     
     //add a horizontal scrolling for paging effect
     scrollView.frame = CGRect(x: 0, y: 0, width: view.frame.width, height: self.view.frame.height-((self.navigationController?.navigationBar.frame.size.height)!+self.segmentView.frame.height+70))
     
     scrollView.backgroundColor = UIColor.white
     scrollView.isPagingEnabled = true
     scrollView.showsHorizontalScrollIndicator = false
     scrollView.bounces = false
     
     let width : CGFloat = self.view.frame.width * CGFloat(sectionTitleArray.count)
     scrollView.contentSize = CGSize(width: width, height: scrollView.frame.height)
     scrollView.delegate = self
     
     let sweepTakesVC = self.storyboard?.instantiateViewController(withIdentifier: "ProductsSubViewVC") as! ProductsSubViewVC
     let premiumSweepStakesVC = self.storyboard?.instantiateViewController(withIdentifier: "ProductsSubViewVC") as! ProductsSubViewVC
     let AuctionVC = self.storyboard?.instantiateViewController(withIdentifier: "ProductsSubViewVC") as! ProductsSubViewVC
     let salesVC = self.storyboard?.instantiateViewController(withIdentifier: "ProductsSubViewVC") as! ProductsSubViewVC
     let platinumVC = self.storyboard?.instantiateViewController(withIdentifier: "ProductsSubViewVC") as! ProductsSubViewVC
     let goldVC = self.storyboard?.instantiateViewController(withIdentifier: "ProductsSubViewVC") as! ProductsSubViewVC
     let silverVC = self.storyboard?.instantiateViewController(withIdentifier: "ProductsSubViewVC") as! ProductsSubViewVC
     let riskyVC = self.storyboard?.instantiateViewController(withIdentifier: "ProductsSubViewVC") as! ProductsSubViewVC
     
     
     addChildViewController(sweepTakesVC)
     sweepTakesVC.senderTag = "sweepTakesVC"
     sweepTakesVC.title = sectionTitleArray[0]
     sweepTakesVC.view.frame = CGRect(x: 0, y: 0,width: self.view.frame.width, height: self.scrollView.frame.height)
     scrollView.addSubview(sweepTakesVC.view)
     sweepTakesVC.didMove(toParentViewController: self)
     //sweepTakesVC.addTarget(self, action:#selector(ProductsVC.segmentedControlChangedValue(_:)) , for: UIControlEvents.valueChanged)
     
     addChildViewController(premiumSweepStakesVC)
     premiumSweepStakesVC.senderTag = "premiumSweepStakesVC"
     premiumSweepStakesVC.title = sectionTitleArray[1]
     premiumSweepStakesVC.view.frame = CGRect(x: self.view.frame.width*1, y: 0,width: self.view.frame.width,height: self.scrollView.frame.height)
     scrollView.addSubview(premiumSweepStakesVC.view)
     premiumSweepStakesVC.didMove(toParentViewController: self)
     
     addChildViewController(AuctionVC)
     AuctionVC.senderTag = "AuctionVC"
     AuctionVC.title = sectionTitleArray[2]
     AuctionVC.view.frame = CGRect(x: self.view.frame.width*2, y: 0,width: self.view.frame.width,height: self.scrollView.frame.height)
     scrollView.addSubview(AuctionVC.view)
     AuctionVC.didMove(toParentViewController: self)
     
     addChildViewController(salesVC)
     salesVC.senderTag = "salesVC"
     salesVC.title = sectionTitleArray[3]
     salesVC.view.frame = CGRect(x: self.view.frame.width*3, y: 0,width: self.view.frame.width, height: self.scrollView.frame.height)
     scrollView.addSubview(salesVC.view)
     salesVC.didMove(toParentViewController: self)
     
     addChildViewController(platinumVC)
     platinumVC.senderTag = "platinumVC"
     platinumVC.title = sectionTitleArray[4]
     platinumVC.view.frame = CGRect(x: self.view.frame.width*4, y: 0,width: self.view.frame.width, height: self.scrollView.frame.height)
     scrollView.addSubview(platinumVC.view)
     platinumVC.didMove(toParentViewController: self)
     
     addChildViewController(goldVC)
     goldVC.senderTag = "goldVC"
     goldVC.title = sectionTitleArray[5]
     goldVC.view.frame = CGRect(x: self.view.frame.width*5, y: 0,width: self.view.frame.width, height: self.scrollView.frame.height)
     scrollView.addSubview(goldVC.view)
     goldVC.didMove(toParentViewController: self)
     
     addChildViewController(silverVC)
     silverVC.senderTag = "silverVC"
     silverVC.title = sectionTitleArray[6]
     silverVC.view.frame = CGRect(x: self.view.frame.width*6, y: 0,width: self.view.frame.width, height: self.scrollView.frame.height)
     scrollView.addSubview(silverVC.view)
     silverVC.didMove(toParentViewController: self)
     
     addChildViewController(riskyVC)
     riskyVC.senderTag = "riskyVC"
     riskyVC.title = sectionTitleArray[7]
     riskyVC.view.frame = CGRect(x: self.view.frame.width*7, y: 0,width: self.view.frame.width, height: self.scrollView.frame.height)
     scrollView.addSubview(riskyVC.view)
     riskyVC.didMove(toParentViewController: self)
     
     self.contentView.addSubview(scrollView)
     
     */
    
    func segmentedControlChangedValue(_ segmentedControl : HMSegmentedControl)->Void
    {
        scrollView.scrollRectToVisible(CGRect(x: self.view.frame.width*CGFloat(segmentedControl.selectedSegmentIndex), y: 0, width: self.scrollView.frame.width, height: self.scrollView.frame.height), animated: true)
    }
    
    func scrollViewDidEndDecelerating(_ scrollView: UIScrollView)
    {
        let pageWidth: CGFloat = scrollView.frame.size.width
        let page = UInt(scrollView.contentOffset.x / pageWidth)
        
        self.segmentedcontrol2.setSelectedSegmentIndex(page, animated: true)
    }
    
    
    
    func getUserPoints()
    {
        let body = String(format:"token=%@", UserDefaults.standard.object(forKey: "token") as! String)
        
        let task = "getuserpoints"
        WebService().sendAPIRequest(UrlClass.baseUrl, body: body,task: task) { (result, error) -> Void in
            
            
            if(result.count>0){
                if result["status"] as! Int == 1
                {
                    
                    DispatchQueue.main.async(execute: { () -> Void in
                        let points = String(format: "Available  Points    %@",result["availablepoints"] as! NSString as String)
                        
                        self.theAvailablePoints.text = points
                    })
                }
            }
        }
    }
    
    
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
    /*
     // MARK: - Navigation
     
     // In a storyboard-based application, you will often want to do a little preparation before navigation
     override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
     // Get the new view controller using segue.destinationViewController.
     // Pass the selected object to the new view controller.
     }
     */
    
}
