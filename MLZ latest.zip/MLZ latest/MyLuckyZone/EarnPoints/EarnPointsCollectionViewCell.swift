//
//  EarnPointsCollectionViewCell.swift
//  MyLuckyzone
//
//  Created by Mastero on 27/11/17.
//  Copyright © 2017 Adodis. All rights reserved.
//

import UIKit

class EarnPointsCollectionViewCell: UICollectionViewCell {
    @IBOutlet weak var imageview: UIImageView!
    @IBOutlet weak var labelmiddel: UILabel!
    @IBOutlet weak var buybutton: UIButton!
    @IBOutlet weak var pointsLabel: UILabel!
    @IBOutlet weak var headerLable: UILabel!
    
}
