//
//  EarnPointsCell.swift
//  MyLuckyZone
//
//  Created by Kavya Mishra on 5/18/16.
//  Copyright © 2016 Adodis. All rights reserved.
//

import UIKit

class EarnPointsCell: UITableViewCell {

    @IBOutlet weak var earnPointLabel: UILabel!
    
    @IBOutlet weak var theImageView: UIImageView!
    
    @IBOutlet weak var theWebSitesTitle: UILabel!
    
    @IBOutlet weak var videoimg: UIImageView!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
