//
//  BrowseVC.swift
//  MyLuckyZone
//
//  Created by Adodis on 25/05/16.
//  Copyright © 2016 Adodis. All rights reserved.
//

import UIKit
import WebKit


class BrowseVC: UIViewController ,WKNavigationDelegate, UIScrollViewDelegate {
    
    var websiteID = NSString()
    
    var websiteUrl = NSString()
    
    var webView: WKWebView
    
    var startTime = NSString()
    
    @IBOutlet var loadingLbl: UILabel!
    
    @IBOutlet var navigationView: UIView!
    
    var urlString:String!
    
    var maxAllowedSeconds : Double?
    
    var timer : Timer?
    
    var remainingTime : TimeInterval?
    
    var lastInteractionTime : TimeInterval?
    
    var interactionTimer : Timer?
    let formatter = DateFormatter()
    var timeoutTimer : Timer?
    
    var alertController : UIAlertController?
    
    required init(coder aDecoder: NSCoder) {
        self.webView = WKWebView(frame: CGRect.zero)
        super.init(coder: aDecoder)!
        self.webView.navigationDelegate = self
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        formatter.dateFormat = "YYYY-MM-dd HH:mm:ss"
        
        self.view.addSubview( self.webView)
        
        webView.translatesAutoresizingMaskIntoConstraints = false
        let height = NSLayoutConstraint(item: webView, attribute: .height, relatedBy: .equal, toItem: view, attribute: .height, multiplier: 1, constant: -44)
        let width = NSLayoutConstraint(item: webView, attribute: .width, relatedBy: .equal, toItem: view, attribute: .width, multiplier: 1, constant: 0)
        view.addConstraints([height, width])
        
        
        let url = URL(string:self.websiteUrl as String)
        let request = URLRequest(url:url!)
        webView.load(request)
        webView.scrollView.delegate = self
    }
    
    func scrollViewDidScroll(_ scrollView: UIScrollView) {
        self.lastInteractionTime = Date().timeIntervalSince1970
    }
    
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
    //It will be called whenever the observable property changes. The state of the back and forward buttons will be changed according to the current state of the web view.
    
    override func observeValue(forKeyPath keyPath: String?, of object: Any?, change: [NSKeyValueChangeKey : Any]?, context: UnsafeMutableRawPointer?)
    {
        if (keyPath == "loading")
        {
            // backButton.enabled = webView.canGoBack
            //forwardButton.enabled = webView.canGoForward
        }
        
        if (keyPath == "estimatedProgress")
        {
            // progressView.hidden = webView.estimatedProgress == 1
            //progressView.setProgress(Float(webView.estimatedProgress), animated: true)
            
            let percent = (Float(webView.estimatedProgress)/1.0)*100
            let percentage = String(percent)
            
            if (percent >= 100)
            {
                self.navigationItem.title = "MyLuckyZone"
            } else {
                self.navigationItem.title = "Loading " + percentage + " %"
                
            }
            
        }
    }
    
    func startInteractionTimer() {
        self.lastInteractionTime = Date().timeIntervalSince1970
        self.interactionTimer?.invalidate()
        self.interactionTimer = Timer.scheduledTimer(timeInterval: 5.0, target: self, selector: #selector(self.interactionTimeout), userInfo: nil, repeats: true)
    }
    
    func interactionTimeout() {
        let diff = Date().timeIntervalSince1970 - lastInteractionTime!
        print("Interaction timeout : \(diff)")
        if diff >= 30 {
            self.interactionTimer?.invalidate()
            self.pauseTimer(false)
            alertController = self.displayAlert("Alert", message: "You have paused earning points from MLZ Press ok to resume earning poins", handler: {(UIAlertAction) -> Void in
                self.timeoutTimer?.invalidate()
                self.activateTimer(false)
                self.startInteractionTimer()
            })
            self.startTimeoutTimer()
        }
    }
    
    func startTimeoutTimer() {
        self.timeoutTimer?.invalidate()
        self.timeoutTimer = Timer.scheduledTimer(timeInterval: 20.0, target: self, selector: #selector(self.timeoutTimerTimeout), userInfo: nil, repeats: false)
    }

    func stopTimeoutTimer() {
        self.timeoutTimer?.invalidate()
    }
    
    func timeoutTimerTimeout() {
        self.TrackBrowsingTime()
        stopTimeoutTimer()
        alertController?.dismiss(animated: false, completion: nil)
        self.navigationController?.popViewController(animated: true)
    }
    
    func timeout() {
        self.TrackBrowsingTime()
        self.displayAlert("Alert", message: "You have exceeded the number of seconds allowed to browse on this web page, please chose another webpage or reopen the same to keep earning points.", handler: {(UIAlertAction) -> Void in
            self.navigationController?.popViewController(animated: true)
        })
    }
    
    
    func webView(_ webView: WKWebView, didStartProvisionalNavigation navigation: WKNavigation!) {
        if self.timer == nil {
            self.activateTimer(true)
            self.startInteractionTimer()
        }
        self.lastInteractionTime = Date().timeIntervalSince1970
    }
    
    
    //MARK:WKNavigationDelegate methods
    
    func webView(_ webView: WKWebView, didFailProvisionalNavigation navigation: WKNavigation!, withError error: Error)
    {
        let alert = UIAlertController(title: "Error", message: error.localizedDescription, preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "Ok", style: .default, handler: nil))
        present(alert, animated: true, completion: nil)
    }
    
    func webView(_ webView: WKWebView, didFinish navigation: WKNavigation!)
    {
        print("didFinishNavigation")
    }
    
    func pauseTimer(_ reset : Bool) {
        if (self.timer?.isValid == true) {
            if reset {
                self.TrackBrowsingTime()
                self.remainingTime = self.maxAllowedSeconds
            } else {
                self.remainingTime = Date().timeIntervalSince((self.timer?.fireDate)!) * -1
            }
            self.timer?.invalidate()
        }
    }
    
    func activateTimer(_ reset : Bool) {
        if timer?.isValid == true {
        } else {
            if reset {
                self.remainingTime = self.maxAllowedSeconds
                self.startTime = formatter.string(from: Date()) as NSString
            }
            self.timer?.invalidate()
            self.timer = Timer.scheduledTimer(timeInterval: self.remainingTime!, target: self, selector: #selector(self.timeout), userInfo: nil, repeats: false)
        }
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(true)
        self.webView.removeObserver(self, forKeyPath: "loading")
        self.webView.removeObserver(self, forKeyPath: "estimatedProgress")
        
        self.pauseTimer(true)
        self.interactionTimer?.invalidate()
        self.timeoutTimer?.invalidate()
    }
    
    
    
    override func viewWillAppear(_ animated: Bool)
    {
        super.viewWillAppear(animated)
        webView.addObserver(self, forKeyPath: "loading", options: .new, context: nil)// it is used to detect error in loading
        webView.addObserver(self, forKeyPath: "estimatedProgress", options: .new, context: nil)//this key path is used for showing progress indicator while loading
    }
    
    
    deinit
    {
        // if you have set either WKWebView delegate also set these to nil here
        self.webView.navigationDelegate = nil
        self.webView.scrollView.delegate = nil
        self.webView.uiDelegate = nil;
        
    }
    
    
    func TrackBrowsingTime()
    {
        print("TrackBrowsingTime")
        let date = Date()
        let formatter = DateFormatter()
        
        formatter.dateFormat = "YYYY-MM-dd HH:mm:ss"
        let endTime = formatter.string(from: date)
        
        let Raw_Code:String = String(format:"%@%@%@%@%@",WebService().getSALT,UserDefaults.standard.object(forKey: "token") as! String,websiteID,self.startTime,endTime)
        let AUTH_CODE:String = WebService().SHA1(Raw_Code)
        
        let body = String(format:"token=%@&websiteid=%@&starttime=%@&endtime=%@&authcode=%@", UserDefaults.standard.object(forKey: "token") as! String,websiteID,self.startTime,endTime,AUTH_CODE)
        WebService.sharedInstance.trackBrowsingTime(body)
    }
    
    
    /*
     // MARK: - Navigation
     
     // In a storyboard-based application, you will often want to do a little preparation before navigation
     override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
     // Get the new view controller using segue.destinationViewController.
     // Pass the selected object to the new view controller.
     }
     */
    
}
