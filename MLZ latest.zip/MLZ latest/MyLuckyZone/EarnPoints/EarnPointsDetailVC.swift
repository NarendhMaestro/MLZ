//
//  EarnPointsDetailVC.swift
//  MyLuckyZone
//
//  Created by Kavya Mishra on 5/18/16.
//  Copyright © 2016 Adodis. All rights reserved.
//

import UIKit

class EarnPointsDetailVC: UIViewController {
    
    var websiteUrl = NSString()
    
    @IBOutlet var thePointsLabel: UILabel!
    @IBOutlet var theTitleLabel: UILabel!
    @IBOutlet var theImageView: UIImageView!
    var getWebsiteID = NSString()
    var maxAllowedSeconds : Double?
    
    @IBOutlet weak var theLabel: UILabel!
    
//    var startTime : NSTimeInterval?
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    
    
    override func viewWillAppear(_ animated: Bool)
    {
        super.viewWillAppear(true)
        
        // self.getWebsiteID = ""
        
        if Reachability.isConnectedToNetwork() == true {
            self.theLabel.text = ""
            
            self.theTitleLabel.text = ""
            
            self.thePointsLabel.text = ""
            
            self.getwebsitedetail(self.getWebsiteID)
            
        } else {
            self.displayAlert("Alert Message", message: "Please Check Internet connection")
            
        }
        
    }
    
    
    override func viewWillDisappear(_ animated: Bool) {
        
        super.viewWillDisappear(true)
//        self.getWebsiteID = ""
        self.theLabel.text = ""
        self.theTitleLabel.text = ""
        self.thePointsLabel.text = ""
        
        
    }
    
    
    func getwebsitedetail(_ websiteID:NSString)
    {
        self.showProgress()
        
        let body = String(format:"token=%@&websiteid=%@", UserDefaults.standard.object(forKey: "token") as! String, websiteID)
        
        let task = "getwebsitedetail"
        WebService().sendAPIRequest(UrlClass.baseUrl, body: body,task: task) { (result, error) -> Void in
            
            if result["status"] as! Int == 1
            {
                DispatchQueue.main.async(execute: { () -> Void in
                    
                    self.hideProgress()
                    
                    self.theLabel.text = (result["website"] as! NSDictionary).object(forKey: "description") as? String
                    
                    self.theTitleLabel.text = (result["website"] as! NSDictionary).object(forKey: "title") as? String
                    
                    let points = String(format: "%@ Points Per Seconds",((result["website"] as! NSDictionary).object(forKey: "pointspersecond") as? String)!)
                    
                    self.thePointsLabel.text = points
                    
                    let url =  (result["website"] as! NSDictionary).object(forKey: "url") as! NSArray
                    
                    self.websiteUrl = url.object(at: 0) as! NSString
                    
                    self.maxAllowedSeconds = Double(((result["website"] as! NSDictionary).object(forKey: "maxallowedseconds") as? String)!)
                    
//                    self.startTime = NSDate().timeIntervalSince1970
                    
                    if(self.isNotNSNull(((result["website"] as! NSDictionary).object(forKey: "logopath"))! as AnyObject))
                    {
                        let imageURl = String(format: "%@%@", WebService.sharedInstance.getBaseURL, ((result["website"] as! NSDictionary).object(forKey: "logopath") as? String)!)
                        
                        let url = URL(string: imageURl.trim())
                        DispatchQueue.global(priority: DispatchQueue.GlobalQueuePriority.background).async {
                            let data = try? Data(contentsOf: url!)
                            DispatchQueue.main.async(execute: {
                                self.theImageView.image = UIImage(data: data!)
                            });
                        }
                    }
                })
            } else if result["status"] as! Int == 0 || result["status"] as! Int == -1
            {
                DispatchQueue.main.async(execute: {
                    self.hideProgress()
                    self.displayAlert("Alert", message: result["msg"] as! String, handler: { (UIAlertAction) in
//                        self.dismissViewControllerAnimated(true, completion: nil)
                        self.navigationController?.popViewController(animated: true)
                    })
                });
            }
        }
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        let destnatination = segue.destination as! BrowseVC
        destnatination.websiteID = self.getWebsiteID
        destnatination.websiteUrl = self.websiteUrl
        destnatination.maxAllowedSeconds = self.maxAllowedSeconds
    }
    
    
    @IBAction func browseButtonClicked(_ sender: AnyObject) {
        self.showProgress()
        let body = String(format:"token=%@&websiteid=%@", UserDefaults.standard.object(forKey: "token") as! String, getWebsiteID)
        let task = "checkuserwebsiteviewstatus"
        WebService().sendAPIRequest(UrlClass.baseUrl, body: body,task: task) { (result, error) -> Void in
            DispatchQueue.main.async(execute: { () -> Void in
                self.hideProgress()
                if result["status"] as! Int == 1 {
                    self.performSegue(withIdentifier: "browseSegue", sender: nil)
                } else {
                    self.displayAlert("Alert Message", message: result["msg"] as! String)
                }
            })
        }
    }
    
    
    func isNotNSNull(_ object:AnyObject) -> Bool {
        return object.classForCoder != NSNull.classForCoder()
    }
    
    
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
    /*
     // MARK: - Navigation
     
     // In a storyboard-based application, you will often want to do a little preparation before navigation
     override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
     // Get the new view controller using segue.destinationViewController.
     // Pass the selected object to the new view controller.
     }
     */
    
}
