//
//  EarnPointsVC.swift
//  MyLuckyZone
//
//  Created by Kavya Mishra on 5/18/16.
//  Copyright © 2016 Adodis. All rights reserved.
//

import UIKit
import SDWebImage

class EarnPointsVC: UIViewController ,UITableViewDataSource,UICollectionViewDelegate,UICollectionViewDataSource
{
    @IBOutlet weak var theTableView: UITableView!
    @IBOutlet weak var collectionview: UICollectionView!
    @IBOutlet weak var toplable: SMIconLabel!
    @IBOutlet weak var middleLable: SMIconLabel!
    
    var earnSubView = EarnPointsDetailVC()
    
    var theWebsiteDataArray = NSArray()
    
    var isEarnDetailView = Bool()
    
    var senderTag = " "
    
    var receivedStoryboardID:String!
    
    var earnPointsTableDataArr = NSMutableArray()
    
    var refreshControl: UIRefreshControl!
    
    var currentPage = NSInteger()
    
    var totalPage = NSInteger()

    
    override func viewDidLoad()
    {
        super.viewDidLoad()
        
        refreshControl = UIRefreshControl()
        //refreshControl.attributedTitle = NSAttributedString(string: "Pull to refresh")
        refreshControl.addTarget(self, action: #selector(EarnPointsVC.refresh(_:)), for: UIControlEvents.valueChanged)
        self.theTableView.addSubview(refreshControl)

        collectionview.delegate = self
        collectionview.dataSource = self
        
        toplable.text = "Featured Rewards"
        toplable.icon = UIImage(named: "flash")
        toplable.iconPosition = ( .left, .center )
        toplable.textColor = .red
        
        
        middleLable.text = "Featured Brand"
        middleLable.icon = UIImage(named: "star")
        middleLable.iconPosition = ( .left, .center )
        middleLable.textColor = .green
        // Do any additional setup after loading the view.
    }
    
    func refresh(_ sender:AnyObject) {
        
        self.theTableView.reloadData()

        refreshControl.endRefreshing()
    }
    
    override func viewWillAppear(_ animated: Bool)
    {
        super.viewWillAppear(true)
        
        if Reachability.isConnectedToNetwork() == true {
            
        self.currentPage = 1
            
        self.getWebsitesList(self.currentPage)
            
        } else
        {
        self.displayAlert("Alert Message", message: "Please Check Internet connection")

        }

        
        //if you are coming from the rear vc
        if let receivedViewDict = UserDefaults.standard.object(forKey: "slideMenuView") as? [String:AnyObject]
        {
            self.theTableView.isHidden = true
            print(receivedViewDict)
            
            if let receivedID = receivedViewDict["storyboardidentifier"] as? String
            {
                receivedStoryboardID = receivedID
            }

            theTableView.isHidden = true
            let viewToAdd = self.storyboard?.instantiateViewController(withIdentifier: receivedStoryboardID)
            addChildViewController(viewToAdd!)
            viewToAdd!.view.frame = self.view.bounds
            viewToAdd!.view.tag = 666
            view.addSubview(viewToAdd!.view)
            viewToAdd!.didMove(toParentViewController: self)
            //remove the object from nsuserDefaults after you have retrieved the dictionary
            UserDefaults.standard.removeObject(forKey: "slideMenuView")
            
        }
        else
        {
            //write codes in this block when you come normally in a flow not from yhe rear view controller
             self.theTableView.isHidden = false
            print("Nothing stored in NSUserDefaults yet. Set a value.")
        }
     
        if isEarnDetailView == true
        {
            earnSubView.getWebsiteID = ""
          self.earnSubView.view.removeFromSuperview()
          self.theTableView.isHidden = false
        }
        
        //add observer to receive notification from tab bar controller
       
         NotificationCenter.default.addObserver(self, selector: #selector(EarnPointsVC.removeSideViewIfPresent(_:)), name:NSNotification.Name(rawValue: "RemoveSideMenuView"), object: nil)
        
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        NotificationCenter.default.removeObserver(self)
    }
    
    
    func removeSideViewIfPresent(_ notification: Notification)
    {
        //Take Action on Notification
        self.view.viewWithTag(666)?.removeFromSuperview()
        self.theTableView.isHidden = false
        print("heyyy")
    }

    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    
    
    func numberOfSections(in tableView: UITableView) -> Int
    {
        return 1;

    }
    
    
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int
    {
        return self.theWebsiteDataArray.count
    }

    
    // Row display. Implementers should *always* try to reuse cells by setting each cell's reuseIdentifier and querying for available reusable cells with dequeueReusableCellWithIdentifier:
    // Cell gets various attributes set automatically based on table (separators) and data source (accessory views, editing controls)
    
     func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell
     {
        let cell = self.theTableView.dequeueReusableCell(withIdentifier: "earnPoints") as! EarnPointsCell
        
        cell.selectionStyle = UITableViewCellSelectionStyle.none

        cell.theWebSitesTitle?.text = (self.theWebsiteDataArray.value(forKey: "title") as! NSArray)[indexPath.row] as? String
        
        if ((self.theWebsiteDataArray.object(at: (indexPath as NSIndexPath).row) as AnyObject).value(forKey: "pointspersecond") != nil)
        {
        let points = String(format: "Earn up to %@ Points watching this week's offers.",((self.theWebsiteDataArray[(indexPath as NSIndexPath).row] as AnyObject).value(forKey: "pointspersecond") as? NSString)!)
            
            cell.earnPointLabel.text = points as String
            cell.videoimg.image = UIImage(named:"watched")
        }
        if (isNotNSNull((self.theWebsiteDataArray.object(at: (indexPath as NSIndexPath).row) as! NSDictionary).value(forKey: "logopath")! as AnyObject))
        {
            let imageURl = String(format: "%@%@", WebService.sharedInstance.getBaseURL, ((self.theWebsiteDataArray[(indexPath as NSIndexPath).row] as AnyObject).value(forKey: "logopath") as? NSString)!)
            
            if (isNotNSNull(imageURl as AnyObject))
            {
            cell.theImageView.sd_setImage(with: URL(string:imageURl)
                                , placeholderImage: nil
                                , options: SDWebImageOptions.retryFailed
                                , progress: {(receivedSize: Int, expectedSize: Int) in
                                }
                                , completed:{(image: UIImage?, error: Error?, cacheType: SDImageCacheType, imageURL: URL?) in
                                    if (image != nil) {
                                        cell.theImageView.image = image
                                    }
                            })
           }
        }
        return cell
    }
    
    
    func isNotNSNull(_ object:AnyObject) -> Bool {
        return object.classForCoder != NSNull.classForCoder()
    }
    
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
//        earnSubView = self.storyboard?.instantiateViewController(withIdentifier: "EarnPointsDetailVC") as! EarnPointsDetailVC
//
//        earnSubView.getWebsiteID = ((self.theWebsiteDataArray[indexPath.row] as AnyObject).value("websiteid") as? NSString)!
//
//        addChildViewController(earnSubView)
//
//        earnSubView.view.frame = self.view.bounds
//
//        self.view.addSubview(earnSubView.view)
//
//        self.theTableView.isHidden = true
//
//        earnSubView.didMove(toParentViewController: self)
//
//        isEarnDetailView = true
//
        self.performSegue(withIdentifier: "showEarnPoints", sender: ["index" : (indexPath as NSIndexPath).row])
        
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any!) {
        if segue.identifier == "showEarnPoints" {
            let earnSubView = segue.destination as? EarnPointsDetailVC
            let index = (sender as! [String : AnyObject])["index"] as? Int
            earnSubView?.getWebsiteID = ((self.theWebsiteDataArray[index!] as AnyObject).value(forKey: "websiteid") as? NSString)!
        }
    }

   
    
    func getWebsitesList(_ pageNumber:NSInteger)
    {
        self.showProgress()
        
        let body = String(format:"token=%@&pagenumer=%@", UserDefaults.standard.object(forKey: "token") as! String,String(pageNumber))
        
        let task = "listallwebsites"
        WebService().sendAPIRequest(UrlClass.baseUrl, body: body,task: task) { (result, error) -> Void in
            
            if result["status"] as! Int == 1
            {
                self.totalPage = result ["totalpages"] as! NSInteger
                
                if(self.currentPage == 1)
                {
                 self.theWebsiteDataArray = result["websitelist"] as! NSArray
                }
                else
                {
                   let newPageArr = result["websitelist"] as! NSArray
                
                   let newArr = self.theWebsiteDataArray.mutableCopy() as? NSMutableArray
                    
                   for i in self.theWebsiteDataArray.count ..< self.theWebsiteDataArray.count+newPageArr.count
                   {
                    newArr!.insert(newPageArr[i-self.theWebsiteDataArray.count], at: i)
                    }
                   self.theWebsiteDataArray = newArr!
                }
                
                DispatchQueue.main.async(execute: { () -> Void in
                self.hideProgress()
                self.theTableView.reloadData()
                })
            } else if result["status"] as! Int == 0 || result["status"] as! Int == -1
            {
            DispatchQueue.main.async(execute: { () -> Void in
            self.hideProgress()
                
                let alertController = UIAlertController(title: "Alert Message", message: result["msg"] as? String, preferredStyle: UIAlertControllerStyle.alert)
                let ok = UIAlertAction(title: "Ok", style: UIAlertActionStyle.default, handler: {(action) -> Void in
                    //The (withIdentifier: "VC2") is the Storyboard Segue identifier.
                print("loggout")
                     self.logout()
                    
                })
                
                alertController.addAction(ok)
                self.present(alertController, animated: true, completion: nil)
                
//            self.displayAlert("", message:  as! String)
            })
            }
        }
    }
    
    
    
    func scrollViewDidEndDragging(_ scrollView: UIScrollView, willDecelerate decelerate: Bool) {
        
        let currentOffset = scrollView.contentOffset.y
        
        let maximumOffset = scrollView.contentSize.height - scrollView.frame.size.height
        
        
        if (maximumOffset - currentOffset <= 10)
        {
            
        if (self.currentPage == totalPage)
        {
            
        } else {
            self.currentPage = self.currentPage + 1
            
            print(self.currentPage)
            
            self.getWebsitesList(self.currentPage)
        }
            
        }
        
    }
    
    
    func numberOfSections(in collectionView: UICollectionView) -> Int {
        return 1
    }

    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return 9
    }

    //    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize
    //    {
    //        return CGSize(width: 1000.0, height: 1000.0)
    //    }


    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "cellcoll", for: indexPath) as! EarnPointsCollectionViewCell
        
        

        return cell
    }


    
    @IBAction func seeProduct(_ sender: Any) {
//        let tab = mainTabBarController()
       
        self.navigationController?.isNavigationBarHidden = true
        UserDefaults.standard.set(1, forKey: "tabBarSelectedIndex")
        self.performSegue(withIdentifier: "buttonindex", sender: "")
        
        

//
        
        
    }
    
    
    
    
}


extension String
{
    func trim() -> String
    {
        return self.trimmingCharacters(in: CharacterSet.whitespaces)
    }
}
